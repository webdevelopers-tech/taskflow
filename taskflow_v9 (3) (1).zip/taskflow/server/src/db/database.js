const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs');

const DB_DIR  = path.join(__dirname, '../../data');
const DB_FILE = path.join(DB_DIR, 'taskflow.db.json');
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

let _db = null;

function persist() {
  if (!_db) return;
  const data = _db.export();
  fs.writeFileSync(DB_FILE, JSON.stringify({ v:1, data: Buffer.from(data).toString('base64') }));
}

setInterval(persist, 5000).unref();
process.on('exit', persist);
process.on('SIGINT', () => { persist(); process.exit(); });
process.on('SIGTERM', () => { persist(); process.exit(); });

class SyncDB {
  prepare(sql) {
    return {
      run: (...params) => { _db.run(sql, flattenParams(params)); return { changes: _db.getRowsModified() }; },
      get: (...params) => {
        const stmt = _db.prepare(sql); stmt.bind(flattenParams(params));
        if (stmt.step()) { const row = stmt.getAsObject(); stmt.free(); return row; }
        stmt.free(); return undefined;
      },
      all: (...params) => {
        const results = []; const stmt = _db.prepare(sql); stmt.bind(flattenParams(params));
        while (stmt.step()) results.push(stmt.getAsObject());
        stmt.free(); return results;
      }
    };
  }
  exec(sql) { _db.run(sql); return this; }
  pragma(s) { try { _db.run(`PRAGMA ${s}`); } catch {} }
}

function flattenParams(params) {
  if (params.length === 0) return [];
  if (params.length === 1 && Array.isArray(params[0])) return params[0];
  const flat = [];
  for (const p of params) { if (Array.isArray(p)) flat.push(...p); else flat.push(p); }
  return flat;
}

const dbWrapper = new SyncDB();

function initSchema() {
  _db.run(`PRAGMA foreign_keys = ON`);
  _db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'Employee',
      department TEXT NOT NULL DEFAULT 'General', is_admin INTEGER NOT NULL DEFAULT 0,
      color TEXT NOT NULL DEFAULT '#6366f1', timezone TEXT NOT NULL DEFAULT 'IST',
      avatar_url TEXT, is_active INTEGER NOT NULL DEFAULT 1,
      last_login TEXT, login_count INTEGER DEFAULT 0,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS work_schedules (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      day_of_week TEXT NOT NULL, is_working INTEGER NOT NULL DEFAULT 1,
      start_time TEXT NOT NULL DEFAULT '09:00', end_time TEXT NOT NULL DEFAULT '17:00',
      UNIQUE(user_id, day_of_week)
    );
    CREATE TABLE IF NOT EXISTS clock_sessions (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      clock_in TEXT NOT NULL, clock_out TEXT, duration_minutes INTEGER,
      date TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT,
      assigned_to TEXT NOT NULL REFERENCES users(id), assigned_by TEXT NOT NULL REFERENCES users(id),
      priority TEXT NOT NULL DEFAULT 'medium', status TEXT NOT NULL DEFAULT 'pending',
      category TEXT NOT NULL DEFAULT 'general', due_date TEXT NOT NULL,
      completed_at TEXT, closed_by TEXT REFERENCES users(id),
      project TEXT, tags TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS task_comments (
      id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id), content TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS task_history (
      id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id), action TEXT NOT NULL,
      field_name TEXT, old_value TEXT, new_value TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL, message TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'info',
      category TEXT DEFAULT 'general',
      is_read INTEGER NOT NULL DEFAULT 0, task_id TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS activity_log (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
      action TEXT NOT NULL, entity TEXT, entity_id TEXT, meta TEXT,
      ip_address TEXT, user_agent TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit_log (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
      action TEXT NOT NULL, entity TEXT NOT NULL, entity_id TEXT,
      old_data TEXT, new_data TEXT, ip_address TEXT, user_agent TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS refresh_tokens (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS branding (
      id TEXT PRIMARY KEY DEFAULT 'main',
      company_name TEXT NOT NULL DEFAULT 'TaskFlow',
      logo_url TEXT, favicon_url TEXT,
      primary_color TEXT DEFAULT '#6366f1',
      secondary_color TEXT DEFAULT '#8b5cf6',
      accent_color TEXT DEFAULT '#06b6d4',
      sidebar_color TEXT DEFAULT '#0f172a',
      header_color TEXT DEFAULT '#1e293b',
      font_family TEXT DEFAULT 'Inter',
      tagline TEXT DEFAULT 'Office Collaboration Platform',
      footer_text TEXT DEFAULT '© 2025 TaskFlow. All rights reserved.',
      login_bg_color TEXT DEFAULT '#0f172a',
      login_logo_text TEXT DEFAULT 'TF',
      updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, color TEXT NOT NULL DEFAULT '#6366f1',
      icon TEXT DEFAULT '📁', description TEXT, is_active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER DEFAULT 0, created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS category_members (
      id TEXT PRIMARY KEY, category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      UNIQUE(category_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS task_reminders (
      id TEXT PRIMARY KEY, task_id TEXT REFERENCES tasks(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      remind_at TEXT NOT NULL, timezone TEXT NOT NULL DEFAULT 'IST',
      note TEXT, status TEXT NOT NULL DEFAULT 'pending',
      snoozed_until TEXT, fired_at TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      sound_tone TEXT DEFAULT 'bell',
      target_user_id TEXT REFERENCES users(id),
      repeat_interval INTEGER DEFAULT 0, repeat_until TEXT, next_fire_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_reminders_user   ON task_reminders(user_id, status);
    CREATE INDEX IF NOT EXISTS idx_reminders_time   ON task_reminders(remind_at, status);
    CREATE INDEX IF NOT EXISTS idx_tasks_assigned  ON tasks(assigned_to);
    CREATE INDEX IF NOT EXISTS idx_tasks_status    ON tasks(status);
    CREATE INDEX IF NOT EXISTS idx_tasks_due       ON tasks(due_date);
    CREATE INDEX IF NOT EXISTS idx_notif_user      ON notifications(user_id, is_read);
    CREATE INDEX IF NOT EXISTS idx_history_task    ON task_history(task_id);
    CREATE INDEX IF NOT EXISTS idx_history_user    ON task_history(user_id);
    CREATE INDEX IF NOT EXISTS idx_activity_user   ON activity_log(user_id);
    CREATE INDEX IF NOT EXISTS idx_audit_user      ON audit_log(user_id);
  `);

  // Insert default branding if not exists
  const brand = dbWrapper.prepare('SELECT id FROM branding WHERE id=?').get('main');
  if (!brand) {
    dbWrapper.prepare(`INSERT INTO branding (id,company_name,updated_at) VALUES (?,?,?)`).run('main','TaskFlow', new Date().toISOString());
  }
}

function initDB() {
  return initSqlJs().then(SQL => {
    if (fs.existsSync(DB_FILE)) {
      try {
        const saved = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
        _db = new SQL.Database(Buffer.from(saved.data, 'base64'));
        console.log('📂 Loaded existing database');
      } catch { _db = new SQL.Database(); console.log('⚠ Fresh database'); }
    } else {
      _db = new SQL.Database();
      console.log('✨ New database');
    }
    initSchema();
    migrateSchema();
    migrateSchemaV4();
    migrateRemindersV6();
    seedDefaultCategories();
    return dbWrapper;
  });
}

module.exports = { initDB, db: dbWrapper, persist, seedDefaultCategories };

// Patch: run after initSchema to add default categories
function seedDefaultCategories() {
  try {
    const catCount = dbWrapper.prepare('SELECT COUNT(*) as c FROM categories').get().c;
    if (catCount === 0) {
      const now = new Date().toISOString().replace('T',' ').split('.')[0];
      const defs = [
        ['cat_mkt','Marketing','#f59e0b','📣'],['cat_dev','Development','#6366f1','💻'],
        ['cat_hr','Human Resources','#22c55e','👥'],['cat_sal','Sales','#14b8a6','💼'],
        ['cat_sup','Support','#06b6d4','🎧'],['cat_acc','Accounts','#8b5cf6','💰'],
        ['cat_ops','Operations','#f97316','⚙'],['cat_cs','Customer Service','#ec4899','🤝'],
        ['cat_hos','Hospitality','#e11d48','🏨'],['cat_ins','Installation','#64748b','🔧'],
      ];
      for (const [id,name,color,icon] of defs) {
        try { dbWrapper.prepare(`INSERT OR IGNORE INTO categories (id,name,color,icon,is_active,created_at,updated_at) VALUES (?,?,?,?,1,?,?)`).run(id,name,color,icon,now,now); } catch(e) {}
      }
    }
  } catch(e) {}
}

// Called after initSchema to ensure new tables exist on existing DBs
function migrateSchema() {
  try { _db.run('ALTER TABLE clock_sessions ADD COLUMN status TEXT DEFAULT "working"'); } catch {}
  try { _db.run('ALTER TABLE clock_sessions ADD COLUMN paused_at TEXT'); } catch {}
  try { _db.run('ALTER TABLE clock_sessions ADD COLUMN paused_minutes INTEGER DEFAULT 0'); } catch {}
  _db.run(`CREATE TABLE IF NOT EXISTS break_sessions (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL, clock_session_id TEXT,
    break_type TEXT DEFAULT 'break', started_at TEXT NOT NULL, ended_at TEXT,
    duration_minutes INTEGER, date TEXT NOT NULL, created_at TEXT NOT NULL
  )`);
  _db.run(`CREATE TABLE IF NOT EXISTS chat_messages (
    id TEXT PRIMARY KEY, sender_id TEXT NOT NULL, recipient_id TEXT,
    room TEXT NOT NULL DEFAULT 'general', content TEXT NOT NULL,
    msg_type TEXT DEFAULT 'text', is_read INTEGER DEFAULT 0,
    edited INTEGER DEFAULT 0, created_at TEXT NOT NULL
  )`);
  try { _db.run('CREATE INDEX IF NOT EXISTS idx_chat_room ON chat_messages(room, created_at)'); } catch {}
  try { _db.run('CREATE INDEX IF NOT EXISTS idx_chat_dm ON chat_messages(sender_id, recipient_id)'); } catch {}
  try { _db.run('CREATE INDEX IF NOT EXISTS idx_break_user ON break_sessions(user_id, date)'); } catch {}
  // Performance indexes
  try { _db.run('CREATE INDEX IF NOT EXISTS idx_notif_created ON notifications(user_id, created_at)'); } catch {}
  try { _db.run('CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks(due_date, status)'); } catch {}
  try { _db.run('CREATE INDEX IF NOT EXISTS idx_tasks_created ON tasks(created_at)'); } catch {}
  try { _db.run('CREATE INDEX IF NOT EXISTS idx_history_created ON task_history(created_at)'); } catch {}
  try { _db.run('CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at)'); } catch {}
  try { _db.run('PRAGMA journal_mode=WAL'); } catch {}
  try { _db.run('PRAGMA synchronous=NORMAL'); } catch {}
  try { _db.run('PRAGMA cache_size=4000'); } catch {}
}

// v4 migration — attachments
function migrateSchemaV4() {
  try {
    _db.run(`CREATE TABLE IF NOT EXISTS task_attachments (
      id TEXT PRIMARY KEY, task_id TEXT NOT NULL, uploaded_by TEXT NOT NULL,
      original_name TEXT NOT NULL, stored_name TEXT NOT NULL,
      file_size INTEGER NOT NULL, mime_type TEXT NOT NULL,
      file_path TEXT NOT NULL, created_at TEXT NOT NULL
    )`);
    _db.run('CREATE INDEX IF NOT EXISTS idx_attach_task ON task_attachments(task_id)');
    _db.run(`CREATE TABLE IF NOT EXISTS chat_attachments (
      id TEXT PRIMARY KEY, message_id TEXT NOT NULL,
      original_name TEXT NOT NULL, stored_name TEXT NOT NULL,
      file_size INTEGER NOT NULL, mime_type TEXT NOT NULL,
      file_path TEXT NOT NULL, created_at TEXT NOT NULL
    )`);
    _db.run('CREATE INDEX IF NOT EXISTS idx_chatatt_msg ON chat_attachments(message_id)');
  } catch(e) {}
}

// v6 migration — reminders: ensure all columns exist AND make task_id optional.
// (The previous "v5" statements ran at module-load time when _db was still null,
//  so they silently did nothing on a fresh database. This runs inside initDB.)
function migrateRemindersV6() {
  try {
    // 1) Ensure every reminder column exists (idempotent — safe on already-migrated DBs)
    try { _db.run("ALTER TABLE task_reminders ADD COLUMN sound_tone TEXT DEFAULT 'bell'"); } catch {}
    try { _db.run('ALTER TABLE task_reminders ADD COLUMN target_user_id TEXT REFERENCES users(id)'); } catch {}
    try { _db.run('ALTER TABLE task_reminders ADD COLUMN repeat_interval INTEGER DEFAULT 0'); } catch {}
    try { _db.run('ALTER TABLE task_reminders ADD COLUMN repeat_until TEXT'); } catch {}
    try { _db.run('ALTER TABLE task_reminders ADD COLUMN next_fire_at TEXT'); } catch {}

    // 2) Detect whether task_id is still declared NOT NULL on this (older) database
    let taskIdNotNull = false;
    const info = _db.exec('PRAGMA table_info(task_reminders)');
    if (info && info[0]) {
      for (const row of info[0].values) {
        // columns: [cid, name, type, notnull, dflt_value, pk]
        if (row[1] === 'task_id' && row[3] === 1) taskIdNotNull = true;
      }
    }
    if (!taskIdNotNull) return; // already optional — nothing to do

    // 3) Rebuild the table with task_id nullable (SQLite can't drop NOT NULL in place).
    //    Reminders without a task are now first-class, so task_id must allow NULL.
    _db.run('PRAGMA foreign_keys=OFF');
    _db.run(`CREATE TABLE task_reminders__new (
      id TEXT PRIMARY KEY, task_id TEXT REFERENCES tasks(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      remind_at TEXT NOT NULL, timezone TEXT NOT NULL DEFAULT 'IST',
      note TEXT, status TEXT NOT NULL DEFAULT 'pending',
      snoozed_until TEXT, fired_at TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      sound_tone TEXT DEFAULT 'bell',
      target_user_id TEXT REFERENCES users(id),
      repeat_interval INTEGER DEFAULT 0, repeat_until TEXT, next_fire_at TEXT
    )`);
    _db.run(`INSERT INTO task_reminders__new
      (id,task_id,user_id,remind_at,timezone,note,status,snoozed_until,fired_at,
       created_at,updated_at,sound_tone,target_user_id,repeat_interval,repeat_until,next_fire_at)
      SELECT id,task_id,user_id,remind_at,timezone,note,status,snoozed_until,fired_at,
       created_at,updated_at,sound_tone,target_user_id,repeat_interval,repeat_until,next_fire_at
      FROM task_reminders`);
    _db.run('DROP TABLE task_reminders');
    _db.run('ALTER TABLE task_reminders__new RENAME TO task_reminders');
    _db.run('CREATE INDEX IF NOT EXISTS idx_reminders_user ON task_reminders(user_id, status)');
    _db.run('CREATE INDEX IF NOT EXISTS idx_reminders_time ON task_reminders(remind_at, status)');
    _db.run('PRAGMA foreign_keys=ON');
    console.log('✅ Migrated task_reminders: task_id is now optional');
  } catch (e) {
    console.error('[reminders] migrateRemindersV6:', e.message);
  }
}

module.exports.migrateSchemaV4 = migrateSchemaV4;
