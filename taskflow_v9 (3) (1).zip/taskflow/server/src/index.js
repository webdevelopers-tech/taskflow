require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const { WebSocketServer } = require('ws');
const jwt = require('jsonwebtoken');
const path = require('path');
const { initDB } = require('./db/database');
const { setWSS } = require('./utils/websocket');
const { startReminderJob } = require('./utils/reminders');
const { JWT_SECRET } = require('./middleware/auth');

const PORT = process.env.PORT || 3001;
const fs = require('fs');
const UPLOAD_BASE = require('path').join(__dirname, '../uploads');
fs.mkdirSync(require('path').join(UPLOAD_BASE,'tasks'),{recursive:true});
fs.mkdirSync(require('path').join(UPLOAD_BASE,'chat'),{recursive:true});

async function startServer() {
  // Init DB first
  await initDB();
  console.log('✅ Database ready');

  const app = express();
  const server = http.createServer(app);

  app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
  app.use(cors({
    origin: process.env.FRONTEND_URL || ['http://localhost:5173', 'http://localhost:3000'],
    credentials: true
  }));
  app.use(morgan('dev'));
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: true }));

  const limiter     = rateLimit({ windowMs: 15*60*1000, max: 2000, standardHeaders:true, legacyHeaders:false });
  const authLimiter = rateLimit({ windowMs: 15*60*1000, max: 50,   standardHeaders:true, legacyHeaders:false });
  app.use('/api/', limiter);
  app.use('/api/auth/login', authLimiter);

  // Routes - loaded after DB is ready
  app.use('/api/auth',           require('./routes/auth'));
  app.use('/api/tasks',          require('./routes/tasks'));
  app.use('/api/users',          require('./routes/users'));
  app.use('/api/categories',     require('./routes/categories'));
  app.use('/api/attachments',    require('./routes/attachments'));
  // Serve uploaded files (auth handled per-route for downloads)
  const uploadPath = require('path').join(__dirname, '../uploads');
  app.use('/uploads', require('./middleware/auth').authenticate, require('express').static(uploadPath));
  app.use('/api/task-reminders', require('./routes/taskreminders'));
  app.use('/api',                require('./routes/misc'));

  app.get('/api/health', (req, res) => res.json({ status:'ok', version:'1.0.0', ts: new Date().toISOString() }));

  // Serve built frontend in production
  if (process.env.NODE_ENV === 'production') {
    const DIST = path.join(__dirname, '../../client/dist');
    app.use(express.static(DIST));
    app.get('*', (req, res) => {
      if (!req.path.startsWith('/api') && !req.path.startsWith('/uploads'))
        res.sendFile(path.join(DIST, 'index.html'));
    });
  }

  app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
  });

  // WebSocket
  const wss = new WebSocketServer({ server, path: '/ws' });
  setWSS(wss);
  wss.on('connection', (ws, req) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const token = url.searchParams.get('token');
      if (token) {
        const dec = jwt.verify(token, JWT_SECRET);
        ws.userId = dec.userId;
      }
    } catch {}
    ws.on('message', data => {
      try { const m = JSON.parse(data); if (m.type==='ping') ws.send(JSON.stringify({type:'pong'})); } catch {}
    });
    ws.send(JSON.stringify({ type:'connected', message:'TaskFlow ready' }));
  });

  server.listen(PORT, () => {
    console.log(`\n🚀 TaskFlow API  →  http://localhost:${PORT}`);
    console.log(`📡 WebSocket     →  ws://localhost:${PORT}/ws`);
    console.log(`🌱 Env: ${process.env.NODE_ENV || 'development'}\n`);
    startReminderJob();
  });
}

startServer().catch(err => { console.error('Failed to start server:', err); process.exit(1); });
