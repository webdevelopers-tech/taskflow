const { v4: uuidv4 } = require('uuid');
const db = require('../db/database').db;
const { sendToUser } = require('./websocket');

// ===== OVERDUE TASK NOTIFICATIONS (hourly) =====
function checkOverdueTasks() {
  const today = new Date().toISOString().split('T')[0];
  try {
    const tasks = db.prepare(`
      SELECT t.*, u.id as assignee_id, u.name as assignee_name
      FROM tasks t JOIN users u ON t.assigned_to = u.id
      WHERE t.status != 'closed' AND t.due_date < ? AND u.is_active = 1
    `).all(today);

    for (const task of tasks) {
      const recent = db.prepare(`
        SELECT id FROM notifications
        WHERE user_id=? AND task_id=? AND category='task_overdue'
          AND created_at > datetime('now','-24 hours')
      `).get(task.assignee_id, task.id);
      if (recent) continue;

      const id  = uuidv4();
      const now = new Date().toISOString().replace('T',' ').split('.')[0];
      db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,task_id,is_read,created_at) VALUES (?,?,?,?,?,?,?,0,?)`)
        .run(id, task.assignee_id, '🔴 Task Overdue',
          `"${task.title}" is overdue (due ${task.due_date})`, 'error', 'task_overdue', task.id, now);
      sendToUser(task.assignee_id, {
        type: 'notification:new',
        notification: { id, user_id: task.assignee_id, title: '🔴 Task Overdue',
          message: `"${task.title}" is overdue`, type: 'error', category: 'task_overdue', task_id: task.id, is_read: 0, created_at: now }
      });
    }
  } catch(e) { console.error('[reminders] checkOverdueTasks:', e.message); }
}

// ===== USER-SET REMINDERS with REPEAT support (every minute) =====
function checkTaskReminders() {
  try {
    const now = new Date().toISOString().replace('T',' ').split('.')[0];

    // Get all pending reminders that are due now
    const due = db.prepare(`
      SELECT r.id, r.task_id, r.user_id, r.target_user_id,
             r.note, r.remind_at, r.timezone, r.sound_tone,
             r.repeat_interval, r.repeat_until, r.next_fire_at,
             t.title as task_title, t.priority, t.status as task_status,
             t.due_date as task_due_date
      FROM task_reminders r
      LEFT JOIN tasks t ON r.task_id = t.id
      WHERE r.status = 'pending'
        AND (r.next_fire_at IS NOT NULL AND r.next_fire_at <= ? OR r.remind_at <= ? AND r.next_fire_at IS NULL)
    `).all(now, now);

    for (const r of due) {
      // Skip if the task is already closed
      if (r.task_status === 'closed') {
        db.prepare("UPDATE task_reminders SET status='completed', fired_at=? WHERE id=?").run(now, r.id);
        continue;
      }

      // Determine recipient
      const recipientId = r.target_user_id || r.user_id;

      // Check if repeat_until has passed
      const repeatDone = r.repeat_until && r.repeat_until <= now;

      if (r.repeat_interval && r.repeat_interval > 0 && !repeatDone) {
        // REPEATING: schedule next fire, keep status=pending
        const nextFire = new Date(Date.now() + r.repeat_interval * 60000)
          .toISOString().replace('T',' ').split('.')[0];
        db.prepare("UPDATE task_reminders SET next_fire_at=? WHERE id=?").run(nextFire, r.id);
      } else if (r.repeat_interval && r.repeat_interval > 0 && repeatDone) {
        // Repeat period ended — mark fired
        db.prepare("UPDATE task_reminders SET status='fired', fired_at=? WHERE id=?").run(now, r.id);
      } else {
        // One-time reminder — mark fired
        db.prepare("UPDATE task_reminders SET status='fired', fired_at=?, next_fire_at=? WHERE id=?").run(now, now, r.id);
      }

      // Insert notification for recipient
      const notifId = uuidv4();
      const repeatLabel = r.repeat_interval > 0 ? ` (repeating every ${r.repeat_interval >= 60 ? Math.round(r.repeat_interval/60)+'h' : r.repeat_interval+'m'})` : '';
      const reminderTitle = r.task_title ? ('⏰ Reminder: ' + r.task_title) : '⏰ Reminder';
      const reminderBody  = r.note || (r.task_title ? `Reminder for "${r.task_title}"` : 'You have a reminder');
      db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,task_id,is_read,created_at) VALUES (?,?,?,?,?,?,?,0,?)`)
        .run(notifId, recipientId,
          reminderTitle,
          reminderBody + repeatLabel,
          'warning', 'task_reminder', r.task_id || null, now);

      const wsPayload = {
        type: 'reminder:fire',
        reminder: {
          id: r.id,
          task_id: r.task_id,
          task_title: r.task_title,
          task_status: r.task_status,
          task_due_date: r.task_due_date,
          note: r.note,
          remind_at: r.remind_at,
          timezone: r.timezone,
          sound_tone: r.sound_tone || 'alert',
          repeat_interval: r.repeat_interval || 0,
          repeat_until: r.repeat_until,
          priority: r.priority,
        }
      };

      // Send to recipient
      sendToUser(recipientId, wsPayload);

      // If creator != recipient, notify creator that it fired
      if (r.user_id !== recipientId) {
        const creatorNotifId = uuidv4();
        const firedSubject = r.task_title ? `"${r.task_title}"` : (r.note ? `"${r.note}"` : 'your reminder');
        db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,task_id,is_read,created_at) VALUES (?,?,?,?,?,?,?,0,?)`)
          .run(creatorNotifId, r.user_id, '📬 Reminder Fired',
            `Reminder for ${firedSubject} was sent to the assigned employee`,
            'info', 'task_reminder', r.task_id || null, now);
        sendToUser(r.user_id, {
          type: 'notification:new',
          notification: { id: creatorNotifId, user_id: r.user_id, title: '📬 Reminder Fired',
            message: `Reminder for ${firedSubject} was delivered`, type: 'info',
            category: 'task_reminder', task_id: r.task_id || null, is_read: 0, created_at: now }
        });
      }
    }

    // Wake snoozed reminders whose snooze has expired
    db.prepare("UPDATE task_reminders SET status='pending', snoozed_until=NULL WHERE status='snoozed' AND snoozed_until <= ?").run(now);

    // Auto-complete reminders for tasks that got closed
    db.prepare(`
      UPDATE task_reminders SET status='completed', fired_at=?
      WHERE status IN ('pending','snoozed')
        AND task_id IN (SELECT id FROM tasks WHERE status='closed')
    `).run(now);

  } catch(e) { console.error('[reminders] checkTaskReminders:', e.message); }
}

// ===== CHAT CLEANUP (daily) =====
function cleanupOldChatMessages() {
  try {
    const cutoff = new Date(Date.now() - 7*24*3600000).toISOString().replace('T',' ').split('.')[0];
    const result = db.prepare("DELETE FROM chat_messages WHERE created_at < ?").run(cutoff);
    if (result.changes > 0) console.log(`🧹 Cleaned ${result.changes} old chat messages`);
  } catch(e) { console.error('[reminders] cleanupOldChatMessages:', e.message); }
}

function startReminderJob() {
  checkOverdueTasks();
  checkTaskReminders();
  cleanupOldChatMessages();
  setInterval(checkOverdueTasks,      60 * 60 * 1000);
  setInterval(checkTaskReminders,     60 * 1000);        // every minute
  setInterval(cleanupOldChatMessages, 24 * 60 * 60 * 1000);
  console.log('⏰ Reminder job started (repeating reminders supported)');
}

module.exports = { startReminderJob };
