// Timezone helpers - only IST and CST
const TIMEZONES = {
  IST: 'Asia/Kolkata',
  CST: 'America/Chicago'
};

function nowISO() {
  return new Date().toISOString().replace('T', ' ').split('.')[0];
}

function todayStr() {
  return new Date().toISOString().split('T')[0];
}

// Format timestamp for display in a given tz
function formatInTZ(isoStr, tz = 'IST') {
  const tzName = TIMEZONES[tz] || TIMEZONES.IST;
  return new Date(isoStr).toLocaleString('en-US', { timeZone: tzName, dateStyle: 'medium', timeStyle: 'short' });
}

// Log notification to all related users of a task
function notifyTaskEvent(db, task, title, message, type, category, actingUserId, broadcast) {
  const { v4: uuidv4 } = require('uuid');
  const recipients = new Set();
  if (task.assigned_to && task.assigned_to !== actingUserId) recipients.add(task.assigned_to);
  if (task.assigned_by && task.assigned_by !== actingUserId) recipients.add(task.assigned_by);

  for (const uid of recipients) {
    const id = uuidv4();
    db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,task_id,is_read,created_at) VALUES (?,?,?,?,?,?,?,0,?)`)
      .run(id, uid, title, message, type, category, task.id, nowISO());

    if (broadcast) {
      broadcast({
        type: 'notification:new',
        notification: { id, user_id: uid, title, message, type, category, task_id: task.id, is_read: 0, created_at: nowISO() }
      }, uid);
    }
  }
}

// Log task history entry
function logHistory(db, taskId, userId, action, fieldName, oldVal, newVal) {
  const { v4: uuidv4 } = require('uuid');
  db.prepare(`INSERT INTO task_history (id,task_id,user_id,action,field_name,old_value,new_value,created_at) VALUES (?,?,?,?,?,?,?,?)`)
    .run(uuidv4(), taskId, userId, action, fieldName || null, oldVal || null, newVal || null, nowISO());
}

// Log audit entry
function logAudit(db, userId, action, entity, entityId, oldData, newData, req) {
  const { v4: uuidv4 } = require('uuid');
  db.prepare(`INSERT INTO audit_log (id,user_id,action,entity,entity_id,old_data,new_data,ip_address,user_agent,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(uuidv4(), userId, action, entity, entityId || null,
      oldData ? JSON.stringify(oldData) : null,
      newData ? JSON.stringify(newData) : null,
      req?.ip || null, req?.headers?.['user-agent']?.slice(0, 200) || null, nowISO());
}

// Log activity
function logActivity(db, userId, action, entity, entityId, meta) {
  const { v4: uuidv4 } = require('uuid');
  db.prepare(`INSERT INTO activity_log (id,user_id,action,entity,entity_id,meta,created_at) VALUES (?,?,?,?,?,?,?)`)
    .run(uuidv4(), userId, action, entity || null, entityId || null, meta || null, nowISO());
}

module.exports = { nowISO, todayStr, formatInTZ, notifyTaskEvent, logHistory, logAudit, logActivity, TIMEZONES };
