let wss = null;
function setWSS(s) { wss = s; }
function broadcast(data, excludeUserId=null) {
  if (!wss) return;
  const msg = JSON.stringify(data);
  wss.clients.forEach(c => {
    if (c.readyState===1 && (!excludeUserId || c.userId!==excludeUserId)) {
      try { c.send(msg); } catch {}
    }
  });
}
function sendToUser(userId, data) {
  if (!wss) return;
  const msg = JSON.stringify(data);
  wss.clients.forEach(c => {
    if (c.readyState===1 && c.userId===userId) { try { c.send(msg); } catch {} }
  });
}
module.exports = { setWSS, broadcast, sendToUser };
