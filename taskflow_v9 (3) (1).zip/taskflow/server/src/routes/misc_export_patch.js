// This patch fixes export endpoints to read auth from header properly
