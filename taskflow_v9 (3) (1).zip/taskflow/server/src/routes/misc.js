const router = require('express').Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../db/database');
const { authenticate, requireAdmin, authenticateExport } = require('../middleware/auth');
const { broadcast, sendToUser } = require('../utils/websocket');
const { nowISO, todayStr, logActivity, logAudit } = require('../utils/helpers');

// ===== CLOCK =====
router.post('/clock/in', authenticate, (req, res) => {
  const today = todayStr();
  if (db.prepare("SELECT id FROM clock_sessions WHERE user_id=? AND date=? AND clock_out IS NULL").get(req.user.id, today))
    return res.status(400).json({ error: 'Already clocked in' });
  const id = uuidv4(); const now = nowISO();
  db.prepare(`INSERT INTO clock_sessions (id,user_id,clock_in,date,note,status,paused_minutes,created_at) VALUES (?,?,?,?,?,?,?,?)`)
    .run(id, req.user.id, now, today, req.body.note||null, 'working', 0, now);
  logActivity(db, req.user.id, 'clocked in', 'session', id, null);
  broadcast({ type: 'user:status', userId: req.user.id, userName: req.user.name, status: 'working' });
  res.status(201).json(db.prepare('SELECT * FROM clock_sessions WHERE id=?').get(id));
});

router.post('/clock/out', authenticate, (req, res) => {
  const today = todayStr();
  const session = db.prepare("SELECT * FROM clock_sessions WHERE user_id=? AND date=? AND clock_out IS NULL").get(req.user.id, today);
  if (!session) return res.status(400).json({ error: 'Not clocked in' });
  // End any active break first
  const activeBreak = db.prepare("SELECT * FROM break_sessions WHERE user_id=? AND date=? AND ended_at IS NULL").get(req.user.id, today);
  if (activeBreak) {
    const bm = Math.round((new Date()-new Date(activeBreak.started_at.replace(' ','T')+'Z'))/60000);
    db.prepare("UPDATE break_sessions SET ended_at=?,duration_minutes=? WHERE id=?").run(nowISO(), bm, activeBreak.id);
  }
  const now = new Date();
  const totalMins = Math.round((now - new Date(session.clock_in.replace(' ','T')+'Z'))/60000);
  const pausedMins = session.paused_minutes || 0;
  const workMins   = Math.max(0, totalMins - pausedMins);
  db.prepare("UPDATE clock_sessions SET clock_out=?,duration_minutes=?,status=? WHERE id=?").run(nowISO(), workMins, 'clocked-out', session.id);
  logActivity(db, req.user.id, 'clocked out', 'session', session.id, `${Math.floor(workMins/60)}h${workMins%60}m`);
  broadcast({ type: 'user:status', userId: req.user.id, userName: req.user.name, status: 'offline' });
  res.json(db.prepare('SELECT * FROM clock_sessions WHERE id=?').get(session.id));
});

router.post('/clock/pause', authenticate, (req, res) => {
  const today = todayStr();
  const session = db.prepare("SELECT * FROM clock_sessions WHERE user_id=? AND date=? AND clock_out IS NULL").get(req.user.id, today);
  if (!session) return res.status(400).json({ error: 'Not clocked in' });
  if (session.status === 'paused') return res.status(400).json({ error: 'Already paused' });
  const now = nowISO();
  db.prepare("UPDATE clock_sessions SET status='paused', paused_at=? WHERE id=?").run(now, session.id);
  broadcast({ type: 'user:status', userId: req.user.id, userName: req.user.name, status: 'paused' });
  res.json({ ok: true, status: 'paused' });
});

router.post('/clock/resume', authenticate, (req, res) => {
  const today = todayStr();
  const session = db.prepare("SELECT * FROM clock_sessions WHERE user_id=? AND date=? AND clock_out IS NULL").get(req.user.id, today);
  if (!session) return res.status(400).json({ error: 'Not clocked in' });
  if (session.status !== 'paused' && session.status !== 'on-break') return res.status(400).json({ error: 'Not paused' });
  // Calculate paused duration and add to paused_minutes
  let addedPause = 0;
  if (session.paused_at) {
    addedPause = Math.round((new Date()-new Date(session.paused_at.replace(' ','T')+'Z'))/60000);
  }
  const newPausedMins = (session.paused_minutes||0) + addedPause;
  db.prepare("UPDATE clock_sessions SET status='working', paused_at=NULL, paused_minutes=? WHERE id=?").run(newPausedMins, session.id);
  // End active break if any
  const activeBreak = db.prepare("SELECT * FROM break_sessions WHERE user_id=? AND date=? AND ended_at IS NULL").get(req.user.id, today);
  if (activeBreak) {
    const bm = Math.round((new Date()-new Date(activeBreak.started_at.replace(' ','T')+'Z'))/60000);
    db.prepare("UPDATE break_sessions SET ended_at=?,duration_minutes=? WHERE id=?").run(nowISO(), bm, activeBreak.id);
  }
  broadcast({ type: 'user:status', userId: req.user.id, userName: req.user.name, status: 'working' });
  res.json({ ok: true, status: 'working', addedPausedMins: addedPause });
});

router.post('/clock/break', authenticate, (req, res) => {
  const today = todayStr();
  const session = db.prepare("SELECT * FROM clock_sessions WHERE user_id=? AND date=? AND clock_out IS NULL").get(req.user.id, today);
  if (!session) return res.status(400).json({ error: 'Not clocked in' });
  const breakType = req.body.break_type || 'break'; // 'break', 'lunch'
  const now = nowISO();
  const id = uuidv4();
  db.prepare(`INSERT INTO break_sessions (id,user_id,clock_session_id,break_type,started_at,date,created_at) VALUES (?,?,?,?,?,?,?)`)
    .run(id, req.user.id, session.id, breakType, now, today, now);
  db.prepare("UPDATE clock_sessions SET status='on-break', paused_at=? WHERE id=?").run(now, session.id);
  broadcast({ type: 'user:status', userId: req.user.id, userName: req.user.name, status: 'on-break' });
  res.json({ ok: true, status: 'on-break', break_id: id });
});

router.get('/clock/today', authenticate, (req, res) => {
  const today = todayStr();
  const session = db.prepare("SELECT * FROM clock_sessions WHERE user_id=? AND date=? AND clock_out IS NULL ORDER BY clock_in DESC").get(req.user.id, today);
  const totalMins = db.prepare("SELECT SUM(duration_minutes) as mins FROM clock_sessions WHERE user_id=? AND date=?").get(req.user.id, today);
  const breaks = db.prepare("SELECT * FROM break_sessions WHERE user_id=? AND date=? ORDER BY started_at").all(req.user.id, today);
  const activeBreak = breaks.find(b=>!b.ended_at)||null;
  res.json({ session: session||null, totalMinutesToday: totalMins?.mins||0, breaks, activeBreak });
});

router.get('/clock/history', authenticate, (req, res) => {
  const userId = req.query.user_id && req.user.is_admin ? req.query.user_id : req.user.id;
  const sessions = db.prepare(`SELECT cs.*, u.name as user_name FROM clock_sessions cs JOIN users u ON cs.user_id=u.id WHERE cs.user_id=? ORDER BY cs.clock_in DESC LIMIT ?`).all(userId, parseInt(req.query.limit)||30);
  res.json(sessions);
});

router.get('/clock/team', authenticate, (req, res) => {
  const today = todayStr();
  res.json(db.prepare(`SELECT u.id,u.name,u.color,u.role,u.timezone,
    cs.clock_in,cs.clock_out,cs.duration_minutes,cs.status as work_status,
    CASE WHEN cs.clock_out IS NULL AND cs.date=? THEN 1 ELSE 0 END as is_active
    FROM users u LEFT JOIN clock_sessions cs ON u.id=cs.user_id AND cs.date=?
    WHERE u.is_active=1 ORDER BY u.name`).all(today, today));
});


// ===== NOTIFICATIONS =====
router.get('/notifications', authenticate, (req, res) => {
  const { category, task_id, is_read, limit=50, search } = req.query;
  let where = ['user_id=?']; const params = [req.user.id];
  if (category) { where.push('category=?'); params.push(category); }
  if (task_id)  { where.push('task_id=?');  params.push(task_id); }
  if (is_read !== undefined) { where.push('is_read=?'); params.push(parseInt(is_read)); }
  if (search) { where.push('(title LIKE ? OR message LIKE ?)'); params.push(`%${search}%`,`%${search}%`); }
  params.push(parseInt(limit));
  const notifications = db.prepare(`SELECT * FROM notifications WHERE ${where.join(' AND ')} ORDER BY created_at DESC LIMIT ?`).all(...params);
  const unread = db.prepare("SELECT COUNT(*) as c FROM notifications WHERE user_id=? AND is_read=0").get(req.user.id).c;
  res.json({ notifications, unread });
});

router.put('/notifications/:id/read', authenticate, (req, res) => {
  db.prepare("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?").run(req.params.id, req.user.id);
  res.json({ ok: true });
});

router.put('/notifications/read-all', authenticate, (req, res) => {
  db.prepare("UPDATE notifications SET is_read=1 WHERE user_id=?").run(req.user.id);
  res.json({ ok: true });
});

router.delete('/notifications/:id', authenticate, (req, res) => {
  db.prepare("DELETE FROM notifications WHERE id=? AND user_id=?").run(req.params.id, req.user.id);
  res.json({ ok: true });
});

router.delete('/notifications/clear-all', authenticate, (req, res) => {
  db.prepare("DELETE FROM notifications WHERE user_id=? AND is_read=1").run(req.user.id);
  res.json({ ok: true });
});

// ===== ACTIVITY =====
router.get('/activity', authenticate, (req, res) => {
  const mine = req.query.mine === 'true';
  const limit = parseInt(req.query.limit)||20;
  const sql = mine
    ? `SELECT al.*,u.name as user_name,u.color as user_color FROM activity_log al JOIN users u ON al.user_id=u.id WHERE al.user_id=? ORDER BY al.created_at DESC LIMIT ?`
    : `SELECT al.*,u.name as user_name,u.color as user_color FROM activity_log al JOIN users u ON al.user_id=u.id ORDER BY al.created_at DESC LIMIT ?`;
  res.json(db.prepare(sql).all(...(mine ? [req.user.id, limit] : [limit])));
});

// ===== TASK HISTORY =====
router.get('/history', authenticate, (req, res) => {
  const { user_id, task_id, action, date_from, date_to, limit=100 } = req.query;
  let where=['1=1']; const params=[];
  if (user_id)  { where.push('th.user_id=?');  params.push(user_id); }
  if (task_id)  { where.push('th.task_id=?');  params.push(task_id); }
  if (action)   { where.push('th.action=?');   params.push(action); }
  if (date_from){ where.push('th.created_at>=?'); params.push(date_from); }
  if (date_to)  { where.push('th.created_at<=?'); params.push(date_to+' 23:59:59'); }
  params.push(parseInt(limit));
  res.json(db.prepare(`SELECT th.*,u.name as user_name,u.color as user_color,u.department,t.title as task_title
    FROM task_history th JOIN users u ON th.user_id=u.id LEFT JOIN tasks t ON th.task_id=t.id
    WHERE ${where.join(' AND ')} ORDER BY th.created_at DESC LIMIT ?`).all(...params));
});

// ===== EMPLOYEE ANALYTICS =====
router.get('/analytics/employees', authenticate, (req, res) => {
  const { department, date_from, date_to } = req.query;
  const today = todayStr();
  let taskWhere = '1=1'; const taskParams = [];
  if (date_from) { taskWhere += ' AND t.created_at>=?'; taskParams.push(date_from); }
  if (date_to)   { taskWhere += ' AND t.created_at<=?'; taskParams.push(date_to+' 23:59:59'); }

  let userWhere = 'u.is_active=1';
  if (department) { userWhere += ` AND u.department='${department.replace(/'/g,"''")}'`; }

  const employees = db.prepare(`
    SELECT u.id, u.name, u.email, u.role, u.department, u.color, u.timezone, u.last_login,
      COUNT(DISTINCT t.id) as total_assigned,
      SUM(CASE WHEN t.status='closed' THEN 1 ELSE 0 END) as total_closed,
      SUM(CASE WHEN t.status='pending' THEN 1 ELSE 0 END) as pending,
      SUM(CASE WHEN t.status='in-progress' THEN 1 ELSE 0 END) as in_progress,
      SUM(CASE WHEN t.status NOT IN('closed') AND t.due_date < '${today}' THEN 1 ELSE 0 END) as overdue,
      ROUND(SUM(CASE WHEN t.status='closed' AND t.completed_at IS NOT NULL THEN
        CAST((julianday(t.completed_at) - julianday(t.created_at)) AS REAL) ELSE NULL END),1) as avg_days_to_close,
      COALESCE(ROUND(SUM(CASE WHEN t.status='closed' THEN 1.0 ELSE 0 END)*100.0/NULLIF(COUNT(t.id),0),1),0) as completion_rate,
      SUM(DISTINCT cs.duration_minutes) as total_minutes_logged
    FROM users u
    LEFT JOIN tasks t ON u.id=t.assigned_to AND ${taskWhere}
    LEFT JOIN clock_sessions cs ON u.id=cs.user_id AND cs.clock_out IS NOT NULL
    WHERE ${userWhere}
    GROUP BY u.id ORDER BY total_closed DESC`).all(...taskParams);
  res.json(employees);
});

// ===== PRODUCTIVITY REPORT =====
router.get('/productivity/report', authenticate, (req, res) => {
  const { period, date_from, date_to } = req.query;
  let since, until;
  if (date_from && date_to) {
    since = `'${date_from}'`;
    until = `'${date_to}'`;
  } else {
    const days = period==='month'?30 : period==='today'?0 : period==='yesterday'?1 : 7;
    if (period==='yesterday') { since=`date('now','-1 day')`; until=`date('now','-1 day')`; }
    else { since=`date('now','-${days} days')`; until=`date('now')`; }
  }
  const userStats = db.prepare(`SELECT u.id,u.name,u.color,u.role,u.department,
    COUNT(t.id) as assigned, SUM(CASE WHEN t.status='closed' THEN 1 ELSE 0 END) as closed,
    SUM(CASE WHEN t.status NOT IN('closed') AND t.due_date<date('now') THEN 1 ELSE 0 END) as overdue,
    ROUND(SUM(cs.duration_minutes)/60.0,1) as hours_worked
    FROM users u LEFT JOIN tasks t ON u.id=t.assigned_to AND t.created_at>=${since}
    LEFT JOIN clock_sessions cs ON u.id=cs.user_id AND cs.date>=${since} AND cs.date<=${until} AND cs.clock_out IS NOT NULL
    WHERE u.is_active=1 GROUP BY u.id`).all();
  const deptStats = db.prepare(`SELECT u.department,COUNT(DISTINCT u.id) as members,COUNT(t.id) as tasks,
    SUM(CASE WHEN t.status='closed' THEN 1 ELSE 0 END) as closed
    FROM users u LEFT JOIN tasks t ON u.id=t.assigned_to WHERE u.is_active=1 GROUP BY u.department`).all();
  res.json({ userStats, deptStats });
});

// ===== AUDIT LOG (admin only) =====
router.get('/audit', authenticate, requireAdmin, (req, res) => {
  const { user_id, entity, action, date_from, date_to, limit=200 } = req.query;
  let where=['1=1']; const params=[];
  if (user_id)  { where.push('al.user_id=?'); params.push(user_id); }
  if (entity)   { where.push('al.entity=?');  params.push(entity); }
  if (action)   { where.push('al.action=?');  params.push(action); }
  if (date_from){ where.push('al.created_at>=?'); params.push(date_from); }
  if (date_to)  { where.push('al.created_at<=?'); params.push(date_to+' 23:59:59'); }
  params.push(parseInt(limit));
  res.json(db.prepare(`SELECT al.*,u.name as user_name,u.department FROM audit_log al
    JOIN users u ON al.user_id=u.id WHERE ${where.join(' AND ')}
    ORDER BY al.created_at DESC LIMIT ?`).all(...params));
});

// ===== BRANDING =====
router.get('/branding', (req, res) => {
  res.json(db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {});
});

router.put('/branding', authenticate, requireAdmin, (req, res) => {
  const fields = ['company_name','logo_url','favicon_url','primary_color','secondary_color','accent_color',
    'sidebar_color','header_color','font_family','tagline','footer_text','login_bg_color','login_logo_text'];
  const updates = {}; for (const f of fields) if (req.body[f]!==undefined) updates[f]=req.body[f];
  updates.updated_at = nowISO();
  const set = Object.keys(updates).map(k=>`${k}=?`).join(',');
  db.prepare(`UPDATE branding SET ${set} WHERE id=?`).run(...Object.values(updates), 'main');
  logAudit(db, req.user.id, 'UPDATE', 'branding', 'main', null, updates, req);
  res.json(db.prepare('SELECT * FROM branding WHERE id=?').get('main'));
});

// ===== EXCEL EXPORTS =====
router.get('/export/tasks', authenticateExport, requireAdmin, async (req, res) => {
  const ExcelJS = require('exceljs');
  const { date_from, date_to, user_id, status, department } = req.query;
  const brand = db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {};

  let where=['1=1']; const params=[];
  if (status)    { where.push('t.status=?'); params.push(status); }
  if (user_id)   { where.push('t.assigned_to=?'); params.push(user_id); }
  if (department){ where.push('a.department=?'); params.push(department); }
  if (date_from) { where.push('t.created_at>=?'); params.push(date_from); }
  if (date_to)   { where.push('t.created_at<=?'); params.push(date_to+' 23:59:59'); }

  const tasks = db.prepare(`SELECT t.*,a.name as assignee,a.department,b.name as created_by
    FROM tasks t LEFT JOIN users a ON t.assigned_to=a.id LEFT JOIN users b ON t.assigned_by=b.id
    WHERE ${where.join(' AND ')} ORDER BY t.created_at DESC`).all(...params);

  const wb = new ExcelJS.Workbook();
  wb.creator = brand.company_name || 'TaskFlow';
  const ws = wb.addWorksheet('Tasks', { pageSetup: { paperSize: 9, orientation: 'landscape' } });

  // Title row
  ws.mergeCells('A1:J1');
  ws.getCell('A1').value = `${brand.company_name || 'TaskFlow'} — Task Report`;
  ws.getCell('A1').font = { bold: true, size: 16, color: { argb: 'FFFFFFFF' } };
  ws.getCell('A1').fill = { type:'pattern', pattern:'solid', fgColor: { argb: 'FF' + (brand.primary_color||'#6366f1').replace('#','') } };
  ws.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(1).height = 36;

  ws.mergeCells('A2:J2');
  ws.getCell('A2').value = `Exported: ${new Date().toLocaleDateString()} | Total: ${tasks.length} tasks`;
  ws.getCell('A2').font = { size: 11, italic: true };
  ws.getCell('A2').alignment = { horizontal: 'center' };
  ws.getRow(2).height = 22;

  // Header
  const headers = ['#','Task ID','Title','Assignee','Department','Priority','Status','Category','Due Date','Created'];
  const headerRow = ws.addRow(headers);
  headerRow.eachCell(cell => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type:'pattern', pattern:'solid', fgColor: { argb: 'FF334155' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = { bottom: { style:'thin', color: { argb: 'FF475569' } } };
  });
  ws.getRow(3).height = 26;

  const statusColors = { closed:'FFbbf7d0', pending:'FFfef9c3', 'in-progress':'FFbfdbfe' };
  const priorityColors = { high:'FFfecaca', medium:'FFfed7aa', low:'FFd1fae5' };

  tasks.forEach((t, i) => {
    const row = ws.addRow([
      i+1, t.id, t.title, t.assignee||'—', t.department||'—',
      t.priority, t.status==='closed'?'Task Closed':t.status,
      t.category, t.due_date, t.created_at?.split(' ')[0]||''
    ]);
    row.height = 20;
    const statusColor = statusColors[t.status]||'FFFFFFFF';
    const prioColor   = priorityColors[t.priority]||'FFFFFFFF';
    row.getCell(7).fill = { type:'pattern', pattern:'solid', fgColor: { argb: statusColor } };
    row.getCell(6).fill = { type:'pattern', pattern:'solid', fgColor: { argb: prioColor } };
    if (i%2===0) {
      row.eachCell((cell, colNum) => {
        if (colNum !== 6 && colNum !== 7)
          cell.fill = { type:'pattern', pattern:'solid', fgColor: { argb: 'FFF8FAFC' } };
      });
    }
    row.eachCell(cell => { cell.border = { bottom: { style:'thin', color: { argb: 'FFE2E8F0' } } }; cell.alignment = { vertical:'middle', wrapText:true }; });
  });

  ws.columns = [
    {width:5},{width:14},{width:36},{width:20},{width:16},
    {width:12},{width:14},{width:14},{width:14},{width:18}
  ];
  ws.autoFilter = { from:'A3', to:`J3` };

  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition',`attachment; filename="tasks_export_${todayStr()}.xlsx"`);
  await wb.xlsx.write(res);
  res.end();
});

router.get('/export/employees', authenticateExport, requireAdmin, async (req, res) => {
  const ExcelJS = require('exceljs');
  const brand = db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {};
  const today = todayStr();

  const employees = db.prepare(`SELECT u.id,u.name,u.email,u.role,u.department,u.timezone,u.last_login,
    COUNT(DISTINCT t.id) as total_assigned,
    SUM(CASE WHEN t.status='closed' THEN 1 ELSE 0 END) as total_closed,
    SUM(CASE WHEN t.status NOT IN('closed') AND t.due_date<'${today}' THEN 1 ELSE 0 END) as overdue,
    COALESCE(ROUND(SUM(CASE WHEN t.status='closed' THEN 1.0 ELSE 0 END)*100.0/NULLIF(COUNT(t.id),0),1),0) as completion_rate,
    SUM(DISTINCT cs.duration_minutes) as total_minutes
    FROM users u LEFT JOIN tasks t ON u.id=t.assigned_to LEFT JOIN clock_sessions cs ON u.id=cs.user_id AND cs.clock_out IS NOT NULL
    WHERE u.is_active=1 GROUP BY u.id ORDER BY total_closed DESC`).all();

  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Employee Report');

  ws.mergeCells('A1:J1');
  ws.getCell('A1').value = `${brand.company_name||'TaskFlow'} — Employee Performance Report`;
  ws.getCell('A1').font = { bold:true, size:16, color:{ argb:'FFFFFFFF' } };
  ws.getCell('A1').fill = { type:'pattern', pattern:'solid', fgColor:{ argb:'FF'+( brand.primary_color||'#6366f1').replace('#','') } };
  ws.getCell('A1').alignment = { horizontal:'center', vertical:'middle' };
  ws.getRow(1).height = 36;

  ws.mergeCells('A2:J2');
  ws.getCell('A2').value = `Generated: ${new Date().toLocaleDateString()} | ${employees.length} employees`;
  ws.getCell('A2').alignment = { horizontal:'center' }; ws.getRow(2).height = 22;

  const hRow = ws.addRow(['#','Name','Email','Role','Department','Timezone','Total Assigned','Task Closed','Overdue','Completion %','Hours Logged','Last Login']);
  ws.mergeCells('A2:L2');
  hRow.eachCell(cell => {
    cell.font = { bold:true, color:{ argb:'FFFFFFFF' } };
    cell.fill = { type:'pattern', pattern:'solid', fgColor:{ argb:'FF1E293B' } };
    cell.alignment = { horizontal:'center', vertical:'middle' };
  });
  ws.getRow(3).height = 26;

  employees.forEach((e,i) => {
    const rate = e.completion_rate||0;
    const rateColor = rate>=80?'FFbbf7d0':rate>=50?'FFfef9c3':'FFfecaca';
    const row = ws.addRow([
      i+1, e.name, e.email, e.role, e.department, e.timezone,
      e.total_assigned||0, e.total_closed||0, e.overdue||0,
      rate+'%', e.total_minutes ? Math.round(e.total_minutes/60)+'h' : '0h',
      e.last_login ? e.last_login.split(' ')[0] : 'Never'
    ]);
    row.height = 22;
    row.getCell(10).fill = { type:'pattern', pattern:'solid', fgColor:{ argb:rateColor } };
    if (i%2===0) row.eachCell((cell,c) => { if(c!==10) cell.fill={ type:'pattern', pattern:'solid', fgColor:{ argb:'FFF8FAFC' } }; });
    row.eachCell(cell => { cell.border = { bottom:{ style:'thin', color:{ argb:'FFE2E8F0' } } }; cell.alignment = { vertical:'middle' }; });
  });

  ws.columns = [{width:5},{width:22},{width:26},{width:20},{width:16},{width:10},{width:14},{width:14},{width:10},{width:14},{width:14},{width:14}];

  // Summary sheet
  const ws2 = wb.addWorksheet('Summary');
  ws2.addRow(['Metric','Value']).eachCell(c => { c.font={bold:true}; c.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF1E293B'}}; c.font={bold:true,color:{argb:'FFFFFFFF'}}; });
  const totalClosed = employees.reduce((a,e)=>a+(e.total_closed||0),0);
  const totalAssigned = employees.reduce((a,e)=>a+(e.total_assigned||0),0);
  [['Total Employees',employees.length],['Total Tasks Assigned',totalAssigned],['Total Tasks Closed',totalClosed],
   ['Overall Completion Rate', totalAssigned ? (totalClosed/totalAssigned*100).toFixed(1)+'%':'0%'],
   ['Report Date',new Date().toLocaleDateString()]].forEach(r => ws2.addRow(r));
  ws2.columns = [{width:30},{width:20}];

  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition',`attachment; filename="employee_report_${todayStr()}.xlsx"`);
  await wb.xlsx.write(res); res.end();
});

router.get('/export/history', authenticateExport, requireAdmin, async (req, res) => {
  const ExcelJS = require('exceljs');
  const { user_id, date_from, date_to } = req.query;
  const brand = db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {};
  let where=['1=1']; const params=[];
  if (user_id)   { where.push('th.user_id=?'); params.push(user_id); }
  if (date_from) { where.push('th.created_at>=?'); params.push(date_from); }
  if (date_to)   { where.push('th.created_at<=?'); params.push(date_to+' 23:59:59'); }

  const history = db.prepare(`SELECT th.*,u.name as user_name,u.department,t.title as task_title
    FROM task_history th JOIN users u ON th.user_id=u.id LEFT JOIN tasks t ON th.task_id=t.id
    WHERE ${where.join(' AND ')} ORDER BY th.created_at DESC LIMIT 2000`).all(...params);

  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Task History');
  ws.mergeCells('A1:H1');
  ws.getCell('A1').value = `${brand.company_name||'TaskFlow'} — Task History Report`;
  ws.getCell('A1').font = { bold:true, size:14, color:{argb:'FFFFFFFF'} };
  ws.getCell('A1').fill = { type:'pattern', pattern:'solid', fgColor:{argb:'FF'+(brand.primary_color||'#6366f1').replace('#','')} };
  ws.getCell('A1').alignment = { horizontal:'center', vertical:'middle' };
  ws.getRow(1).height = 32;

  const hRow = ws.addRow(['#','Timestamp','Employee','Department','Task','Action','Old Value','New Value']);
  hRow.eachCell(c => { c.font={bold:true,color:{argb:'FFFFFFFF'}}; c.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF334155'}}; c.alignment={horizontal:'center'}; });
  ws.getRow(2).height = 24;

  history.forEach((h,i) => {
    const row = ws.addRow([i+1, h.created_at, h.user_name, h.department||'—', h.task_title||h.task_id, h.action, h.old_value||'—', h.new_value||'—']);
    if(i%2===0) row.eachCell(c => c.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FFF8FAFC'}});
    row.eachCell(c => c.border={bottom:{style:'thin',color:{argb:'FFE2E8F0'}}});
    row.height = 18;
  });
  ws.columns = [{width:5},{width:20},{width:20},{width:16},{width:30},{width:20},{width:20},{width:25}];

  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition',`attachment; filename="history_export_${todayStr()}.xlsx"`);
  await wb.xlsx.write(res); res.end();
});

// ===== FULL DATA EXPORT (Excel — all sheets) =====
router.get('/export/full', authenticateExport, requireAdmin, async (req, res) => {
  const ExcelJS = require('exceljs');
  const brand = db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {};
  const today = todayStr();
  const primaryHex = 'FF' + (brand.primary_color||'#6366f1').replace('#','');
  const wb = new ExcelJS.Workbook();
  wb.creator = brand.company_name||'TaskFlow';
  wb.created = new Date();

  function hdr(ws, title, cols) {
    ws.mergeCells(`A1:${String.fromCharCode(64+cols)}1`);
    const c = ws.getCell('A1');
    c.value = `${brand.company_name||'TaskFlow'} — ${title}`;
    c.font = { bold:true, size:14, color:{argb:'FFFFFFFF'} };
    c.fill = { type:'pattern', pattern:'solid', fgColor:{argb:primaryHex} };
    c.alignment = { horizontal:'center', vertical:'middle' };
    ws.getRow(1).height = 32;
    ws.mergeCells(`A2:${String.fromCharCode(64+cols)}2`);
    ws.getCell('A2').value = `Generated: ${new Date().toLocaleString()} | Full Export`;
    ws.getCell('A2').alignment = { horizontal:'center' }; ws.getRow(2).height = 20;
  }
  function styleRow(row, i, hdrs) {
    if (i===0) { row.eachCell(c => { c.font={bold:true,color:{argb:'FFFFFFFF'}}; c.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF1E293B'}}; c.alignment={horizontal:'center',vertical:'middle'}; }); row.height=24; }
    else if (i%2===0) row.eachCell(c => c.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FFF8FAFC'}});
    row.eachCell(c => c.border={bottom:{style:'thin',color:{argb:'FFE2E8F0'}}});
  }

  // Sheet 1: Summary
  const wsSumm = wb.addWorksheet('Summary');
  hdr(wsSumm, 'Complete Data Export', 3);
  const summRows = [
    ['Metric','Count','Notes'],
    ['Total Users',     db.prepare("SELECT COUNT(*) as c FROM users WHERE is_active=1").get().c, 'Active employees'],
    ['Total Tasks',     db.prepare("SELECT COUNT(*) as c FROM tasks").get().c, 'All tasks'],
    ['Tasks Closed',    db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='closed'").get().c, 'Completed'],
    ['Overdue Tasks',   db.prepare(`SELECT COUNT(*) as c FROM tasks WHERE status!='closed' AND due_date<'${today}'`).get().c, 'Needs attention'],
    ['Notifications',   db.prepare("SELECT COUNT(*) as c FROM notifications").get().c, 'All notifications'],
    ['Reminders',       db.prepare("SELECT COUNT(*) as c FROM task_reminders").get().c, 'Task reminders'],
    ['Audit Entries',   db.prepare("SELECT COUNT(*) as c FROM audit_log").get().c, 'Audit records'],
    ['Categories',      db.prepare("SELECT COUNT(*) as c FROM categories WHERE is_active=1").get().c, 'Active categories'],
    ['Comments',        db.prepare("SELECT COUNT(*) as c FROM task_comments").get().c, 'Total comments'],
    ['History Entries', db.prepare("SELECT COUNT(*) as c FROM task_history").get().c, 'Activity records'],
    ['Export Date',     new Date().toLocaleDateString(), new Date().toLocaleTimeString()],
  ];
  summRows.forEach((r,i) => styleRow(wsSumm.addRow(r), i));
  wsSumm.columns = [{width:22},{width:14},{width:26}];

  // Sheet 2: Users
  const wsU = wb.addWorksheet('Users');
  hdr(wsU, 'All Employees', 8);
  const users = db.prepare('SELECT * FROM users WHERE is_active=1 ORDER BY name').all();
  [['Name','Email','Role','Department','Timezone','Admin','Login Count','Last Login']].concat(
    users.map(u=>[u.name,u.email,u.role,u.department,u.timezone,u.is_admin?'Yes':'No',u.login_count||0,u.last_login||'Never'])
  ).forEach((r,i) => styleRow(wsU.addRow(r), i));
  wsU.columns = [{width:22},{width:28},{width:22},{width:18},{width:8},{width:8},{width:12},{width:18}];

  // Sheet 3: Tasks
  const wsT = wb.addWorksheet('Tasks');
  hdr(wsT, 'All Tasks', 10);
  const tasks = db.prepare(`SELECT t.*,a.name as assignee,b.name as creator FROM tasks t LEFT JOIN users a ON t.assigned_to=a.id LEFT JOIN users b ON t.assigned_by=b.id ORDER BY t.created_at DESC`).all();
  const statusFmt = s => s==='closed'?'Task Closed':s;
  [['ID','Title','Assignee','Created By','Priority','Status','Category','Due Date','Created','Closed']].concat(
    tasks.map(t=>[t.id,t.title,t.assignee||'—',t.creator||'—',t.priority,statusFmt(t.status),t.category,t.due_date,t.created_at?.split(' ')[0],t.completed_at||'—'])
  ).forEach((r,i) => styleRow(wsT.addRow(r), i));
  wsT.columns = [{width:14},{width:34},{width:18},{width:18},{width:10},{width:14},{width:14},{width:12},{width:14},{width:12}];

  // Sheet 4: Comments
  const wsC = wb.addWorksheet('Comments');
  hdr(wsC, 'Task Comments', 5);
  const comments = db.prepare(`SELECT tc.*,u.name as user_name,t.title as task_title FROM task_comments tc JOIN users u ON tc.user_id=u.id LEFT JOIN tasks t ON tc.task_id=t.id ORDER BY tc.created_at DESC`).all();
  [['Timestamp','Task','User','Comment']].concat(
    comments.map(c=>[c.created_at,c.task_title||c.task_id,c.user_name,c.content])
  ).forEach((r,i) => styleRow(wsC.addRow(r), i));
  wsC.columns = [{width:20},{width:30},{width:18},{width:60}];

  // Sheet 5: Task History
  const wsH = wb.addWorksheet('Task History');
  hdr(wsH, 'Task History', 7);
  const hist = db.prepare(`SELECT th.*,u.name as user_name,t.title as task_title FROM task_history th JOIN users u ON th.user_id=u.id LEFT JOIN tasks t ON th.task_id=t.id ORDER BY th.created_at DESC LIMIT 2000`).all();
  [['Timestamp','Employee','Task','Action','Field','Old Value','New Value']].concat(
    hist.map(h=>[h.created_at,h.user_name,h.task_title||h.task_id,h.action,h.field_name||'—',h.old_value||'—',h.new_value||'—'])
  ).forEach((r,i) => styleRow(wsH.addRow(r), i));
  wsH.columns = [{width:20},{width:20},{width:30},{width:20},{width:16},{width:20},{width:24}];

  // Sheet 6: Categories
  const wsCat = wb.addWorksheet('Categories');
  hdr(wsCat, 'Categories', 5);
  const cats = db.prepare('SELECT c.*,COUNT(cm.user_id) as member_count FROM categories c LEFT JOIN category_members cm ON c.id=cm.category_id GROUP BY c.id ORDER BY c.name').all();
  [['ID','Name','Color','Active','Members']].concat(
    cats.map(c=>[c.id,c.name,c.color,c.is_active?'Yes':'No',c.member_count||0])
  ).forEach((r,i) => styleRow(wsCat.addRow(r), i));
  wsCat.columns = [{width:14},{width:22},{width:10},{width:8},{width:10}];

  // Sheet 7: Reminders
  const wsR = wb.addWorksheet('Reminders');
  hdr(wsR, 'Task Reminders', 7);
  const rems = db.prepare(`SELECT r.*,t.title as task_title,u.name as user_name FROM task_reminders r LEFT JOIN tasks t ON r.task_id=t.id LEFT JOIN users u ON r.user_id=u.id ORDER BY r.remind_at DESC LIMIT 1000`).all();
  [['User','Task','Remind At','Timezone','Status','Note','Created']].concat(
    rems.map(r=>[r.user_name,r.task_title||r.task_id,r.remind_at,r.timezone,r.status,r.note||'—',r.created_at?.split(' ')[0]])
  ).forEach((r,i) => styleRow(wsR.addRow(r), i));
  wsR.columns = [{width:18},{width:30},{width:20},{width:8},{width:12},{width:30},{width:14}];

  // Sheet 8: Audit Log
  const wsA = wb.addWorksheet('Audit Log');
  hdr(wsA, 'Audit Log', 7);
  const auditLogs = db.prepare(`SELECT al.*,u.name as user_name FROM audit_log al JOIN users u ON al.user_id=u.id ORDER BY al.created_at DESC LIMIT 2000`).all();
  [['Timestamp','User','Action','Entity','Entity ID','IP Address','Details']].concat(
    auditLogs.map(a=>[a.created_at,a.user_name,a.action,a.entity,a.entity_id||'—',a.ip_address||'—',(a.new_data||a.old_data||'').slice(0,100)])
  ).forEach((r,i) => styleRow(wsA.addRow(r), i));
  wsA.columns = [{width:20},{width:18},{width:20},{width:14},{width:16},{width:16},{width:50}];

  // Sheet 9: Branding
  const wsBr = wb.addWorksheet('Branding Settings');
  hdr(wsBr, 'Branding Settings', 2);
  const br = db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {};
  [['Setting','Value']].concat(
    Object.entries(br).filter(([k])=>k!=='id').map(([k,v])=>[k.replace(/_/g,' '),v||'—'])
  ).forEach((r,i) => styleRow(wsBr.addRow(r), i));
  wsBr.columns = [{width:28},{width:50}];

  // Sheet 10: Analytics Summary
  const wsAn = wb.addWorksheet('Analytics');
  hdr(wsAn, 'Employee Analytics', 8);
  const empData = db.prepare(`
    SELECT u.name,u.department,u.timezone,
      COUNT(t.id) as total,SUM(CASE WHEN t.status='closed' THEN 1 ELSE 0 END) as closed,
      SUM(CASE WHEN t.status!='closed' AND t.due_date<'${today}' THEN 1 ELSE 0 END) as overdue,
      ROUND(SUM(CASE WHEN t.status='closed' THEN 1.0 ELSE 0 END)*100.0/NULLIF(COUNT(t.id),0),1) as rate,
      SUM(DISTINCT cs.duration_minutes) as total_mins
    FROM users u LEFT JOIN tasks t ON u.id=t.assigned_to LEFT JOIN clock_sessions cs ON u.id=cs.user_id AND cs.clock_out IS NOT NULL
    WHERE u.is_active=1 GROUP BY u.id ORDER BY closed DESC`).all();
  [['Employee','Department','Timezone','Assigned','Closed','Overdue','Rate %','Hours Logged']].concat(
    empData.map(e=>[e.name,e.department,e.timezone,e.total||0,e.closed||0,e.overdue||0,(e.rate||0)+'%',e.total_mins?Math.round(e.total_mins/60)+'h':'0h'])
  ).forEach((r,i) => styleRow(wsAn.addRow(r), i));
  wsAn.columns = [{width:22},{width:18},{width:10},{width:10},{width:10},{width:10},{width:10},{width:12}];

  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition',`attachment; filename="${(brand.company_name||'TaskFlow').replace(/\s/g,'_')}_full_export_${todayStr()}.xlsx"`);
  await wb.xlsx.write(res); res.end();
});

// ===== JSON BACKUP =====
router.get('/export/backup', authenticateExport, requireAdmin, (req, res) => {
  const brand = db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {};
  const backup = {
    meta: {
      version: '2.0', exported_at: new Date().toISOString(),
      exported_by: req.user.name, company: brand.company_name||'TaskFlow',
      description: 'Complete TaskFlow database backup — restorable'
    },
    branding:     db.prepare('SELECT * FROM branding').all(),
    users:        db.prepare('SELECT id,name,email,role,department,is_admin,color,timezone,is_active,last_login,login_count,created_at FROM users').all(),
    categories:   db.prepare('SELECT * FROM categories').all(),
    category_members: db.prepare('SELECT * FROM category_members').all(),
    tasks:        db.prepare('SELECT * FROM tasks').all(),
    task_comments:db.prepare('SELECT * FROM task_comments').all(),
    task_history: db.prepare('SELECT * FROM task_history').all(),
    task_reminders: db.prepare('SELECT * FROM task_reminders').all(),
    notifications:db.prepare('SELECT * FROM notifications').all(),
    activity_log: db.prepare('SELECT * FROM activity_log ORDER BY created_at DESC LIMIT 5000').all(),
    audit_log:    db.prepare('SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 5000').all(),
    analytics: {
      task_stats: {
        total:    db.prepare("SELECT COUNT(*) as c FROM tasks").get().c,
        closed:   db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='closed'").get().c,
        pending:  db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='pending'").get().c,
        overdue:  db.prepare(`SELECT COUNT(*) as c FROM tasks WHERE status!='closed' AND due_date<'${todayStr()}'`).get().c,
      }
    }
  };
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename="${(brand.company_name||'TaskFlow').replace(/\s/g,'_')}_backup_${todayStr()}.json"`);
  res.send(JSON.stringify(backup, null, 2));
});

// ===== TEAM CHAT =====
router.get('/chat/messages', authenticate, (req, res) => {
  const { room='general', recipient_id, limit=100, before } = req.query;
  const isDM = !!recipient_id;
  let sql, params;
  if (isDM) {
    // DM: messages between two users
    sql = `SELECT m.*,u.name as sender_name,u.color as sender_color,u.role as sender_role,u.avatar_url as sender_avatar
      FROM chat_messages m JOIN users u ON m.sender_id=u.id
      WHERE ((m.sender_id=? AND m.recipient_id=?) OR (m.sender_id=? AND m.recipient_id=?))
      ${before ? 'AND m.created_at<?' : ''} ORDER BY m.created_at DESC LIMIT ?`;
    params = [req.user.id, recipient_id, recipient_id, req.user.id, ...(before?[before]:[]), parseInt(limit)];
    // Mark as read
    db.prepare("UPDATE chat_messages SET is_read=1 WHERE sender_id=? AND recipient_id=? AND is_read=0").run(recipient_id, req.user.id);
  } else {
    sql = `SELECT m.*,u.name as sender_name,u.color as sender_color,u.role as sender_role,u.avatar_url as sender_avatar
      FROM chat_messages m JOIN users u ON m.sender_id=u.id
      WHERE m.room=? AND m.recipient_id IS NULL ${before ? 'AND m.created_at<?' : ''}
      ORDER BY m.created_at DESC LIMIT ?`;
    params = [room, ...(before?[before]:[]), parseInt(limit)];
  }
  const messages = db.prepare(sql).all(...params).reverse();
  res.json(messages);
});

router.post('/chat/messages', authenticate, (req, res) => {
  const { content, room='general', recipient_id } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Content required' });
  const id = uuidv4(); const now = nowISO();
  db.prepare(`INSERT INTO chat_messages (id,sender_id,recipient_id,room,content,created_at) VALUES (?,?,?,?,?,?)`)
    .run(id, req.user.id, recipient_id||null, room, content.trim(), now);
  const msg = db.prepare(`SELECT m.*,u.name as sender_name,u.color as sender_color,u.role as sender_role,u.avatar_url as sender_avatar
    FROM chat_messages m JOIN users u ON m.sender_id=u.id WHERE m.id=?`).get(id);
  if (recipient_id) {
    sendToUser(recipient_id, { type:'chat:message', message:msg, dm:true });
    sendToUser(req.user.id,  { type:'chat:message', message:msg, dm:true });
  } else {
    broadcast({ type:'chat:message', message:msg, room });
  }
  res.status(201).json(msg);
});

router.delete('/chat/messages/:id', authenticate, (req, res) => {
  const msg = db.prepare('SELECT * FROM chat_messages WHERE id=?').get(req.params.id);
  if (!msg) return res.status(404).json({ error: 'Not found' });
  if (msg.sender_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Forbidden' });
  db.prepare('DELETE FROM chat_messages WHERE id=?').run(req.params.id);
  broadcast({ type:'chat:deleted', messageId: req.params.id });
  res.json({ ok:true });
});

router.get('/chat/unread', authenticate, (req, res) => {
  const counts = db.prepare(`SELECT sender_id, COUNT(*) as count FROM chat_messages WHERE recipient_id=? AND is_read=0 GROUP BY sender_id`).all(req.user.id);
  res.json(counts);
});


// ===== ENHANCED ANALYTICS =====
router.get('/analytics/tasks', authenticate, (req, res) => {
  const { user_id, department, status, priority, search, date_from, date_to } = req.query;
  const today = todayStr();
  let where = ['1=1']; const params = [];
  if (user_id)    { where.push('t.assigned_to=?');  params.push(user_id); }
  if (status)     { where.push('t.status=?');        params.push(status); }
  if (priority)   { where.push('t.priority=?');      params.push(priority); }
  if (department) { where.push('u.department=?');    params.push(department); }
  if (search)     { where.push('(t.title LIKE ? OR t.description LIKE ?)'); params.push('%'+search+'%','%'+search+'%'); }
  if (date_from)  { where.push('t.created_at>=?');   params.push(date_from); }
  if (date_to)    { where.push('t.created_at<=?');   params.push(date_to+' 23:59:59'); }

  const tasks = db.prepare(`
    SELECT t.*, u.name as assignee, u.department, u.color as assignee_color,
      b.name as creator,
      CAST(julianday(COALESCE(t.completed_at, '${today}')) - julianday(date(t.created_at)) AS INTEGER) as age_days
    FROM tasks t
    LEFT JOIN users u ON t.assigned_to=u.id
    LEFT JOIN users b ON t.assigned_by=b.id
    WHERE ${where.join(' AND ')}
    ORDER BY t.created_at DESC LIMIT 500`).all(...params);

  // Summary stats
  const total    = tasks.length;
  const closed   = tasks.filter(t=>t.status==='closed').length;
  const pending  = tasks.filter(t=>t.status==='pending').length;
  const inProg   = tasks.filter(t=>t.status==='in-progress').length;
  const overdue  = tasks.filter(t=>t.status!=='closed' && t.due_date<today).length;
  const avgClose = tasks.filter(t=>t.status==='closed'&&t.age_days!=null).reduce((a,t,_,arr)=>a+t.age_days/arr.length,0);

  // Speed buckets
  const speed = { fast:0, normal:0, slow:0 };
  tasks.filter(t=>t.status==='closed').forEach(t=>{
    if (t.age_days<=2) speed.fast++;
    else if (t.age_days<=7) speed.normal++;
    else speed.slow++;
  });

  res.json({ tasks, summary:{ total,closed,pending,inProgress:inProg,overdue, avgCloseDays:Math.round(avgClose*10)/10, speed } });
});

module.exports = router;
