const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { db } = require('../db/database');
const { authenticate, generateTokens, JWT_SECRET } = require('../middleware/auth');
const { nowISO, logActivity, logAudit } = require('../utils/helpers');
const jwt = require('jsonwebtoken');

router.post('/login',
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email=? AND is_active=1').get(email);
    if (!user || !await bcrypt.compare(password, user.password))
      return res.status(401).json({ error: 'Invalid credentials' });

    const { accessToken, refreshToken } = generateTokens(user.id);
    const expires = new Date(Date.now()+7*24*3600000).toISOString().replace('T',' ').split('.')[0];
    db.prepare('INSERT INTO refresh_tokens (id,user_id,token,expires_at,created_at) VALUES (?,?,?,?,?)').run(uuidv4(), user.id, refreshToken, expires, nowISO());
    db.prepare("UPDATE users SET last_login=?,login_count=COALESCE(login_count,0)+1 WHERE id=?").run(nowISO(), user.id);
    logActivity(db, user.id, 'logged in', 'auth', null, req.ip);
    logAudit(db, user.id, 'LOGIN', 'auth', user.id, null, { email: user.email }, req);

    const { password:_, ...safeUser } = user;
    const schedule = db.prepare('SELECT * FROM work_schedules WHERE user_id=? ORDER BY id').all(user.id);
    const brand = db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {};
    res.json({ accessToken, refreshToken, user: safeUser, schedule, brand });
  }
);

router.post('/refresh', (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(401).json({ error: 'No refresh token' });
  try {
    const decoded = jwt.verify(refreshToken, JWT_SECRET);
    if (decoded.type !== 'refresh') return res.status(401).json({ error: 'Invalid token type' });
    const stored = db.prepare("SELECT * FROM refresh_tokens WHERE token=? AND expires_at>?").get(refreshToken, nowISO());
    if (!stored) return res.status(401).json({ error: 'Token revoked' });
    const user = db.prepare('SELECT * FROM users WHERE id=? AND is_active=1').get(decoded.userId);
    if (!user) return res.status(401).json({ error: 'User not found' });
    db.prepare('DELETE FROM refresh_tokens WHERE token=?').run(refreshToken);
    const tokens = generateTokens(user.id);
    const expires = new Date(Date.now()+7*24*3600000).toISOString().replace('T',' ').split('.')[0];
    db.prepare('INSERT INTO refresh_tokens (id,user_id,token,expires_at,created_at) VALUES (?,?,?,?,?)').run(uuidv4(), user.id, tokens.refreshToken, expires, nowISO());
    res.json(tokens);
  } catch { res.status(401).json({ error: 'Invalid refresh token' }); }
});

router.post('/logout', authenticate, (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) db.prepare('DELETE FROM refresh_tokens WHERE token=?').run(refreshToken);
  db.prepare('DELETE FROM refresh_tokens WHERE user_id=?').run(req.user.id);
  logActivity(db, req.user.id, 'logged out', 'auth');
  res.json({ ok: true });
});

router.get('/me', authenticate, (req, res) => {
  const { password: _, ...safeUser } = req.user;
  const schedule = db.prepare('SELECT * FROM work_schedules WHERE user_id=?').all(req.user.id);
  const activeSession = db.prepare("SELECT * FROM clock_sessions WHERE user_id=? AND date=? AND clock_out IS NULL").get(req.user.id, new Date().toISOString().split('T')[0]);
  const brand = db.prepare('SELECT * FROM branding WHERE id=?').get('main') || {};
  res.json({ user: safeUser, schedule, activeSession: activeSession||null, brand });
});

router.put('/profile', authenticate, async (req, res) => {
  const { name, timezone, color, avatar_url } = req.body;
  const allowed = { name, timezone, color, avatar_url };
  // Only IST or CST allowed
  if (timezone && !['IST','CST'].includes(timezone)) return res.status(400).json({ error: 'Only IST and CST timezones allowed' });
  const updates = {}; for (const [k,v] of Object.entries(allowed)) if (v!==undefined) updates[k]=v;
  updates.updated_at = nowISO();
  const set = Object.keys(updates).map(k=>`${k}=?`).join(',');
  db.prepare(`UPDATE users SET ${set} WHERE id=?`).run(...Object.values(updates), req.user.id);
  const { password:_, ...safeUser } = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  res.json(safeUser);
});

router.put('/change-password', authenticate,
  body('currentPassword').notEmpty(), body('newPassword').isLength({ min:6 }),
  async (req, res) => {
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
    if (!await bcrypt.compare(req.body.currentPassword, user.password))
      return res.status(400).json({ error: 'Current password incorrect' });
    const hashed = await bcrypt.hash(req.body.newPassword, 10);
    db.prepare("UPDATE users SET password=?,updated_at=? WHERE id=?").run(hashed, nowISO(), req.user.id);
    logAudit(db, req.user.id, 'PASSWORD_CHANGE', 'user', req.user.id, null, null, req);
    res.json({ ok: true });
  }
);

module.exports = router;
