const router = require('express').Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../db/database');
const { authenticate } = require('../middleware/auth');
const { nowISO } = require('../utils/helpers');
const { sendToUser } = require('../utils/websocket');

// Normalize a datetime-local value ("2026-05-29T16:26" or with seconds) to the
// engine's storage/compare format "YYYY-MM-DD HH:MM:SS". Without this, the 'T'
// separator sorts after the space used by nowISO(), so reminders never fired.
function normTS(s) {
  if (!s) return s;
  let v = String(s).trim().replace('T', ' ');
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(v)) v += ':00';
  return v;
}

function getReminder(id) {
  return db.prepare(`
    SELECT r.*,
      t.title as task_title, t.priority as task_priority,
      t.status as task_status, t.due_date as task_due_date,
      t.description as task_description,
      u.name as user_name, u.color as user_color,
      tu.name as target_name, tu.color as target_color
    FROM task_reminders r
    LEFT JOIN tasks t ON r.task_id = t.id
    LEFT JOIN users u ON r.user_id = u.id
    LEFT JOIN users tu ON r.target_user_id = tu.id
    WHERE r.id = ?
  `).get(id);
}

// GET /api/task-reminders
router.get('/', authenticate, (req, res) => {
  const { task_id, status, limit = 200 } = req.query;
  let where = ['(r.user_id=? OR r.target_user_id=?)'];
  const params = [req.user.id, req.user.id];
  if (task_id) { where.push('r.task_id=?'); params.push(task_id); }
  if (status)  { where.push('r.status=?');  params.push(status); }
  params.push(parseInt(limit));
  const rows = db.prepare(`
    SELECT r.*,
      t.title as task_title, t.priority as task_priority, t.status as task_status,
      u.name as set_by_name, tu.name as target_name, tu.color as target_color
    FROM task_reminders r
    LEFT JOIN tasks t ON r.task_id = t.id
    LEFT JOIN users u ON r.user_id = u.id
    LEFT JOIN users tu ON r.target_user_id = tu.id
    WHERE ${where.join(' AND ')}
    ORDER BY COALESCE(r.next_fire_at, r.remind_at) ASC LIMIT ?
  `).all(...params);
  res.json(rows);
});

// POST /api/task-reminders
router.post('/', authenticate, (req, res) => {
  const {
    task_id, remind_at, timezone = 'IST', note,
    sound_tone = 'alert', target_user_id,
    repeat_interval = 0, repeat_until
  } = req.body;

  if (!remind_at) return res.status(400).json({ error: 'remind_at required' });
  if (!['IST', 'CST'].includes(timezone)) return res.status(400).json({ error: 'Only IST or CST' });

  // Reminders may be standalone (no task) — created from the Reminder panel — or
  // attached to an existing task when created from the Tasks screen.
  let task = null;
  if (task_id) {
    task = db.prepare('SELECT id,title,assigned_to FROM tasks WHERE id=?').get(task_id);
    if (!task) return res.status(404).json({ error: 'Task not found' });
  }

  // Target = explicitly provided user, or task's assigned person, or self
  let effectiveTarget = target_user_id || (task && task.assigned_to) || req.user.id;

  // Any employee may set a reminder for anyone on the team. We just confirm the
  // target is a real, active user so we don't create an orphaned reminder.
  if (effectiveTarget !== req.user.id) {
    const target = db.prepare('SELECT id FROM users WHERE id=? AND is_active=1').get(effectiveTarget);
    if (!target) return res.status(404).json({ error: 'Target user not found' });
  }

  const id  = 'rem_' + uuidv4().replace(/-/g,'').slice(0,8);
  const now = nowISO();

  // Normalize times so they compare correctly against nowISO() in the firing engine
  const remindAtNorm  = normTS(remind_at);
  const repeatUntilNorm = repeat_until ? normTS(repeat_until) : null;
  const nextFireAt = remindAtNorm; // First fire = remind_at

  db.prepare(`
    INSERT INTO task_reminders
      (id,task_id,user_id,target_user_id,remind_at,next_fire_at,timezone,note,sound_tone,
       repeat_interval,repeat_until,status,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `).run(id, task_id||null, req.user.id, effectiveTarget, remindAtNorm, nextFireAt,
         timezone, note||null, sound_tone, repeat_interval||0, repeatUntilNorm,
         'pending', now, now);

  const rem = getReminder(id);

  // Label used in notification text — task title if any, else the note, else generic
  const subject = task ? `"${task.title}"` : (note ? `"${note}"` : 'your reminder');

  // Notify target if different from creator
  if (effectiveTarget !== req.user.id) {
    const nid = uuidv4();
    const repeatText = repeat_interval > 0 ? ` (repeats every ${repeat_interval >= 60 ? Math.round(repeat_interval/60)+'h' : repeat_interval+'m'})` : '';
    db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,task_id,is_read,created_at) VALUES (?,?,?,?,?,?,?,0,?)`)
      .run(nid, effectiveTarget, '⏰ Reminder Set for You',
        `${req.user.name} set a reminder for ${subject} at ${remind_at}${repeatText}`,
        'info', 'task_reminder', task_id||null, now);
    sendToUser(effectiveTarget, { type: 'reminder:created', reminder: rem });
    sendToUser(effectiveTarget, {
      type: 'notification:new',
      notification: { id: nid, user_id: effectiveTarget, title: '⏰ Reminder Set for You',
        message: `Reminder for ${subject} at ${remind_at}`, type: 'info',
        category: 'task_reminder', task_id: task_id||null, is_read: 0, created_at: now }
    });
  }
  sendToUser(req.user.id, { type: 'reminder:created', reminder: rem });
  res.status(201).json(rem);
});

// PUT /api/task-reminders/:id
router.put('/:id', authenticate, (req, res) => {
  const rem = db.prepare('SELECT * FROM task_reminders WHERE id=? AND (user_id=? OR target_user_id=?)').get(req.params.id, req.user.id, req.user.id);
  if (!rem) return res.status(404).json({ error: 'Not found' });

  const fields = ['remind_at','timezone','note','status','snoozed_until','sound_tone','repeat_interval','repeat_until','next_fire_at'];
  const updates = {};
  for (const f of fields) if (req.body[f] !== undefined) updates[f] = req.body[f];
  // Keep datetime fields in the engine's comparable format
  for (const tf of ['remind_at','next_fire_at','repeat_until','snoozed_until']) {
    if (updates[tf]) updates[tf] = normTS(updates[tf]);
  }

  if (updates.timezone && !['IST','CST'].includes(updates.timezone))
    return res.status(400).json({ error: 'Only IST or CST' });

  // Handle snooze
  if (req.body.snooze_minutes) {
    updates.snoozed_until = new Date(Date.now() + req.body.snooze_minutes * 60000).toISOString().replace('T',' ').split('.')[0];
    updates.status = 'snoozed';
    // Also schedule next repeat fire after snooze
    if (rem.repeat_interval > 0) {
      updates.next_fire_at = updates.snoozed_until;
    }
  }
  if (req.body.status === 'completed') updates.fired_at = nowISO();
  updates.updated_at = nowISO();

  const set = Object.keys(updates).map(k => `${k}=?`).join(',');
  db.prepare(`UPDATE task_reminders SET ${set} WHERE id=?`).run(...Object.values(updates), req.params.id);

  const updated = getReminder(req.params.id);
  sendToUser(req.user.id, { type: 'reminder:updated', reminder: updated });
  if (rem.target_user_id && rem.target_user_id !== req.user.id) {
    sendToUser(rem.target_user_id, { type: 'reminder:updated', reminder: updated });
  }
  res.json(updated);
});

// DELETE /api/task-reminders/:id
router.delete('/:id', authenticate, (req, res) => {
  const rem = db.prepare('SELECT * FROM task_reminders WHERE id=? AND (user_id=? OR target_user_id=?)').get(req.params.id, req.user.id, req.user.id);
  if (!rem) return res.status(404).json({ error: 'Not found' });
  db.prepare('DELETE FROM task_reminders WHERE id=?').run(rem.id);
  sendToUser(req.user.id, { type: 'reminder:deleted', reminderId: rem.id });
  if (rem.target_user_id && rem.target_user_id !== req.user.id)
    sendToUser(rem.target_user_id, { type: 'reminder:deleted', reminderId: rem.id });
  res.json({ ok: true });
});

// GET /api/task-reminders/stats
router.get('/stats', authenticate, (req, res) => {
  const now = nowISO();
  res.json({
    upcoming:  db.prepare("SELECT COUNT(*) as c FROM task_reminders WHERE (user_id=? OR target_user_id=?) AND status='pending' AND COALESCE(next_fire_at,remind_at) > ?").get(req.user.id, req.user.id, now).c,
    missed:    db.prepare("SELECT COUNT(*) as c FROM task_reminders WHERE (user_id=? OR target_user_id=?) AND status='fired'").get(req.user.id, req.user.id).c,
    snoozed:   db.prepare("SELECT COUNT(*) as c FROM task_reminders WHERE (user_id=? OR target_user_id=?) AND status='snoozed'").get(req.user.id, req.user.id).c,
    completed: db.prepare("SELECT COUNT(*) as c FROM task_reminders WHERE (user_id=? OR target_user_id=?) AND status='completed'").get(req.user.id, req.user.id).c,
    active:    db.prepare("SELECT COUNT(*) as c FROM task_reminders WHERE (user_id=? OR target_user_id=?) AND status='pending' AND repeat_interval > 0").get(req.user.id, req.user.id).c,
  });
});

module.exports = router;
