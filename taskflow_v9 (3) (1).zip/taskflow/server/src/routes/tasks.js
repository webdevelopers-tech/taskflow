const router = require('express').Router();
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { db } = require('../db/database');
const { authenticate } = require('../middleware/auth');
const { broadcast, sendToUser } = require('../utils/websocket');
const { nowISO, todayStr, notifyTaskEvent, logHistory, logAudit, logActivity } = require('../utils/helpers');

function getTask(id) {
  return db.prepare(`
    SELECT t.*,
      a.name as assigned_to_name, a.color as assigned_to_color, a.role as assigned_to_role, a.department as assigned_to_dept,
      b.name as assigned_by_name, b.color as assigned_by_color,
      c.name as closed_by_name
    FROM tasks t
    LEFT JOIN users a ON t.assigned_to = a.id
    LEFT JOIN users b ON t.assigned_by = b.id
    LEFT JOIN users c ON t.closed_by  = c.id
    WHERE t.id = ?`).get(id);
}

// GET /api/tasks
router.get('/', authenticate, (req, res) => {
  const { status, priority, assigned_to, assigned_by, category, overdue, search, project, department, date_from, date_to, page=1, limit=100 } = req.query;
  let where = ['1=1']; const params = [];

  if (status)      { where.push('t.status = ?'); params.push(status); }
  if (priority)    { where.push('t.priority = ?'); params.push(priority); }
  if (assigned_to) { where.push('t.assigned_to = ?'); params.push(assigned_to); }
  if (assigned_by) { where.push('t.assigned_by = ?'); params.push(assigned_by); }
  if (category)    { where.push('t.category = ?'); params.push(category); }
  if (project)     { where.push('t.project = ?'); params.push(project); }
  if (department)  { where.push('a.department = ?'); params.push(department); }
  if (date_from)   { where.push('t.due_date >= ?'); params.push(date_from); }
  if (date_to)     { where.push('t.due_date <= ?'); params.push(date_to); }
  if (overdue === 'true') { where.push("t.status != 'closed' AND t.due_date < ?"); params.push(todayStr()); }
  if (search) { where.push('(t.title LIKE ? OR t.description LIKE ?)'); params.push(`%${search}%`, `%${search}%`); }

  const offset = (parseInt(page)-1) * parseInt(limit);
  const sql = `
    SELECT t.*, a.name as assigned_to_name, a.color as assigned_to_color, a.role as assigned_to_role, a.department as assigned_to_dept,
      b.name as assigned_by_name, b.color as assigned_by_color
    FROM tasks t
    LEFT JOIN users a ON t.assigned_to = a.id
    LEFT JOIN users b ON t.assigned_by = b.id
    WHERE ${where.join(' AND ')}
    ORDER BY
      CASE WHEN t.status NOT IN ('closed') AND t.due_date < '${todayStr()}' THEN 0 ELSE 1 END,
      CASE t.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END,
      t.due_date ASC LIMIT ? OFFSET ?`;
  params.push(parseInt(limit), offset);

  const tasks = db.prepare(sql).all(...params);
  const countParams = params.slice(0,-2);
  const total = db.prepare(`SELECT COUNT(*) as c FROM tasks t LEFT JOIN users a ON t.assigned_to=a.id WHERE ${where.join(' AND ')}`).get(...countParams).c;
  res.json({ tasks, total, page: parseInt(page), pages: Math.ceil(total/parseInt(limit)) });
});

// GET /api/tasks/stats
router.get('/stats', authenticate, (req, res) => {
  const today = todayStr();
  const stats = {
    total:        db.prepare("SELECT COUNT(*) as c FROM tasks").get().c,
    pending:      db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='pending'").get().c,
    inProgress:   db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='in-progress'").get().c,
    closed:       db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='closed'").get().c,
    overdue:      db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status NOT IN ('closed') AND due_date < ?").get(today).c,
    closedToday:  db.prepare("SELECT COUNT(*) as c FROM tasks WHERE completed_at=?").get(today).c,
    myPending:    db.prepare("SELECT COUNT(*) as c FROM tasks WHERE assigned_to=? AND status!='closed'").get(req.user.id).c,
    myOverdue:    db.prepare("SELECT COUNT(*) as c FROM tasks WHERE assigned_to=? AND status NOT IN ('closed') AND due_date < ?").get(req.user.id, today).c,
  };
  stats.byPriority = db.prepare("SELECT priority, COUNT(*) as count FROM tasks GROUP BY priority").all();
  stats.byCategory = db.prepare("SELECT category, COUNT(*) as count FROM tasks GROUP BY category ORDER BY count DESC").all();
  stats.byUser = db.prepare(`SELECT u.id,u.name,u.color,u.department,COUNT(t.id) as total,
    SUM(CASE WHEN t.status='closed' THEN 1 ELSE 0 END) as closed,
    SUM(CASE WHEN t.status NOT IN('closed') AND t.due_date < '${today}' THEN 1 ELSE 0 END) as overdue
    FROM users u LEFT JOIN tasks t ON u.id=t.assigned_to WHERE u.is_active=1 GROUP BY u.id`).all();
  stats.weeklyTrend = [];
  for (let i=6; i>=0; i--) {
    const d = new Date(); d.setDate(d.getDate()-i);
    const ds = d.toISOString().split('T')[0];
    stats.weeklyTrend.push({ date: ds, closed: db.prepare("SELECT COUNT(*) as c FROM tasks WHERE completed_at=?").get(ds).c });
  }
  res.json(stats);
});

// GET /api/tasks/:id
router.get('/:id', authenticate, (req, res) => {
  const task = getTask(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  const comments = db.prepare(`SELECT tc.*, u.name as user_name, u.color as user_color, u.role as user_role
    FROM task_comments tc JOIN users u ON tc.user_id=u.id WHERE tc.task_id=? ORDER BY tc.created_at ASC`).all(req.params.id);
  const history = db.prepare(`SELECT th.*, u.name as user_name, u.color as user_color
    FROM task_history th JOIN users u ON th.user_id=u.id WHERE th.task_id=? ORDER BY th.created_at DESC`).all(req.params.id);
  res.json({ ...task, comments, history });
});

// POST /api/tasks
router.post('/', authenticate,
  body('title').trim().notEmpty().isLength({ max:255 }),
  body('assigned_to').notEmpty(),
  body('due_date').isDate(),
  body('priority').isIn(['low','medium','high']),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { title, description, assigned_to, priority, status='pending', category='general', due_date, project, tags } = req.body;
    const assignee = db.prepare('SELECT id,name FROM users WHERE id=? AND is_active=1').get(assigned_to);
    if (!assignee) return res.status(400).json({ error: 'Assignee not found' });

    const id = 'tsk_' + uuidv4().replace(/-/g,'').slice(0,8);
    const now = nowISO();
    db.prepare(`INSERT INTO tasks (id,title,description,assigned_to,assigned_by,priority,status,category,due_date,project,tags,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(id, title, description||null, assigned_to, req.user.id, priority, status, category, due_date, project||null, tags||null, now, now);

    logHistory(db, id, req.user.id, 'task_created', null, null, title);
    logActivity(db, req.user.id, 'created task', 'task', id, title);
    logAudit(db, req.user.id, 'CREATE', 'task', id, null, { title, assigned_to, priority, status }, req);

    const task = getTask(id);
    notifyTaskEvent(db, task, '📋 New Task Assigned',
      `"${title}" assigned to ${assignee.name} by ${req.user.name} — Due: ${due_date}`,
      'info', 'task_assigned', req.user.id, (data, uid) => sendToUser(uid, data));

    broadcast({ type: 'task:created', task });
    res.status(201).json(task);
  }
);

// PUT /api/tasks/:id
router.put('/:id', authenticate, (req, res) => {
  const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });

  const isAdmin   = req.user.is_admin;
  const isCreator = task.assigned_by === req.user.id;
  const isAssignee= task.assigned_to === req.user.id;
  const canEdit   = isAdmin || isCreator || isAssignee;
  if (!canEdit) return res.status(403).json({ error: 'Not authorized to edit this task' });

  // All three (admin/creator/assignee) can edit task content
  // ONLY restriction: assignees cannot REASSIGN the task to a different person
  const fullEditFields = ['title','description','assigned_to','priority','status','category','due_date','project','tags'];
  // Assignee can edit everything EXCEPT reassigning to someone else
  const allowedFields = fullEditFields; // everyone can edit content
  // We'll block assigned_to change specifically for assignees below

  const updates = {};
  const historyEntries = [];

  for (const f of fullEditFields) {
    if (req.body[f] !== undefined && req.body[f] !== task[f]) {
      // Assignees cannot reassign the task to someone else
      if (f === 'assigned_to' && isAssignee && !isAdmin && !isCreator) {
        continue; // skip - only admin/creator can reassign
      }
      updates[f] = req.body[f];
      historyEntries.push({ field: f, old: task[f], new: req.body[f] });
    }
  }

  // Handle close/reopen
  if (updates.status === 'closed' && task.status !== 'closed') {
    updates.completed_at = todayStr();
    updates.closed_by = req.user.id;
    historyEntries.push({ field: 'status', old: task.status, new: 'closed', action: 'task_closed' });
    notifyTaskEvent(db, task, '✅ Task Closed',
      `"${task.title}" was closed by ${req.user.name}`, 'success', 'task_closed', req.user.id,
      (data, uid) => sendToUser(uid, data));
    logActivity(db, req.user.id, 'closed task', 'task', task.id, task.title);
  } else if (updates.status && updates.status !== 'closed' && task.status === 'closed') {
    updates.completed_at = null;
    updates.closed_by    = null;
    notifyTaskEvent(db, task, '🔄 Task Reopened',
      `"${task.title}" was reopened by ${req.user.name}`, 'warning', 'task_reopened', req.user.id,
      (data, uid) => sendToUser(uid, data));
    logActivity(db, req.user.id, 'reopened task', 'task', task.id, task.title);
  }

  // Specific change notifications
  for (const e of historyEntries) {
    logHistory(db, task.id, req.user.id, e.action || `${e.field}_changed`, e.field, e.old, e.new);

    if (e.field === 'priority') {
      notifyTaskEvent(db, task, '⚡ Priority Changed',
        `"${task.title}" priority changed from ${e.old} to ${e.new} by ${req.user.name}`, 'warning', 'priority_changed', req.user.id,
        (data, uid) => sendToUser(uid, data));
    }
    if (e.field === 'due_date') {
      notifyTaskEvent(db, task, '📅 Due Date Changed',
        `"${task.title}" due date changed to ${e.new} by ${req.user.name}`, 'info', 'due_date_changed', req.user.id,
        (data, uid) => sendToUser(uid, data));
    }
    if (e.field === 'assigned_to') {
      const newAssignee = db.prepare('SELECT name FROM users WHERE id=?').get(e.new);
      if (newAssignee) {
        const nid = uuidv4(); const now2 = nowISO();
        db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,task_id,is_read,created_at) VALUES (?,?,?,?,?,?,?,0,?)`)
          .run(nid, e.new, '📋 Task Reassigned', `"${task.title}" has been assigned to you by ${req.user.name}`, 'info', 'task_assigned', task.id, now2);
        sendToUser(e.new, { type:'notification:new', notification: { id:nid, user_id:e.new, title:'📋 Task Reassigned', message:`"${task.title}" assigned to you`, type:'info', category:'task_assigned', task_id:task.id, is_read:0, created_at:now2 } });
      }
    }
  }

  if (historyEntries.length > 0 && Object.keys(updates)[0] !== 'status') {
    notifyTaskEvent(db, task, '✏️ Task Updated',
      `"${task.title}" was updated by ${req.user.name}`, 'info', 'task_updated', req.user.id,
      (data, uid) => sendToUser(uid, data));
  }

  if (Object.keys(updates).length === 0) {
    return res.json(getTask(task.id)); // Nothing changed
  }

  const now = nowISO();
  const setClause = [...Object.keys(updates).map(k=>`${k}=?`), 'updated_at=?'].join(', ');
  db.prepare(`UPDATE tasks SET ${setClause} WHERE id=?`).run(...Object.values(updates), now, task.id);
  logAudit(db, req.user.id, 'UPDATE', 'task', task.id, task, updates, req);

  const updated = getTask(task.id);
  broadcast({ type: 'task:updated', task: updated });
  res.json(updated);
});

// DELETE /api/tasks/:id
router.delete('/:id', authenticate, (req, res) => {
  const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  if (!req.user.is_admin && task.assigned_by !== req.user.id) return res.status(403).json({ error: 'Not authorized' });

  logAudit(db, req.user.id, 'DELETE', 'task', task.id, task, null, req);
  logActivity(db, req.user.id, 'deleted task', 'task', task.id, task.title);
  db.prepare('DELETE FROM tasks WHERE id=?').run(task.id);
  broadcast({ type: 'task:deleted', taskId: task.id });
  res.json({ message: 'Task deleted' });
});

// POST /api/tasks/:id/comments
router.post('/:id/comments', authenticate,
  body('content').trim().notEmpty().isLength({ max:2000 }),
  (req, res) => {
    const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found' });
    const id = uuidv4(); const now = nowISO();
    db.prepare(`INSERT INTO task_comments (id,task_id,user_id,content,created_at) VALUES (?,?,?,?,?)`)
      .run(id, task.id, req.user.id, req.body.content, now);
    logHistory(db, task.id, req.user.id, 'comment_added', null, null, req.body.content.slice(0,80));
    notifyTaskEvent(db, task, '💬 New Comment',
      `${req.user.name} commented on "${task.title}": ${req.body.content.slice(0,60)}...`, 'info', 'comment_added', req.user.id,
      (data, uid) => sendToUser(uid, data));
    const comment = db.prepare(`SELECT tc.*, u.name as user_name, u.color as user_color, u.role as user_role
      FROM task_comments tc JOIN users u ON tc.user_id=u.id WHERE tc.id=?`).get(id);
    broadcast({ type: 'task:comment', taskId: task.id, comment });
    res.status(201).json(comment);
  }
);

module.exports = router;
