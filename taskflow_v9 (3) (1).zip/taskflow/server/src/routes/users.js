const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { db } = require('../db/database');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { nowISO, todayStr, logAudit, logActivity } = require('../utils/helpers');

const SAFE = 'id,name,email,role,department,is_admin,color,timezone,avatar_url,is_active,last_login,login_count,created_at';

router.get('/', authenticate, (req, res) => {
  res.json(db.prepare(`SELECT ${SAFE} FROM users WHERE is_active=1 ORDER BY name`).all());
});

router.get('/online', authenticate, (req, res) => {
  res.json(db.prepare(`SELECT u.id,u.name,u.color,u.role,u.timezone,cs.clock_in FROM users u
    JOIN clock_sessions cs ON u.id=cs.user_id WHERE cs.date=? AND cs.clock_out IS NULL AND u.is_active=1`).all(todayStr()));
});

router.get('/:id', authenticate, (req, res) => {
  const user = db.prepare(`SELECT ${SAFE} FROM users WHERE id=? AND is_active=1`).get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const schedule = db.prepare('SELECT * FROM work_schedules WHERE user_id=? ORDER BY id').all(req.params.id);
  const taskStats = db.prepare(`SELECT COUNT(*) as total,
    SUM(CASE WHEN status='closed' THEN 1 ELSE 0 END) as closed,
    SUM(CASE WHEN status NOT IN('closed') AND due_date<? THEN 1 ELSE 0 END) as overdue
    FROM tasks WHERE assigned_to=?`).get(todayStr(), req.params.id);
  const hoursThisWeek = db.prepare(`SELECT SUM(duration_minutes) as mins FROM clock_sessions
    WHERE user_id=? AND date>=date('now','-6 days') AND clock_out IS NOT NULL`).get(req.params.id);
  res.json({ ...user, schedule, taskStats, hoursThisWeek: hoursThisWeek?.mins||0 });
});

router.post('/', authenticate, requireAdmin,
  body('name').trim().notEmpty(), body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min:6 }), body('role').notEmpty(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { name, email, password, role, department='General', timezone='IST', color='#6366f1', is_admin=false } = req.body;
    if (!['IST','CST'].includes(timezone)) return res.status(400).json({ error: 'Only IST and CST timezones' });
    if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(400).json({ error: 'Email already in use' });
    const id = 'usr_' + uuidv4().replace(/-/g,'').slice(0,8);
    const now = nowISO();
    db.prepare(`INSERT INTO users (id,name,email,password,role,department,is_admin,color,timezone,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
      .run(id, name, email, await bcrypt.hash(password,10), role, department, is_admin?1:0, color, timezone, now, now);
    const days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
    for (const day of days) {
      db.prepare('INSERT INTO work_schedules (id,user_id,day_of_week,is_working,start_time,end_time) VALUES (?,?,?,?,?,?)')
        .run(uuidv4(), id, day, !['Saturday','Sunday'].includes(day)?1:0, '09:00', '17:00');
    }
    logAudit(db, req.user.id, 'CREATE_USER', 'user', id, null, { name, email, role, department }, req);
    logActivity(db, req.user.id, 'created employee', 'user', id, name);
    const user = db.prepare(`SELECT ${SAFE} FROM users WHERE id=?`).get(id);
    res.status(201).json(user);
  }
);

router.put('/:id', authenticate, async (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found' });
  if (!req.user.is_admin && req.user.id !== req.params.id) return res.status(403).json({ error: 'Not authorized' });

  const allowed = ['name','timezone','color','avatar_url'];
  if (req.user.is_admin) allowed.push('role','department','is_admin','is_active','email');
  if (req.body.timezone && !['IST','CST'].includes(req.body.timezone)) return res.status(400).json({ error: 'Only IST and CST timezones' });

  const updates = {}; for (const f of allowed) if (req.body[f]!==undefined) updates[f]=req.body[f];
  if (req.body.password && req.user.is_admin) updates.password = await bcrypt.hash(req.body.password, 10);
  if (!Object.keys(updates).length) return res.status(400).json({ error: 'Nothing to update' });
  updates.updated_at = nowISO();

  const set = Object.keys(updates).map(k=>`${k}=?`).join(',');
  db.prepare(`UPDATE users SET ${set} WHERE id=?`).run(...Object.values(updates), req.params.id);
  logAudit(db, req.user.id, 'UPDATE_USER', 'user', req.params.id, target, updates, req);
  res.json(db.prepare(`SELECT ${SAFE} FROM users WHERE id=?`).get(req.params.id));
});

router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  if (req.params.id === req.user.id) return res.status(400).json({ error: 'Cannot deactivate yourself' });
  db.prepare("UPDATE users SET is_active=0,updated_at=? WHERE id=?").run(nowISO(), req.params.id);
  logAudit(db, req.user.id, 'DEACTIVATE_USER', 'user', req.params.id, null, null, req);
  res.json({ ok: true });
});

router.put('/:id/schedule', authenticate, (req, res) => {
  if (!req.user.is_admin && req.user.id !== req.params.id) return res.status(403).json({ error: 'Not authorized' });
  const { schedule } = req.body;
  if (!Array.isArray(schedule)) return res.status(400).json({ error: 'schedule must be array' });
  for (const s of schedule) {
    db.prepare('UPDATE work_schedules SET is_working=?,start_time=?,end_time=? WHERE user_id=? AND day_of_week=?')
      .run(s.is_working?1:0, s.start_time, s.end_time, req.params.id, s.day_of_week);
  }
  if (req.user.id !== req.params.id) {
    const target = db.prepare('SELECT name FROM users WHERE id=?').get(req.params.id);
    const { v4: u } = require('uuid');
    db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,is_read,created_at) VALUES (?,?,?,?,?,?,0,?)`)
      .run(u(), req.params.id, '📅 Schedule Updated', `Your schedule was updated by ${req.user.name}`, 'info', 'general', nowISO());
  }
  res.json(db.prepare('SELECT * FROM work_schedules WHERE user_id=?').all(req.params.id));
});

module.exports = router;
