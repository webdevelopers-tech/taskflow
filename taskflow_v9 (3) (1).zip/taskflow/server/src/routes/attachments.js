const router  = require('express').Router();
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { v4: uuidv4 } = require('uuid');
const { db }  = require('../db/database');
const { authenticate } = require('../middleware/auth');
const { nowISO, logHistory, logActivity } = require('../utils/helpers');
const { broadcast, sendToUser } = require('../utils/websocket');

const UPLOAD_BASE = path.join(__dirname, '../../uploads');
const ALLOWED_TYPES = {
  'image/jpeg':true,'image/png':true,'image/gif':true,'image/webp':true,
  'application/pdf':true,
  'application/msword':true,'application/vnd.openxmlformats-officedocument.wordprocessingml.document':true,
  'application/vnd.ms-excel':true,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':true,
  'application/vnd.ms-powerpoint':true,'application/vnd.openxmlformats-officedocument.presentationml.presentation':true,
  'application/zip':true,'application/x-zip-compressed':true,
  'text/plain':true,'text/csv':true,
};
const MAX_SIZE = 25 * 1024 * 1024; // 25MB

function makeStorage(folder) {
  return multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(UPLOAD_BASE, folder);
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      const ext  = path.extname(file.originalname).toLowerCase();
      const name = uuidv4().replace(/-/g,'') + ext;
      cb(null, name);
    }
  });
}

const taskUpload = multer({
  storage: makeStorage('tasks'),
  limits: { fileSize: MAX_SIZE },
  fileFilter: (req, file, cb) => {
    if (ALLOWED_TYPES[file.mimetype]) cb(null, true);
    else cb(new Error(`File type ${file.mimetype} not allowed`));
  }
});

const chatUpload = multer({
  storage: makeStorage('chat'),
  limits: { fileSize: MAX_SIZE },
  fileFilter: (req, file, cb) => {
    if (ALLOWED_TYPES[file.mimetype]) cb(null, true);
    else cb(new Error(`File type ${file.mimetype} not allowed`));
  }
});

// ===== TASK ATTACHMENTS =====

// GET /api/attachments/task/:taskId
router.get('/task/:taskId', authenticate, (req, res) => {
  const atts = db.prepare(`
    SELECT a.*, u.name as uploader_name, u.color as uploader_color
    FROM task_attachments a JOIN users u ON a.uploaded_by=u.id
    WHERE a.task_id=? ORDER BY a.created_at DESC
  `).all(req.params.taskId);
  res.json(atts);
});

// POST /api/attachments/task/:taskId
router.post('/task/:taskId', authenticate, taskUpload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.taskId);
  if (!task) return res.status(404).json({ error: 'Task not found' });

  const id  = uuidv4(); const now = nowISO();
  const rel = path.relative(UPLOAD_BASE, req.file.path).replace(/\\/g, '/');
  db.prepare(`INSERT INTO task_attachments (id,task_id,uploaded_by,original_name,stored_name,file_size,mime_type,file_path,created_at)
    VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(id, task.id, req.user.id, req.file.originalname, req.file.filename, req.file.size, req.file.mimetype, rel, now);

  logHistory(db, task.id, req.user.id, 'attachment_added', 'attachment', null, req.file.originalname);
  logActivity(db, req.user.id, 'attached file', 'task', task.id, req.file.originalname);

  const att = db.prepare(`SELECT a.*,u.name as uploader_name,u.color as uploader_color FROM task_attachments a JOIN users u ON a.uploaded_by=u.id WHERE a.id=?`).get(id);

  // Notify task participants
  const recipients = new Set();
  if (task.assigned_to !== req.user.id) recipients.add(task.assigned_to);
  if (task.assigned_by !== req.user.id) recipients.add(task.assigned_by);
  const notifMsg = `${req.user.name} attached "${req.file.originalname}" to "${task.title}"`;
  for (const uid of recipients) {
    const nid = uuidv4();
    db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,task_id,is_read,created_at) VALUES (?,?,?,?,?,?,?,0,?)`)
      .run(nid, uid, '📎 File Attached', notifMsg, 'info', 'attachment_added', task.id, now);
    sendToUser(uid, { type:'notification:new', notification:{ id:nid, user_id:uid, title:'📎 File Attached', message:notifMsg, type:'info', category:'attachment_added', task_id:task.id, is_read:0, created_at:now } });
  }
  broadcast({ type:'task:attachment', taskId:task.id, attachment:att });
  res.status(201).json(att);
});

// GET /api/attachments/task-file/:id/download
router.get('/task-file/:id/download', authenticate, (req, res) => {
  const att = db.prepare('SELECT * FROM task_attachments WHERE id=?').get(req.params.id);
  if (!att) return res.status(404).json({ error: 'Not found' });
  const filePath = path.join(UPLOAD_BASE, att.file_path);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not found on disk' });
  res.setHeader('Content-Disposition', `attachment; filename="${att.original_name}"`);
  res.setHeader('Content-Type', att.mime_type);
  res.sendFile(filePath);
});

// GET /api/attachments/task-file/:id/preview (inline for images/pdf)
router.get('/task-file/:id/preview', authenticate, (req, res) => {
  const att = db.prepare('SELECT * FROM task_attachments WHERE id=?').get(req.params.id);
  if (!att) return res.status(404).json({ error: 'Not found' });
  const filePath = path.join(UPLOAD_BASE, att.file_path);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not found' });
  res.setHeader('Content-Disposition', `inline; filename="${att.original_name}"`);
  res.setHeader('Content-Type', att.mime_type);
  res.sendFile(filePath);
});

// DELETE /api/attachments/task-file/:id
router.delete('/task-file/:id', authenticate, (req, res) => {
  const att = db.prepare('SELECT * FROM task_attachments WHERE id=?').get(req.params.id);
  if (!att) return res.status(404).json({ error: 'Not found' });
  const canDelete = req.user.is_admin || att.uploaded_by === req.user.id;
  if (!canDelete) return res.status(403).json({ error: 'Not authorized' });
  // Delete file from disk
  const filePath = path.join(UPLOAD_BASE, att.file_path);
  try { fs.unlinkSync(filePath); } catch {}
  db.prepare('DELETE FROM task_attachments WHERE id=?').run(att.id);
  logHistory(db, att.task_id, req.user.id, 'attachment_removed', 'attachment', att.original_name, null);
  broadcast({ type:'task:attachment_removed', taskId:att.task_id, attachmentId:att.id });
  res.json({ ok:true });
});

// ===== CHAT ATTACHMENTS =====

// POST /api/attachments/chat  — send message with file
router.post('/chat', authenticate, chatUpload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  const { room='general', recipient_id } = req.body;
  const now = nowISO();
  const msgId = uuidv4();
  const rel   = path.relative(UPLOAD_BASE, req.file.path).replace(/\\/g, '/');

  // Create the chat message
  db.prepare(`INSERT INTO chat_messages (id,sender_id,recipient_id,room,content,msg_type,created_at) VALUES (?,?,?,?,?,?,?)`)
    .run(msgId, req.user.id, recipient_id||null, room, req.file.originalname, 'file', now);

  // Store attachment
  const attId = uuidv4();
  db.prepare(`INSERT INTO chat_attachments (id,message_id,original_name,stored_name,file_size,mime_type,file_path,created_at) VALUES (?,?,?,?,?,?,?,?)`)
    .run(attId, msgId, req.file.originalname, req.file.filename, req.file.size, req.file.mimetype, rel, now);

  const msg = db.prepare(`SELECT m.*,u.name as sender_name,u.color as sender_color,u.role as sender_role
    FROM chat_messages m JOIN users u ON m.sender_id=u.id WHERE m.id=?`).get(msgId);
  const att = db.prepare('SELECT * FROM chat_attachments WHERE id=?').get(attId);
  const payload = { ...msg, attachment: att };

  if (recipient_id) {
    sendToUser(recipient_id, { type:'chat:message', message:payload, dm:true });
    sendToUser(req.user.id,  { type:'chat:message', message:payload, dm:true });
  } else {
    broadcast({ type:'chat:message', message:payload, room });
  }
  res.status(201).json(payload);
});

// GET /api/attachments/chat-file/:id/download
router.get('/chat-file/:id/download', authenticate, (req, res) => {
  const att = db.prepare('SELECT * FROM chat_attachments WHERE id=?').get(req.params.id);
  if (!att) return res.status(404).json({ error: 'Not found' });
  const filePath = path.join(UPLOAD_BASE, att.file_path);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not found on disk' });
  res.setHeader('Content-Disposition', `attachment; filename="${att.original_name}"`);
  res.setHeader('Content-Type', att.mime_type);
  res.sendFile(filePath);
});

// GET /api/attachments/chat-file/:id/preview
router.get('/chat-file/:id/preview', authenticate, (req, res) => {
  const att = db.prepare('SELECT * FROM chat_attachments WHERE id=?').get(req.params.id);
  if (!att) return res.status(404).json({ error: 'Not found' });
  const filePath = path.join(UPLOAD_BASE, att.file_path);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not found' });
  res.setHeader('Content-Disposition', `inline; filename="${att.original_name}"`);
  res.setHeader('Content-Type', att.mime_type);
  res.sendFile(filePath);
});

module.exports = router;
