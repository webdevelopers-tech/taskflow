const router = require('express').Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../db/database');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { nowISO, logAudit, logActivity } = require('../utils/helpers');
const { broadcast } = require('../utils/websocket');

// GET /api/categories  — all active (any user needs this for dropdowns)
router.get('/', authenticate, (req, res) => {
  const includeInactive = req.query.all === 'true' && req.user.is_admin;
  const rows = db.prepare(`
    SELECT c.*, COUNT(cm.user_id) as member_count
    FROM categories c
    LEFT JOIN category_members cm ON c.id = cm.category_id
    ${includeInactive ? '' : "WHERE c.is_active = 1"}
    GROUP BY c.id ORDER BY c.sort_order, c.name
  `).all();
  res.json(rows);
});

// GET /api/categories/:id  — single with members
router.get('/:id', authenticate, (req, res) => {
  const cat = db.prepare('SELECT * FROM categories WHERE id=?').get(req.params.id);
  if (!cat) return res.status(404).json({ error: 'Category not found' });
  const members = db.prepare(`
    SELECT u.id,u.name,u.email,u.role,u.color,u.timezone,u.department
    FROM category_members cm JOIN users u ON cm.user_id=u.id WHERE cm.category_id=?
  `).all(req.params.id);
  res.json({ ...cat, members });
});

// POST /api/categories  — admin only
router.post('/', authenticate, requireAdmin, (req, res) => {
  const { name, color='#6366f1', icon='📁', description, sort_order=0 } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: 'Name required' });
  if (db.prepare('SELECT id FROM categories WHERE name=?').get(name.trim()))
    return res.status(400).json({ error: 'Category name already exists' });
  const id = 'cat_' + uuidv4().replace(/-/g,'').slice(0,8);
  const now = nowISO();
  db.prepare(`INSERT INTO categories (id,name,color,icon,description,is_active,sort_order,created_by,created_at,updated_at) VALUES (?,?,?,?,?,1,?,?,?,?)`)
    .run(id, name.trim(), color, icon, description||null, sort_order, req.user.id, now, now);
  logAudit(db, req.user.id, 'CREATE_CATEGORY', 'category', id, null, { name, color }, req);
  logActivity(db, req.user.id, 'created category', 'category', id, name);
  const cat = db.prepare('SELECT * FROM categories WHERE id=?').get(id);
  broadcast({ type: 'category:created', category: cat });
  res.status(201).json(cat);
});

// PUT /api/categories/:id  — admin only
router.put('/:id', authenticate, requireAdmin, (req, res) => {
  const cat = db.prepare('SELECT * FROM categories WHERE id=?').get(req.params.id);
  if (!cat) return res.status(404).json({ error: 'Not found' });
  const fields = ['name','color','icon','description','is_active','sort_order'];
  const updates = {};
  for (const f of fields) if (req.body[f] !== undefined) updates[f] = req.body[f];
  if (updates.name && updates.name !== cat.name) {
    if (db.prepare('SELECT id FROM categories WHERE name=? AND id!=?').get(updates.name, req.params.id))
      return res.status(400).json({ error: 'Name already exists' });
  }
  updates.updated_at = nowISO();
  const set = Object.keys(updates).map(k=>`${k}=?`).join(',');
  db.prepare(`UPDATE categories SET ${set} WHERE id=?`).run(...Object.values(updates), req.params.id);
  logAudit(db, req.user.id, 'UPDATE_CATEGORY', 'category', req.params.id, cat, updates, req);
  const updated = db.prepare('SELECT * FROM categories WHERE id=?').get(req.params.id);
  broadcast({ type: 'category:updated', category: updated });
  res.json(updated);
});

// DELETE /api/categories/:id  — admin only
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  const cat = db.prepare('SELECT * FROM categories WHERE id=?').get(req.params.id);
  if (!cat) return res.status(404).json({ error: 'Not found' });
  // Soft delete — just deactivate
  db.prepare("UPDATE categories SET is_active=0, updated_at=? WHERE id=?").run(nowISO(), req.params.id);
  logAudit(db, req.user.id, 'DELETE_CATEGORY', 'category', req.params.id, cat, null, req);
  broadcast({ type: 'category:deleted', categoryId: req.params.id });
  res.json({ ok: true });
});

// PUT /api/categories/:id/members  — assign employees
router.put('/:id/members', authenticate, requireAdmin, (req, res) => {
  const { user_ids } = req.body; // array
  if (!Array.isArray(user_ids)) return res.status(400).json({ error: 'user_ids must be array' });
  db.prepare('DELETE FROM category_members WHERE category_id=?').run(req.params.id);
  for (const uid of user_ids) {
    try {
      db.prepare('INSERT OR IGNORE INTO category_members (id,category_id,user_id) VALUES (?,?,?)').run(uuidv4(), req.params.id, uid);
    } catch {}
  }
  logActivity(db, req.user.id, 'updated category members', 'category', req.params.id, `${user_ids.length} members`);
  const members = db.prepare(`SELECT u.id,u.name,u.color,u.role FROM category_members cm JOIN users u ON cm.user_id=u.id WHERE cm.category_id=?`).all(req.params.id);
  broadcast({ type: 'category:members_updated', categoryId: req.params.id, members });
  res.json(members);
});

// GET /api/categories/user/:userId — categories for a user
router.get('/user/:userId', authenticate, (req, res) => {
  if (!req.user.is_admin && req.user.id !== req.params.userId) return res.status(403).json({ error: 'Forbidden' });
  res.json(db.prepare(`
    SELECT c.* FROM categories c
    JOIN category_members cm ON c.id=cm.category_id
    WHERE cm.user_id=? AND c.is_active=1 ORDER BY c.name
  `).all(req.params.userId));
});

module.exports = router;
