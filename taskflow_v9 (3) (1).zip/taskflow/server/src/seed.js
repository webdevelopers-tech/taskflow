require('dotenv').config();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { initDB, persist } = require('./db/database');

function d(offset) { const x=new Date(); x.setDate(x.getDate()+offset); return x.toISOString().split('T')[0]; }
function now(hoursAgo=0) { return new Date(Date.now()-hoursAgo*3600000).toISOString().replace('T',' ').split('.')[0]; }

async function seed() {
  const db = await initDB();
  console.log('🌱 Seeding...');
  db.exec(`DELETE FROM task_comments;DELETE FROM task_history;DELETE FROM notifications;DELETE FROM activity_log;DELETE FROM clock_sessions;DELETE FROM tasks;DELETE FROM work_schedules;DELETE FROM refresh_tokens;DELETE FROM audit_log;DELETE FROM users;`);

  const users = [
    { id:'usr_admin', name:'Sarah Mitchell', email:'admin@taskflow.io', password:'admin123', role:'Super Admin', department:'Management', is_admin:1, color:'#6366f1', timezone:'IST' },
    { id:'usr_001', name:'Alex Chen', email:'alex@taskflow.io', password:'pass123', role:'Senior Developer', department:'Engineering', is_admin:0, color:'#14b8a6', timezone:'CST' },
    { id:'usr_002', name:'Maya Patel', email:'maya@taskflow.io', password:'pass123', role:'Product Designer', department:'Design', is_admin:0, color:'#ec4899', timezone:'IST' },
    { id:'usr_003', name:'James Liu', email:'james@taskflow.io', password:'pass123', role:'Marketing Lead', department:'Marketing', is_admin:0, color:'#f59e0b', timezone:'CST' },
    { id:'usr_004', name:'Priya Sharma', email:'priya@taskflow.io', password:'pass123', role:'HR Manager', department:'Human Resources', is_admin:0, color:'#22c55e', timezone:'IST' },
    { id:'usr_005', name:'Marco Rossi', email:'marco@taskflow.io', password:'pass123', role:'Backend Engineer', department:'Engineering', is_admin:0, color:'#06b6d4', timezone:'CST' },
  ];
  for (const u of users) {
    db.prepare(`INSERT INTO users (id,name,email,password,role,department,is_admin,color,timezone,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
      .run(u.id,u.name,u.email,bcrypt.hashSync(u.password,10),u.role,u.department,u.is_admin,u.color,u.timezone,now(48),now(48));
  }
  const days=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  for (const u of users) for (const day of days)
    db.prepare('INSERT INTO work_schedules (id,user_id,day_of_week,is_working,start_time,end_time) VALUES (?,?,?,?,?,?)')
      .run(uuidv4(),u.id,day,!['Saturday','Sunday'].includes(day)?1:0,'09:00','17:00');

  const tasks = [
    { id:'tsk_001', title:'Redesign landing page hero section', desc:'Update hero with new brand colors and messaging for Q4 campaign.', to:'usr_002', by:'usr_admin', p:'high', s:'pending', c:'design', due:d(-1) },
    { id:'tsk_002', title:'Fix authentication bug in mobile app', desc:'Users cannot login on iOS 17.4+. Investigate JWT refresh token handling.', to:'usr_001', by:'usr_admin', p:'high', s:'in-progress', c:'development', due:d(0) },
    { id:'tsk_003', title:'Prepare Q3 marketing report', desc:'Compile metrics from Google Analytics, social media, and email campaigns.', to:'usr_003', by:'usr_004', p:'medium', s:'in-progress', c:'marketing', due:d(2) },
    { id:'tsk_004', title:'Onboard new developer', desc:'Set up accounts, tools, Git access, and schedule intro meetings.', to:'usr_004', by:'usr_admin', p:'medium', s:'pending', c:'hr', due:d(1) },
    { id:'tsk_005', title:'Update API documentation', desc:'Document all v3 endpoints including new webhook system.', to:'usr_001', by:'usr_001', p:'low', s:'closed', c:'development', due:d(-2), closedAt:d(-1) },
    { id:'tsk_006', title:'Team building event planning', desc:'Plan Q4 team outing — venue, activities, budget approval.', to:'usr_004', by:'usr_admin', p:'low', s:'pending', c:'hr', due:d(5) },
    { id:'tsk_007', title:'Social media content calendar', desc:'Plan 30 days of posts across LinkedIn, Twitter, and Instagram.', to:'usr_003', by:'usr_003', p:'medium', s:'in-progress', c:'marketing', due:d(3) },
    { id:'tsk_008', title:'Security audit review', desc:'Review penetration test findings and prioritize critical patches.', to:'usr_001', by:'usr_admin', p:'high', s:'pending', c:'development', due:d(-3) },
    { id:'tsk_009', title:'Employee satisfaction survey', desc:'Quarterly engagement survey — create, distribute, analyze results.', to:'usr_004', by:'usr_admin', p:'medium', s:'closed', c:'hr', due:d(-4), closedAt:d(-2) },
    { id:'tsk_010', title:'Brand guidelines v2', desc:'Update typography, color palette, and logo usage guidelines doc.', to:'usr_002', by:'usr_002', p:'medium', s:'pending', c:'design', due:d(4) },
    { id:'tsk_011', title:'Database query optimization', desc:'Identify and fix N+1 queries in the reporting module.', to:'usr_005', by:'usr_001', p:'high', s:'in-progress', c:'development', due:d(1) },
    { id:'tsk_012', title:'Setup CI/CD pipeline', desc:'Configure GitHub Actions for automated testing and deployment.', to:'usr_005', by:'usr_admin', p:'medium', s:'closed', c:'development', due:d(-5), closedAt:d(-3) },
    { id:'tsk_013', title:'GDPR compliance review', desc:'Audit data handling processes for GDPR and CCPA compliance.', to:'usr_004', by:'usr_admin', p:'high', s:'pending', c:'legal', due:d(7) },
    { id:'tsk_014', title:'Competitor analysis deck', desc:'Research top 5 competitors and create comparison presentation.', to:'usr_003', by:'usr_admin', p:'medium', s:'pending', c:'marketing', due:d(6) },
    { id:'tsk_015', title:'Mobile app UI refresh', desc:'Update navigation patterns and implement new design tokens.', to:'usr_002', by:'usr_001', p:'medium', s:'pending', c:'design', due:d(8) },
  ];
  for (const t of tasks) {
    db.prepare(`INSERT INTO tasks (id,title,description,assigned_to,assigned_by,priority,status,category,due_date,completed_at,closed_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(t.id,t.title,t.desc,t.to,t.by,t.p,t.s,t.c,t.due,t.closedAt||null,t.closedAt?t.to:null,now(72),now(24));
  }

  // History entries
  const histEntries = [
    { tid:'tsk_005', uid:'usr_001', action:'task_closed', field:'status', old:'in-progress', new:'closed', h:26 },
    { tid:'tsk_009', uid:'usr_004', action:'task_closed', field:'status', old:'in-progress', new:'closed', h:50 },
    { tid:'tsk_012', uid:'usr_005', action:'task_closed', field:'status', old:'in-progress', new:'closed', h:72 },
    { tid:'tsk_002', uid:'usr_001', action:'status_changed', field:'status', old:'pending', new:'in-progress', h:6 },
    { tid:'tsk_001', uid:'usr_admin', action:'priority_changed', field:'priority', old:'medium', new:'high', h:12 },
    { tid:'tsk_008', uid:'usr_admin', action:'task_created', field:null, old:null, new:'Security audit review', h:80 },
    { tid:'tsk_002', uid:'usr_admin', action:'comment_added', field:null, old:null, new:'Please resolve ASAP — customers reporting', h:5 },
    { tid:'tsk_011', uid:'usr_005', action:'comment_added', field:null, old:null, new:'Found 12 N+1 queries, adding eager loading', h:4 },
  ];
  for (const h of histEntries)
    db.prepare(`INSERT INTO task_history (id,task_id,user_id,action,field_name,old_value,new_value,created_at) VALUES (?,?,?,?,?,?,?,?)`)
      .run(uuidv4(),h.tid,h.uid,h.action,h.field,h.old,h.new,now(h.h));

  // Notifications
  const notifs = [
    { uid:'usr_001', title:'🔴 Task Overdue', msg:'Security audit review is 3 days overdue', type:'error', cat:'task_overdue', tid:'tsk_008', h:3 },
    { uid:'usr_002', title:'🔴 Task Overdue', msg:'Redesign landing page hero is 1 day overdue', type:'warning', cat:'task_overdue', tid:'tsk_001', h:5 },
    { uid:'usr_001', title:'📋 New Task Assigned', msg:'Fix authentication bug assigned — High Priority', type:'info', cat:'task_assigned', tid:'tsk_002', h:6 },
    { uid:'usr_admin', title:'✅ Task Closed', msg:'Alex Chen closed: Update API documentation', type:'success', cat:'task_closed', tid:'tsk_005', h:26 },
    { uid:'usr_003', title:'📅 Due Date Reminder', msg:'Q3 marketing report due in 2 days', type:'warning', cat:'task_overdue', tid:'tsk_003', h:1 },
    { uid:'usr_005', title:'📋 New Task Assigned', msg:'Database query optimization — assigned by Alex Chen', type:'info', cat:'task_assigned', tid:'tsk_011', h:10 },
  ];
  for (const n of notifs)
    db.prepare(`INSERT INTO notifications (id,user_id,title,message,type,category,task_id,is_read,created_at) VALUES (?,?,?,?,?,?,?,0,?)`)
      .run(uuidv4(),n.uid,n.title,n.msg,n.type,n.cat,n.tid,now(n.h));

  // Activity
  const acts = [
    { uid:'usr_001', action:'closed task', entity:'task', eid:'tsk_005', meta:'Update API documentation', h:26 },
    { uid:'usr_004', action:'closed task', entity:'task', eid:'tsk_009', meta:'Employee satisfaction survey', h:50 },
    { uid:'usr_005', action:'closed task', entity:'task', eid:'tsk_012', meta:'Setup CI/CD pipeline', h:72 },
    { uid:'usr_001', action:'updated task', entity:'task', eid:'tsk_002', meta:'Changed status to in-progress', h:6 },
    { uid:'usr_admin', action:'created task', entity:'task', eid:'tsk_013', meta:'GDPR compliance review', h:5 },
  ];
  for (const a of acts)
    db.prepare(`INSERT INTO activity_log (id,user_id,action,entity,entity_id,meta,created_at) VALUES (?,?,?,?,?,?,?)`)
      .run(uuidv4(),a.uid,a.action,a.entity,a.eid,a.meta,now(a.h));

  // Clock sessions
  for (const c of [{uid:'usr_001',d:1,in:8,out:16.5},{uid:'usr_001',d:2,in:8.1,out:16.2},{uid:'usr_002',d:1,in:9.2,out:18.1},{uid:'usr_003',d:1,in:10,out:18},{uid:'usr_004',d:1,in:9.5,out:17.5},{uid:'usr_005',d:1,in:9,out:17}]) {
    const base=new Date(); base.setDate(base.getDate()-c.d);
    const ds=base.toISOString().split('T')[0];
    const cin=new Date(base); cin.setHours(Math.floor(c.in),Math.round((c.in%1)*60),0);
    const cout=new Date(base); cout.setHours(Math.floor(c.out),Math.round((c.out%1)*60),0);
    const mins=Math.round((cout-cin)/60000);
    db.prepare(`INSERT INTO clock_sessions (id,user_id,clock_in,clock_out,duration_minutes,date,created_at) VALUES (?,?,?,?,?,?,?)`)
      .run(uuidv4(),c.uid,cin.toISOString().replace('T',' ').split('.')[0],cout.toISOString().replace('T',' ').split('.')[0],mins,ds,now(c.d*24));
  }

  persist();
  console.log('\n✅ Seeded successfully!');
  console.log('  admin@taskflow.io / admin123 (Super Admin — IST)');
  console.log('  alex@taskflow.io  / pass123  (Developer — CST)');
  console.log('  maya@taskflow.io  / pass123  (Designer — IST)');
  console.log('  james@taskflow.io / pass123  (Marketing — CST)');
  console.log('  priya@taskflow.io / pass123  (HR — IST)');
  console.log('  marco@taskflow.io / pass123  (Engineer — CST)');
  process.exit(0);
}
seed().catch(e => { console.error(e); process.exit(1); });
