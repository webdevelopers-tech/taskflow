import axios from 'axios';

const api = axios.create({ baseURL:'/api', timeout:12000 });

api.interceptors.request.use(c => {
  const t = localStorage.getItem('accessToken');
  if (t) c.headers.Authorization = `Bearer ${t}`;
  return c;
});

api.interceptors.response.use(r => r, async err => {
  const orig = err.config;
  if (err.response?.status===401 && !orig._retry) {
    orig._retry = true;
    try {
      const rt = localStorage.getItem('refreshToken');
      if (!rt) throw new Error('no refresh');
      const { data } = await axios.post('/api/auth/refresh', { refreshToken: rt });
      localStorage.setItem('accessToken', data.accessToken);
      localStorage.setItem('refreshToken', data.refreshToken);
      orig.headers.Authorization = `Bearer ${data.accessToken}`;
      return api(orig);
    } catch { localStorage.clear(); window.location.href='/login'; }
  }
  return Promise.reject(err);
});

// Timezone utilities
export const TIMEZONES = {
  IST: { label:'India Standard Time (IST)', tz:'Asia/Kolkata', abbr:'IST', utcOffset:'+5:30' },
  CST: { label:'USA Chicago Time (CST/CDT)', tz:'America/Chicago', abbr:'CST', utcOffset:'-6:00' }
};

export function formatDateTime(isoStr, userTz='IST', opts={}) {
  if (!isoStr) return '—';
  const tzName = TIMEZONES[userTz]?.tz || 'Asia/Kolkata';
  const abbr = TIMEZONES[userTz]?.abbr || 'IST';
  try {
    const date = new Date(isoStr.includes('T') ? isoStr : isoStr.replace(' ','T')+'Z');
    const formatted = date.toLocaleString('en-US', {
      timeZone: tzName, month:'short', day:'numeric', year:'numeric',
      hour:'2-digit', minute:'2-digit', hour12:true, ...opts
    });
    return `${formatted} ${abbr}`;
  } catch { return isoStr; }
}

export function formatDate(isoStr, userTz='IST') {
  if (!isoStr) return '—';
  try {
    const tzName = TIMEZONES[userTz]?.tz || 'Asia/Kolkata';
    const abbr   = TIMEZONES[userTz]?.abbr || 'IST';
    const date = new Date(isoStr.includes('T') ? isoStr : isoStr+'T00:00:00');
    return date.toLocaleDateString('en-US', { timeZone:tzName, month:'short', day:'numeric', year:'numeric' })+' '+abbr;
  } catch { return isoStr; }
}

export function liveTime(userTz='IST') {
  const tzName = TIMEZONES[userTz]?.tz || 'Asia/Kolkata';
  const abbr   = TIMEZONES[userTz]?.abbr || 'IST';
  return new Date().toLocaleTimeString('en-US', { timeZone:tzName, hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:true })+' '+abbr;
}

export function isOverdue(dueDateStr) {
  return dueDateStr && new Date(dueDateStr) < new Date(new Date().toISOString().split('T')[0]);
}

// Auth
export const login           = (e,p)     => api.post('/auth/login',{email:e,password:p}).then(r=>r.data);
export const logout          = (rt)      => api.post('/auth/logout',{refreshToken:rt});
export const getMe           = ()        => api.get('/auth/me').then(r=>r.data);
export const updateProfile   = (d)       => api.put('/auth/profile',d).then(r=>r.data);
export const changePassword  = (d)       => api.put('/auth/change-password',d);

// Users
export const getUsers        = ()        => api.get('/users').then(r=>r.data);
export const getUser         = (id)      => api.get(`/users/${id}`).then(r=>r.data);
export const createUser      = (d)       => api.post('/users',d).then(r=>r.data);
export const updateUser      = (id,d)    => api.put(`/users/${id}`,d).then(r=>r.data);
export const deleteUser      = (id)      => api.delete(`/users/${id}`);
export const updateSchedule  = (id,s)    => api.put(`/users/${id}/schedule`,{schedule:s}).then(r=>r.data);

// Tasks
export const getTasks        = (p)       => api.get('/tasks',{params:p}).then(r=>r.data);
export const getTask         = (id)      => api.get(`/tasks/${id}`).then(r=>r.data);
export const getTaskStats    = ()        => api.get('/tasks/stats').then(r=>r.data);
export const createTask      = (d)       => api.post('/tasks',d).then(r=>r.data);
export const updateTask      = (id,d)    => api.put(`/tasks/${id}`,d).then(r=>r.data);
export const deleteTask      = (id)      => api.delete(`/tasks/${id}`);
export const addComment      = (id,c)    => api.post(`/tasks/${id}/comments`,{content:c}).then(r=>r.data);

// Clock
export const clockIn         = (note)    => api.post('/clock/in',{note}).then(r=>r.data);
export const clockOut        = ()        => api.post('/clock/out').then(r=>r.data);
export const getTodayClock   = ()        => api.get('/clock/today').then(r=>r.data);
export const getClockHistory = (p)       => api.get('/clock/history',{params:p}).then(r=>r.data);
export const getTeamClock    = ()        => api.get('/clock/team').then(r=>r.data);

// Notifications
export const getNotifications= (p)       => api.get('/notifications',{params:p}).then(r=>r.data);
export const markRead        = (id)      => api.put(`/notifications/${id}/read`);
export const markAllRead     = ()        => api.put('/notifications/read-all');
export const deleteNotif     = (id)      => api.delete(`/notifications/${id}`);

// History & analytics
export const getHistory      = (p)       => api.get('/history',{params:p}).then(r=>r.data);
export const getEmployeeAnalytics = (p)  => api.get('/analytics/employees',{params:p}).then(r=>r.data);
export const getProductivity = (period)  => api.get('/productivity/report',{params:{period}}).then(r=>r.data);
export const getActivity     = (p)       => api.get('/activity',{params:p}).then(r=>r.data);
export const getAuditLog     = (p)       => api.get('/audit',{params:p}).then(r=>r.data);

// Branding
export const getBranding     = ()        => api.get('/branding').then(r=>r.data);
export const updateBranding  = (d)       => api.put('/branding',d).then(r=>r.data);

// Exports
export const exportTasks     = (p={})    => { window.open(`/api/export/tasks?${new URLSearchParams({...p,_t:localStorage.getItem('accessToken')}).toString()}`); };
export const exportEmployees = ()        => { window.open(`/api/export/employees?_t=${localStorage.getItem('accessToken')}`); };
export const exportHistory   = (p={})    => { window.open(`/api/export/history?${new URLSearchParams({...p,_t:localStorage.getItem('accessToken')}).toString()}`); };

export default api;

// Categories
export const getCategories      = (p)    => api.get('/categories', {params:p}).then(r=>r.data);
export const getCategory        = (id)   => api.get(`/categories/${id}`).then(r=>r.data);
export const createCategory     = (d)    => api.post('/categories',d).then(r=>r.data);
export const updateCategory     = (id,d) => api.put(`/categories/${id}`,d).then(r=>r.data);
export const deleteCategory     = (id)   => api.delete(`/categories/${id}`);
export const updateCategoryMembers = (id,user_ids) => api.put(`/categories/${id}/members`,{user_ids}).then(r=>r.data);

// Task Reminders
export const getTaskReminders   = (p)    => api.get('/task-reminders', {params:p}).then(r=>r.data);
export const getReminderStats   = ()     => api.get('/task-reminders/stats').then(r=>r.data);
export const createTaskReminder = (d)    => api.post('/task-reminders',d).then(r=>r.data);
export const updateTaskReminder = (id,d) => api.put(`/task-reminders/${id}`,d).then(r=>r.data);
export const deleteTaskReminder = (id)   => api.delete(`/task-reminders/${id}`);

// Full exports
export const exportFull    = () => { window.open(`/api/export/full?_t=${localStorage.getItem('accessToken')}`); };
export const exportBackup  = () => { window.open(`/api/export/backup?_t=${localStorage.getItem('accessToken')}`); };

// Enhanced clock
export const clockPause  = ()      => api.post('/clock/pause').then(r=>r.data);
export const clockResume = ()      => api.post('/clock/resume').then(r=>r.data);
export const clockBreak  = (type)  => api.post('/clock/break',{break_type:type}).then(r=>r.data);

// Team Chat
export const getChatMessages = (p) => api.get('/chat/messages',{params:p}).then(r=>r.data);
export const sendChatMessage = (d)  => api.post('/chat/messages',d).then(r=>r.data);
export const deleteChatMsg   = (id) => api.delete(`/chat/messages/${id}`);
export const getChatUnread   = ()   => api.get('/chat/unread').then(r=>r.data);

// Task Attachments
export const getTaskAttachments  = (taskId)     => api.get(`/attachments/task/${taskId}`).then(r=>r.data);
export const deleteTaskAttachment= (id)          => api.delete(`/attachments/task-file/${id}`);
export const taskAttachmentDownloadUrl = (id)    => `/api/attachments/task-file/${id}/download?_t=${localStorage.getItem('accessToken')}`;
export const taskAttachmentPreviewUrl  = (id)    => `/api/attachments/task-file/${id}/preview?_t=${localStorage.getItem('accessToken')}`;
export const uploadTaskAttachment = (taskId, file, onProgress) => {
  const fd = new FormData(); fd.append('file', file);
  return api.post(`/attachments/task/${taskId}`, fd, {
    headers: {'Content-Type':'multipart/form-data'},
    onUploadProgress: e => onProgress && onProgress(Math.round(e.loaded/e.total*100))
  }).then(r=>r.data);
};

// Chat Attachments
export const chatAttachmentDownloadUrl = (id)   => `/api/attachments/chat-file/${id}/download?_t=${localStorage.getItem('accessToken')}`;
export const chatAttachmentPreviewUrl  = (id)   => `/api/attachments/chat-file/${id}/preview?_t=${localStorage.getItem('accessToken')}`;
export const uploadChatAttachment = (room, recipientId, file, onProgress) => {
  const fd = new FormData();
  fd.append('file', file);
  if (recipientId) fd.append('recipient_id', recipientId);
  else fd.append('room', room);
  return api.post('/attachments/chat', fd, {
    headers: {'Content-Type':'multipart/form-data'},
    onUploadProgress: e => onProgress && onProgress(Math.round(e.loaded/e.total*100))
  }).then(r=>r.data);
};

// Enhanced analytics
export const getTaskAnalytics = (p) => api.get('/analytics/tasks',{params:p}).then(r=>r.data);
export const getProductivityReport = (p) => api.get('/productivity/report',{params:p}).then(r=>r.data);
