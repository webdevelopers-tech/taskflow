import { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { login as apiLogin, logout as apiLogout, getMe, getBranding } from '../utils/api';

const AuthContext = createContext(null);
const WSContext   = createContext(null);
export const BrandContext = createContext({});

export function AuthProvider({ children }) {
  const [user,      setUser]      = useState(null);
  const [schedule,  setSchedule]  = useState([]);
  const [activeSession, setActiveSession] = useState(null);
  const [brand,     setBrand]     = useState({});
  const [loading,   setLoading]   = useState(true);

  const applyBrand = (b) => {
    if (!b) return;
    setBrand(b);
    const root = document.documentElement;
    if (b.primary_color)   root.style.setProperty('--brand-primary',   b.primary_color);
    if (b.secondary_color) root.style.setProperty('--brand-secondary',  b.secondary_color);
    if (b.accent_color)    root.style.setProperty('--brand-accent',     b.accent_color);
    if (b.sidebar_color)   root.style.setProperty('--brand-sidebar',    b.sidebar_color);
    if (b.header_color)    root.style.setProperty('--brand-header',     b.header_color);
    if (b.primary_color)   root.style.setProperty('--accent',           b.primary_color);
    if (b.font_family && b.font_family !== 'Inter') {
      root.style.setProperty('--font', `'${b.font_family}', system-ui, sans-serif`);
    }
    if (b.company_name) document.title = b.company_name;
    if (b.favicon_url) {
      let link = document.querySelector("link[rel~='icon']");
      if (!link) { link = document.createElement('link'); link.rel='icon'; document.head.appendChild(link); }
      link.href = b.favicon_url;
    }
  };

  useEffect(() => {
    // Always load branding first (even before login)
    getBranding().then(applyBrand).catch(()=>{});
    const token = localStorage.getItem('accessToken');
    if (token) {
      getMe().then(({ user, schedule, activeSession, brand }) => {
        setUser(user); setSchedule(schedule); setActiveSession(activeSession);
        if (brand) applyBrand(brand);
      }).catch(() => localStorage.clear()).finally(() => setLoading(false));
    } else { setLoading(false); }
  }, []);

  const login = async (email, password) => {
    const data = await apiLogin(email, password);
    localStorage.setItem('accessToken', data.accessToken);
    localStorage.setItem('refreshToken', data.refreshToken);
    setUser(data.user);
    if (data.brand) applyBrand(data.brand);
    return data;
  };

  const logout = async () => {
    await apiLogout(localStorage.getItem('refreshToken')).catch(()=>{});
    localStorage.clear(); setUser(null);
  };

  const refreshMe = async () => {
    const d = await getMe();
    setUser(d.user); setSchedule(d.schedule); setActiveSession(d.activeSession);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, schedule, setSchedule, activeSession, setActiveSession, brand, applyBrand, login, logout, loading, refreshMe }}>
      {children}
    </AuthContext.Provider>
  );
}

export function WSProvider({ children }) {
  const { user } = useAuth();
  const wsRef = useRef(null);
  const listenersRef = useRef({});
  const [connected, setConnected] = useState(false);

  const subscribe = useCallback((type, fn) => {
    if (!listenersRef.current[type]) listenersRef.current[type] = new Set();
    listenersRef.current[type].add(fn);
    return () => listenersRef.current[type]?.delete(fn);
  }, []);

  useEffect(() => {
    if (!user) return;
    const token = localStorage.getItem('accessToken');
    const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${window.location.host}/ws?token=${token}`);
    wsRef.current = ws;
    ws.onopen = () => setConnected(true);
    ws.onclose = () => { setConnected(false); wsRef.current = null; };
    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        listenersRef.current[msg.type]?.forEach(fn => fn(msg));
        listenersRef.current['*']?.forEach(fn => fn(msg));
      } catch {}
    };
    const ping = setInterval(() => { if (ws.readyState===1) ws.send(JSON.stringify({type:'ping'})); }, 25000);
    return () => { clearInterval(ping); ws.close(); };
  }, [user]);

  return <WSContext.Provider value={{ connected, subscribe }}>{children}</WSContext.Provider>;
}

export const useAuth  = () => useContext(AuthContext);
export const useWS    = () => useContext(WSContext);
export const useBrand = () => useContext(BrandContext);
