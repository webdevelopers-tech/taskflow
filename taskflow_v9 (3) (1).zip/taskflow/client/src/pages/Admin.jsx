import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Avatar, PageLoader, Modal, FormGroup, Toggle, SectionHeader, ProgressBar } from '../components/UI';
import { getUsers, createUser, updateUser, deleteUser, updateSchedule, getEmployeeAnalytics, exportTasks, exportEmployees, getCategories } from '../utils/api';
import toast from 'react-hot-toast';

const COLORS = ['#6366f1', '#ec4899', '#14b8a6', '#f59e0b', '#22c55e', '#ef4444', '#8b5cf6', '#06b6d4'];

export default function Admin() {
  const { user } = useAuth();
  const [tab, setTab]           = useState('employees');
  const [users, setUsers]       = useState([]);
  const [analytics, setAnalytics] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [empModal, setEmpModal] = useState(false);
  const [schedModal, setSchedModal] = useState(false);
  const [editEmp, setEditEmp]   = useState(null);
  const [schedEmp, setSchedEmp] = useState(null);
  const [searchQ, setSearchQ]   = useState('');

  if (!user.is_admin) return <div style={{ padding: 40, color: 'var(--red)', fontSize: 16 }}>⛔ Admin access required.</div>;

  const load = async () => {
    try {
      const [u, a, c] = await Promise.all([getUsers(), getEmployeeAnalytics(), getCategories()]);
      setUsers(u); setAnalytics(a); setCategories(c);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  if (loading) return <PageLoader />;

  return (
    <div className="fade-up">
      <SectionHeader
        title="⚙ Admin Panel"
        sub="Manage employees, schedules and exports"
        action={
          <div className="flex gap-8">
            <button className="btn btn-ghost" onClick={exportEmployees}>📥 Export Employees</button>
            <button className="btn btn-ghost" onClick={() => exportTasks()}>📥 Export Tasks</button>
            <button className="btn btn-accent" onClick={() => { setEditEmp(null); setEmpModal(true); }}>➕ Add Employee</button>
          </div>
        }
      />

      <div className="tabs">
        {[['employees', '👤 Employees'], ['performance', '📊 Performance'], ['schedules', '📅 Schedules']].map(([k, l]) => (
          <div key={k} className={`tab ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{l}</div>
        ))}
      </div>

      {tab === 'employees' && (
        <div>
          <div className="card card-sm mb-12" style={{ display:'flex', gap:10 }}>
            <div style={{ flex:1, position:'relative' }}>
              <span style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'var(--text3)' }}>⌕</span>
              <input className="input" value={searchQ} onChange={e=>setSearchQ(e.target.value)} placeholder="Search by name, email, role…" style={{ paddingLeft:32 }} />
            </div>
          </div>
          <div className="card" style={{ overflow: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr><th>Employee</th><th>Department</th><th>Role</th><th>Timezone</th><th>Last Login</th><th>Admin</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {users.filter(u=>!searchQ||u.name.toLowerCase().includes(searchQ.toLowerCase())||u.email.toLowerCase().includes(searchQ.toLowerCase())||u.role.toLowerCase().includes(searchQ.toLowerCase())).map(u => (
                <tr key={u.id}>
                  <td>
                    <div className="flex items-center gap-10">
                      <Avatar name={u.name} color={u.color} size="sm" />
                      <div>
                        <div style={{ fontWeight: 500 }}>{u.name}</div>
                        <div style={{ fontSize: 11, color: 'var(--text2)' }}>{u.email}</div>
                      </div>
                    </div>
                  </td>
                  <td><code style={{ fontFamily: 'var(--mono)', fontSize: 11, background: 'var(--bg3)', padding: '2px 6px', borderRadius: 4 }}>{u.id}</code></td>
                  <td style={{ fontSize: 12 }}>{u.department}</td>
                  <td style={{ fontSize: 12 }}>{u.role}</td>
                  <td><span className={`badge ${u.timezone === 'IST' ? 'badge-purple' : 'badge-teal'}`}>{u.timezone}</span></td>
                  <td style={{ fontSize: 11, color: 'var(--text3)' }}>{u.last_login ? u.last_login.split(' ')[0] : 'Never'}</td>
                  <td>{u.is_admin ? <span className="badge badge-red">Admin</span> : <span style={{ color: 'var(--text3)', fontSize: 12 }}>—</span>}</td>
                  <td>
                    <div className="flex gap-6">
                      <button className="btn btn-ghost btn-sm" onClick={() => { setEditEmp(u); setEmpModal(true); }}>✎ Edit</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => { setSchedEmp(u); setSchedModal(true); }}>📅</button>
                      {u.id !== user.id && <button className="btn btn-danger btn-sm" onClick={async () => { if (!confirm(`Remove ${u.name}?`)) return; await deleteUser(u.id); toast.success('Deactivated'); load(); }}>✕</button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        </div>
      )}

      {tab === 'performance' && (
        <div>
          <div className="card card-sm mb-12" style={{ display:'flex', gap:10 }}>
            <div style={{ flex:1, position:'relative' }}>
              <span style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'var(--text3)' }}>⌕</span>
              <input className="input" value={searchQ} onChange={e=>setSearchQ(e.target.value)} placeholder="Filter by name or department…" style={{ paddingLeft:32 }} />
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {analytics.filter(e=>!searchQ||e.name.toLowerCase().includes(searchQ.toLowerCase())||e.department?.toLowerCase().includes(searchQ.toLowerCase())).map(emp => {
            const rate = emp.completion_rate || 0;
            const rateColor = rate >= 80 ? 'var(--green)' : rate >= 50 ? 'var(--amber)' : 'var(--red)';
            const hoursLogged = emp.total_minutes ? Math.round(emp.total_minutes/60*10)/10 : 0;
            return (
              <div key={emp.id} className="card card-sm">
                <div className="flex items-center gap-14">
                  <Avatar name={emp.name} color={emp.color} size="md" />
                  <div style={{ flex: 1 }}>
                    <div className="flex items-center gap-10 mb-4">
                      <span style={{ fontWeight: 600, fontSize: 14 }}>{emp.name}</span>
                      <span className={`badge ${emp.timezone === 'IST' ? 'badge-purple' : 'badge-teal'}`}>{emp.timezone}</span>
                      <span className="badge badge-gray">{emp.department}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text2)', marginBottom: 6 }}>{emp.role}</div>
                    <div style={{ fontSize:11, color:'var(--text3)', marginBottom:5 }}>Completion rate</div>
                    <ProgressBar value={rate} color={rateColor} height={5} />
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 12, minWidth: 400 }}>
                    {[
                      { l: 'Assigned',   v: emp.total_assigned || 0,   c: 'var(--text)' },
                      { l: 'Closed',     v: emp.total_closed || 0,      c: 'var(--green)' },
                      { l: 'Pending',    v: emp.pending || 0,            c: 'var(--amber)' },
                      { l: 'Overdue',    v: emp.overdue || 0,           c: emp.overdue > 0 ? 'var(--red)' : 'var(--text3)' },
                      { l: 'Rate',       v: rate + '%',                  c: rateColor },
                    ].map(s => (
                      <div key={s.l} style={{ textAlign: 'center', padding:'8px 4px', background:'var(--bg3)', borderRadius:'var(--radius-sm)' }}>
                        <div style={{ fontSize: 18, fontWeight: 700, color: s.c, letterSpacing: '-.5px' }}>{s.v}</div>
                        <div style={{ fontSize: 10, color: 'var(--text3)', marginTop:2 }}>{s.l}</div>
                      </div>
                    ))}
                  </div>
                </div>
                {/* Second row: hours + last login */}
                <div style={{ marginTop:10, paddingTop:8, borderTop:'1px solid var(--border)', display:'flex', gap:20, fontSize:12, color:'var(--text2)' }}>
                  <span>🕐 Hours logged: <strong>{hoursLogged}h</strong></span>
                  <span>📅 Avg close: <strong>{emp.avg_days_to_close ? emp.avg_days_to_close+'d' : '—'}</strong></span>
                  <span>🔑 Last login: <strong>{emp.last_login ? emp.last_login.split(' ')[0] : 'Never'}</strong></span>
                </div>
              </div>
            );
          })}
          </div>
        </div>
      )}

      {tab === 'schedules' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {users.map(u => (
            <div key={u.id} className="card card-sm flex items-center justify-between" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div className="flex items-center gap-12">
                <Avatar name={u.name} color={u.color} size="sm" />
                <div>
                  <div style={{ fontWeight: 500 }}>{u.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text2)' }}>{u.role} · {u.department}</div>
                </div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={() => { setSchedEmp(u); setSchedModal(true); }}>📅 Edit Schedule</button>
            </div>
          ))}
        </div>
      )}

      <EmployeeModal open={empModal} onClose={() => setEmpModal(false)} editData={editEmp} onSave={() => { load(); setEmpModal(false); }} categories={categories} />
      {schedEmp && <ScheduleModal open={schedModal} onClose={() => setSchedModal(false)} empId={schedEmp.id} empName={schedEmp.name} onSave={() => { load(); setSchedModal(false); }} />}
    </div>
  );
}

function EmployeeModal({ open, onClose, editData, onSave, categories=[] }) {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: '', department: 'Engineering', timezone: 'IST', color: '#6366f1', is_admin: false });
  const [saving, setSaving] = useState(false);

  // Build dept list from categories + fallback defaults
  const deptOptions = categories.length > 0
    ? categories.map(c=>c.name)
    : ['Engineering','Design','Marketing','Human Resources','Finance','Operations','Management','Legal'];

  useEffect(() => {
    if (editData) setForm({ name: editData.name, email: editData.email, password: '', role: editData.role, department: editData.department, timezone: editData.timezone, color: editData.color, is_admin: !!editData.is_admin });
    else setForm({ name: '', email: '', password: '', role: '', department: deptOptions[0]||'Engineering', timezone: 'IST', color: '#6366f1', is_admin: false });
  }, [editData, open]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const save = async () => {
    if (!form.name || !form.email) return toast.error('Name and email required');
    if (!editData && !form.password) return toast.error('Password required for new employee');
    setSaving(true);
    try {
      if (editData) await updateUser(editData.id, form);
      else await createUser(form);
      toast.success(editData ? '✅ Employee updated' : '✅ Employee added');
      onSave();
    } catch (e) { toast.error(e.response?.data?.error || 'Failed to save'); }
    setSaving(false);
  };

  return (
    <Modal open={open} onClose={onClose} title={editData ? '✎ Edit Employee' : '➕ Add Employee'} width={580}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FormGroup label="Full Name" required><input className="input" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Jane Smith" /></FormGroup>
        <FormGroup label="Email" required><input className="input" type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="jane@company.com" /></FormGroup>
        <FormGroup label={editData ? 'New Password' : 'Password'} required={!editData}><input className="input" type="password" value={form.password} onChange={e => set('password', e.target.value)} placeholder={editData ? 'Leave blank to keep' : 'Min 6 characters'} /></FormGroup>
        <FormGroup label="Role / Title"><input className="input" value={form.role} onChange={e => set('role', e.target.value)} placeholder="e.g. Senior Developer" /></FormGroup>
        <FormGroup label="Department / Category" hint={categories.length?`${categories.length} categories from system`:'Default departments'}>
          <select className="input" value={form.department} onChange={e => set('department', e.target.value)}>
            {deptOptions.map(d => <option key={d}>{d}</option>)}
          </select>
        </FormGroup>
        <FormGroup label="Timezone" hint="Only IST and CST supported">
          <select className="input" value={form.timezone} onChange={e => set('timezone', e.target.value)}>
            <option value="IST">🇮🇳 India Standard Time (IST)</option>
            <option value="CST">🇺🇸 USA Chicago Time (CST)</option>
          </select>
        </FormGroup>
      </div>
      <div className="flex items-center gap-10 mb-16" style={{ flexWrap: 'wrap' }}>
        <div className="label" style={{ marginBottom: 0, minWidth: 80 }}>Avatar Color</div>
        {COLORS.map(c => (
          <div key={c} onClick={() => set('color', c)} style={{ width: 26, height: 26, borderRadius: '50%', background: c, cursor: 'pointer', border: form.color === c ? '3px solid white' : '3px solid transparent', boxShadow: form.color === c ? `0 0 0 2px ${c}` : 'none', transition: 'all .15s' }} />
        ))}
        <input type="color" value={form.color} onChange={e => set('color', e.target.value)} style={{ width: 30, height: 26, borderRadius: 4, cursor: 'pointer', border: 'none', padding: 1, background: 'var(--bg3)' }} title="Custom color" />
      </div>
      <div className="flex items-center gap-10 mb-16">
        <Toggle on={form.is_admin} onChange={v => set('is_admin', v)} />
        <span style={{ fontSize: 13 }}>Grant admin privileges</span>
        {form.is_admin && <span className="badge badge-red">⚠ Admin can access all data</span>}
      </div>
      <div className="flex gap-10 justify-end pt-16" style={{ borderTop: '1px solid var(--border)' }}>
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-accent" onClick={save} disabled={saving}>{saving ? 'Saving…' : editData ? 'Save Changes' : 'Add Employee'}</button>
      </div>
    </Modal>
  );
}

function ScheduleModal({ open, onClose, empId, empName, onSave }) {
  const [sched, setSched] = useState([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!open || !empId) return;
    import('../utils/api').then(({ getUser }) => {
      getUser(empId).then(d => { setSched(d.schedule || []); setLoading(false); });
    });
  }, [open, empId]);

  const update = (day, field, value) => setSched(s => s.map(d => d.day_of_week === day ? { ...d, [field]: value } : d));

  const save = async () => {
    setSaving(true);
    try {
      await updateSchedule(empId, sched.map(d => ({ day_of_week: d.day_of_week, is_working: d.is_working ? 1 : 0, start_time: d.start_time, end_time: d.end_time })));
      toast.success(`✅ ${empName}'s schedule updated`);
      onSave();
    } catch { toast.error('Failed'); }
    setSaving(false);
  };

  return (
    <Modal open={open} onClose={onClose} title={`📅 ${empName}'s Schedule`}>
      {loading ? <div style={{ padding: 30, textAlign: 'center' }}>Loading…</div> : sched.map(d => (
        <div key={d.day_of_week} className="flex items-center gap-10" style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
          <div style={{ width: 90, fontSize: 13, fontWeight: d.is_working ? 600 : 400, color: d.is_working ? 'var(--text)' : 'var(--text3)' }}>{d.day_of_week.slice(0, 3)}</div>
          <Toggle on={!!d.is_working} onChange={v => update(d.day_of_week, 'is_working', v)} />
          <input type="time" className="input" value={d.start_time} onChange={e => update(d.day_of_week, 'start_time', e.target.value)} style={{ width: 90, opacity: d.is_working ? 1 : .35 }} />
          <span style={{ color: 'var(--text3)' }}>→</span>
          <input type="time" className="input" value={d.end_time} onChange={e => update(d.day_of_week, 'end_time', e.target.value)} style={{ width: 90, opacity: d.is_working ? 1 : .35 }} />
        </div>
      ))}
      <div className="flex gap-10 justify-end mt-16">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-accent" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save Schedule'}</button>
      </div>
    </Modal>
  );
}
