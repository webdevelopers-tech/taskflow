import { useState, useEffect, useCallback } from 'react';
import { useWS, useAuth } from '../context/AuthContext';
import { PageLoader, EmptyState, SectionHeader, NotifTypeIcon, Modal, FormGroup, Avatar, Spinner } from '../components/UI';
import { getNotifications, markRead, markAllRead, deleteNotif, getTaskReminders, getReminderStats, updateTaskReminder, deleteTaskReminder, createTaskReminder, getTasks, getUsers, updateTask } from '../utils/api';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

const SOUND_TONES = [
  { value:'alert',   label:'🚨 Alert',    desc:'Urgent beeps' },
  { value:'bell',    label:'🔔 Bell',     desc:'Classic bell' },
  { value:'chime',   label:'🎵 Chime',    desc:'Ascending melody' },
  { value:'warning', label:'⚠️ Warning',  desc:'Low warning' },
];

const REPEAT_OPTIONS = [
  { value:0,    label:'Once only' },
  { value:15,   label:'Every 15 minutes' },
  { value:30,   label:'Every 30 minutes' },
  { value:60,   label:'Every 1 hour' },
  { value:120,  label:'Every 2 hours' },
  { value:240,  label:'Every 4 hours' },
  { value:480,  label:'Every 8 hours' },
  { value:1440, label:'Every day' },
];

const NOTIF_CATS = [
  { key:'', label:'All' }, { key:'task_assigned', label:'📋 Assigned' },
  { key:'task_closed', label:'✅ Closed' }, { key:'task_updated', label:'✏️ Updated' },
  { key:'task_reopened', label:'🔄 Reopened' }, { key:'comment_added', label:'💬 Comments' },
  { key:'priority_changed', label:'⚡ Priority' }, { key:'due_date_changed', label:'📅 Due Date' },
  { key:'task_overdue', label:'🔴 Overdue' }, { key:'task_reminder', label:'⏰ Reminders' },
];

function playPreviewTone(tone) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const play = (freq, start, dur, type='sine', vol=0.3) => {
      const osc=ctx.createOscillator(), g=ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.type=type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime+start);
      g.gain.setValueAtTime(vol, ctx.currentTime+start);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime+start+dur);
      osc.start(ctx.currentTime+start); osc.stop(ctx.currentTime+start+dur);
    };
    switch(tone) {
      case 'alert':   play(660,0,.15,'square',.2); play(660,.2,.15,'square',.2); play(880,.4,.25,'square',.2); break;
      case 'bell':    play(880,0,.4); play(1100,.08,.35); play(880,.2,.3); break;
      case 'chime':   play(1047,0,.3); play(1319,.12,.3); play(1568,.24,.4); break;
      case 'warning': play(440,0,.2,'triangle',.25); play(330,.25,.3,'triangle',.2); break;
    }
  } catch {}
}

export default function Reminders() {
  const { user } = useAuth();
  const { subscribe } = useWS();
  const navigate = useNavigate();
  const [mainTab, setMainTab] = useState('reminders');

  // Create reminder state — step-by-step wizard
  const [createModal, setCreateModal] = useState(false);
  const [wizardStep, setWizardStep]   = useState(1); // 1=who, 2=note, 3=when, 4=interval+sound
  const [tasks,  setTasks]  = useState([]);
  const [users,  setUsers]  = useState([]);
  const [form, setForm] = useState({
    target_user_id: user?.id || '',
    remind_at: '',
    timezone: user?.timezone || 'IST',
    note: '',
    sound_tone: 'alert',
    repeat_interval: 0,
    repeat_until: '',
  });
  const [creating, setCreating] = useState(false);
  const setF = (k, v) => setForm(f => ({ ...f, [k]: v }));

  // Notifications
  const [notifications, setNotifications] = useState([]);
  const [unread, setUnread]   = useState(0);
  const [notifLoading, setNotifLoading] = useState(true);
  const [search, setSearch]   = useState('');
  const [category, setCategory] = useState('');
  const [readFilter, setReadFilter] = useState('');

  // Reminder Center
  const [reminders, setReminders] = useState([]);
  const [remStats,  setRemStats]  = useState({ upcoming:0, missed:0, snoozed:0, completed:0, active:0 });
  const [remTab,    setRemTab]    = useState('upcoming');
  const [remLoading, setRemLoading] = useState(true);

  const loadNotifs = useCallback(async () => {
    setNotifLoading(true);
    try {
      const p = { limit:100 };
      if (category) p.category = category;
      if (search) p.search = search;
      if (readFilter !== '') p.is_read = readFilter;
      const d = await getNotifications(p);
      setNotifications(d.notifications); setUnread(d.unread);
    } catch {} finally { setNotifLoading(false); }
  }, [category, search, readFilter]);

  const loadReminders = useCallback(async () => {
    setRemLoading(true);
    try {
      const statusMap = { upcoming:'pending', missed:'fired', snoozed:'snoozed', completed:'completed' };
      const [r, s] = await Promise.all([
        getTaskReminders(statusMap[remTab] ? { status: statusMap[remTab] } : {}),
        getReminderStats()
      ]);
      setReminders(r); setRemStats(s);
    } catch {} finally { setRemLoading(false); }
  }, [remTab]);

  useEffect(() => { loadNotifs(); }, [loadNotifs]);
  useEffect(() => { if (mainTab==='reminders') loadReminders(); }, [mainTab, loadReminders]);

  useEffect(() => {
    Promise.all([getTasks({ limit:300 }), getUsers()]).then(([t,u]) => {
      setTasks(t.tasks||[]); setUsers(u);
    }).catch(()=>{});
  }, []);

  useEffect(() => {
    if (!subscribe) return;
    const subs = [
      subscribe('notification:new',  () => loadNotifs()),
      subscribe('reminder:fire',     () => { loadNotifs(); if(mainTab==='reminders') loadReminders(); }),
      subscribe('reminder:created',  () => { if(mainTab==='reminders') loadReminders(); }),
      subscribe('reminder:updated',  () => { if(mainTab==='reminders') loadReminders(); }),
      subscribe('reminder:deleted',  () => { if(mainTab==='reminders') loadReminders(); }),
    ];
    return () => subs.forEach(u => u());
  }, [subscribe, loadNotifs, loadReminders, mainTab]);

  const openCreate = () => {
    setWizardStep(1);
    setForm({ target_user_id:user?.id||'', remind_at:'', timezone:user?.timezone||'IST', note:'', sound_tone:'alert', repeat_interval:0, repeat_until:'' });
    setCreateModal(true);
  };

  const handleCreate = async () => {
    if (!form.target_user_id) return toast.error('Select who to remind');
    if (!form.remind_at)      return toast.error('Select reminder date & time');
    setCreating(true);
    try {
      await createTaskReminder(form);
      const targetUser = users.find(u=>u.id===form.target_user_id);
      const isForSelf = form.target_user_id === user.id;
      const repeatLabel = form.repeat_interval > 0 ? ` (${REPEAT_OPTIONS.find(o=>o.value===form.repeat_interval)?.label})` : '';
      toast.success(`⏰ Reminder set${isForSelf?'':` for ${targetUser?.name}`}${repeatLabel}!`);
      setCreateModal(false);
      loadReminders();
    } catch(e) { toast.error(e.response?.data?.error || 'Failed'); }
    setCreating(false);
  };

  // Handlers
  const handleReadNotif = async (n) => {
    if (!n.is_read) { await markRead(n.id); setNotifications(p=>p.map(x=>x.id===n.id?{...x,is_read:1}:x)); setUnread(u=>Math.max(0,u-1)); }
    if (n.task_id) navigate(`/tasks?highlight=${n.task_id}`);
  };
  const handleDeleteNotif = async (id) => { await deleteNotif(id); setNotifications(n=>n.filter(x=>x.id!==id)); toast.success('Deleted'); };
  const handleMarkAll = async () => { await markAllRead(); setNotifications(n=>n.map(x=>({...x,is_read:1}))); setUnread(0); toast.success('All marked as read'); };
  const handleSnooze = async (rem, mins) => { await updateTaskReminder(rem.id, { snooze_minutes:mins }); toast.success(`⏸ Snoozed ${mins >= 60 ? Math.round(mins/60)+'h' : mins+'m'}`); loadReminders(); };
  const handleComplete = async (remId) => { await updateTaskReminder(remId, { status:'completed' }); toast.success('✅ Done'); loadReminders(); };
  const handleCompleteTask = async (taskId, remId) => {
    try {
      await updateTask(taskId, { status:'closed' });
      await updateTaskReminder(remId, { status:'completed' });
      toast.success('✅ Task closed!'); loadReminders(); loadNotifs();
    } catch { toast.error('Failed'); }
  };
  const handleDeleteRem = async (id) => { await deleteTaskReminder(id); toast.success('Deleted'); loadReminders(); };

  const typeColors = { error:'var(--red)', warning:'var(--amber)', success:'var(--green)', info:'var(--accent)' };

  // Wizard step helpers
  const selectedUser = users.find(u=>u.id===form.target_user_id);
  // Anyone can set a reminder for anyone on the team.
  const selectableUsers = users;
  const minDT = new Date(Date.now()+60000).toISOString().slice(0,16);

  // Modern date/time quick-picks (local time, formatted for datetime-local input)
  const toLocalInput = (d) => {
    const off = d.getTimezoneOffset()*60000;
    return new Date(d.getTime()-off).toISOString().slice(0,16);
  };
  const quickPicks = (() => {
    const now = new Date();
    const in1h  = new Date(now.getTime()+60*60000);
    const in3h  = new Date(now.getTime()+3*60*60000);
    const tom9  = new Date(now); tom9.setDate(tom9.getDate()+1); tom9.setHours(9,0,0,0);
    const tonight = new Date(now); tonight.setHours(18,0,0,0);
    const picks = [
      { label:'In 1 hour',  value:toLocalInput(in1h) },
      { label:'In 3 hours', value:toLocalInput(in3h) },
    ];
    if (tonight > now) picks.push({ label:'This evening · 6 PM', value:toLocalInput(tonight) });
    picks.push({ label:'Tomorrow · 9 AM', value:toLocalInput(tom9) });
    return picks;
  })();
  const prettyWhen = form.remind_at
    ? new Date(form.remind_at).toLocaleString(undefined, { weekday:'short', month:'short', day:'numeric', hour:'numeric', minute:'2-digit' })
    : '';

  return (
    <div className="fade-up">
      <SectionHeader
        title="🔔 Reminders & Notifications"
        sub={`${unread} unread · ${remStats.upcoming} upcoming · ${remStats.active} repeating`}
        action={
          <div className="flex gap-8">
            <button className="btn btn-accent" onClick={openCreate}>⏰ Set Reminder</button>
            {mainTab==='notifications' && <button className="btn btn-ghost" onClick={handleMarkAll}>✓ Mark all read</button>}
            <button className="btn btn-ghost btn-sm" onClick={mainTab==='notifications'?loadNotifs:loadReminders}>🔄</button>
          </div>
        }
      />

      {/* Main tabs */}
      <div className="tabs">
        <div className={`tab ${mainTab==='reminders'?'active':''}`} onClick={()=>setMainTab('reminders')}>
          ⏰ Reminder Center
          {(remStats.upcoming+remStats.missed)>0&&<span className="badge badge-amber" style={{ fontSize:10, marginLeft:5 }}>{remStats.upcoming+remStats.missed}</span>}
        </div>
        <div className={`tab ${mainTab==='notifications'?'active':''}`} onClick={()=>setMainTab('notifications')}>
          🔔 Notifications
          {unread>0&&<span className="badge badge-red" style={{ fontSize:10, marginLeft:5 }}>{unread}</span>}
        </div>
      </div>

      {/* ===== REMINDER CENTER ===== */}
      {mainTab==='reminders' && (
        <>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
            {[
              { l:'Upcoming',  v:remStats.upcoming,  c:'var(--accent)', k:'upcoming', icon:'⏰' },
              { l:'Missed',    v:remStats.missed,    c:'var(--red)',    k:'missed',   icon:'🔴' },
              { l:'Snoozed',   v:remStats.snoozed,   c:'var(--amber)', k:'snoozed',  icon:'😴' },
              { l:'Completed', v:remStats.completed, c:'var(--green)', k:'completed',icon:'✅' },
            ].map(s=>(
              <div key={s.k} onClick={()=>setRemTab(s.k)}
                style={{ background:'var(--bg2)', border:`2px solid ${remTab===s.k?s.c:'var(--border)'}`, borderRadius:'var(--radius)', padding:'16px 20px', cursor:'pointer', transition:'all .2s' }}>
                <div style={{ fontSize:22 }}>{s.icon}</div>
                <div style={{ fontSize:26, fontWeight:700, color:s.c, letterSpacing:'-1px', marginTop:4 }}>{s.v}</div>
                <div style={{ fontSize:12, color:'var(--text2)', marginTop:2 }}>{s.l}</div>
              </div>
            ))}
          </div>

          <div style={{ display:'flex', gap:4, marginBottom:16, borderBottom:'1px solid var(--border)' }}>
            {[['upcoming','⏰ Upcoming'],['missed','🔴 Missed'],['snoozed','😴 Snoozed'],['completed','✅ Done']].map(([k,l])=>(
              <div key={k} onClick={()=>setRemTab(k)} style={{ padding:'8px 14px', fontSize:13, fontWeight:remTab===k?600:400, color:remTab===k?'var(--accent2)':'var(--text2)', borderBottom:`2px solid ${remTab===k?'var(--accent)':'transparent'}`, marginBottom:-1, cursor:'pointer', transition:'all .15s' }}>{l}</div>
            ))}
          </div>

          {remLoading ? <PageLoader /> : reminders.length===0 ? (
            <EmptyState icon="⏰" title={`No ${remTab} reminders`}
              sub={remTab==='upcoming'?'Click "Set Reminder" to create a reminder for any task':'Nothing here'}
              action={remTab==='upcoming'&&<button className="btn btn-accent" onClick={openCreate}>⏰ Set Reminder</button>}
            />
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {reminders.map(r => {
                const isRepeating = (r.repeat_interval||0) > 0;
                const rLabel = isRepeating
                  ? `Repeating · ${r.repeat_interval>=60?Math.round(r.repeat_interval/60)+'h':r.repeat_interval+'m'} interval`
                  : 'One-time';
                const borderColor = remTab==='missed'?'var(--red)':remTab==='snoozed'?'var(--amber)':remTab==='completed'?'var(--green)':'var(--accent)';
                return (
                  <div key={r.id} style={{ background:'var(--bg2)', border:`1px solid var(--border)`, borderLeft:`4px solid ${borderColor}`, borderRadius:'var(--radius)', padding:'14px 16px' }}>
                    <div style={{ display:'flex', alignItems:'flex-start', gap:14 }}>
                      <div style={{ width:40, height:40, borderRadius:'var(--radius-sm)', background:remTab==='missed'?'var(--red-bg)':remTab==='snoozed'?'var(--amber-bg)':remTab==='completed'?'var(--green-bg)':'var(--accent-bg)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0 }}>
                        {remTab==='completed'?'✅':remTab==='missed'?'🔴':remTab==='snoozed'?'😴':isRepeating?'🔁':'⏰'}
                      </div>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontWeight:700, fontSize:14, marginBottom:4, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{r.task_title || r.note || 'Reminder'}</div>
                        {r.task_title && r.note && <div style={{ fontSize:12, color:'var(--text2)', marginBottom:6, fontStyle:'italic' }}>"{r.note}"</div>}
                        <div style={{ display:'flex', gap:10, flexWrap:'wrap', fontSize:12, alignItems:'center' }}>
                          <span style={{ color:'var(--text3)' }}>📅 {r.remind_at}</span>
                          <span className={`badge ${r.timezone==='IST'?'badge-purple':'badge-teal'}`} style={{ fontSize:9 }}>{r.timezone}</span>
                          <span style={{ color: isRepeating?'var(--accent2)':'var(--text3)', fontWeight:isRepeating?600:400 }}>{isRepeating?'🔁':''} {rLabel}</span>
                          {r.set_by_name && r.user_id!==user.id && <span style={{ color:'var(--text3)' }}>Set by {r.set_by_name}</span>}
                          {r.task_status && <span className={`badge ${r.task_status==='closed'?'badge-green':r.task_status==='in-progress'?'badge-blue':'badge-amber'}`} style={{ fontSize:9 }}>Task: {r.task_status}</span>}
                        </div>
                      </div>
                      <div style={{ display:'flex', gap:6, flexShrink:0, flexWrap:'wrap', justifyContent:'flex-end' }}>
                        {r.task_id && r.task_status!=='closed' && (
                          <button className="btn btn-success btn-sm" onClick={()=>handleCompleteTask(r.task_id, r.id)}>✅ Close Task</button>
                        )}
                        {(remTab==='upcoming'||remTab==='missed'||remTab==='snoozed') && (
                          <>
                            <select className="input" style={{ fontSize:11, padding:'4px 8px', height:28, width:'auto' }}
                              onChange={e=>{if(e.target.value){handleSnooze(r,parseInt(e.target.value));e.target.value='';}}}>
                              <option value="">😴 Snooze</option>
                              <option value="15">15 min</option>
                              <option value="30">30 min</option>
                              <option value="60">1 hour</option>
                              <option value="240">4 hours</option>
                            </select>
                            <button className="btn btn-ghost btn-sm" onClick={()=>handleComplete(r.id)}>✓ Done</button>
                          </>
                        )}
                        <button className="btn btn-danger btn-sm btn-icon" onClick={()=>handleDeleteRem(r.id)}>✕</button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* ===== NOTIFICATIONS TAB ===== */}
      {mainTab==='notifications' && (
        <>
          <div className="card card-sm mb-16">
            <div className="flex items-center gap-12" style={{ flexWrap:'wrap' }}>
              <div style={{ flex:1, minWidth:200, position:'relative' }}>
                <span style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'var(--text3)' }}>⌕</span>
                <input className="input" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search notifications…" style={{ paddingLeft:32 }} />
              </div>
              <select className="input" style={{ width:140 }} value={readFilter} onChange={e=>setReadFilter(e.target.value)}>
                <option value="">All Status</option><option value="0">Unread</option><option value="1">Read</option>
              </select>
            </div>
            <div className="filter-chips mt-12" style={{ marginBottom:0 }}>
              {NOTIF_CATS.map(c=>(
                <span key={c.key} className={`chip ${category===c.key?'active':''}`} onClick={()=>setCategory(c.key)}>{c.label}</span>
              ))}
            </div>
          </div>
          {notifLoading ? <PageLoader /> : notifications.length===0 ? (
            <EmptyState icon="🔔" title="No notifications" sub="You're all caught up!" />
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {notifications.map(n => {
                const bc = typeColors[n.type]||'var(--border)';
                return (
                  <div key={n.id} onClick={()=>handleReadNotif(n)}
                    style={{ background:'var(--bg2)', border:`1px solid ${n.is_read?'var(--border)':bc}`, borderLeft:`4px solid ${bc}`, borderRadius:'var(--radius)', padding:'14px 16px', cursor:'pointer', transition:'all .18s', display:'flex', alignItems:'flex-start', gap:14, opacity:n.is_read?.75:1 }}
                    onMouseEnter={e=>e.currentTarget.style.background='var(--bg3)'}
                    onMouseLeave={e=>e.currentTarget.style.background='var(--bg2)'}>
                    <div style={{ fontSize:20, marginTop:2 }}><NotifTypeIcon category={n.category} /></div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:3, flexWrap:'wrap' }}>
                        {!n.is_read&&<div style={{ width:7, height:7, borderRadius:'50%', background:'var(--accent)', flexShrink:0 }}/>}
                        <span style={{ fontSize:13, fontWeight:n.is_read?500:700 }}>{n.title}</span>
                        <span className={`badge badge-${n.type==='error'?'red':n.type==='warning'?'amber':n.type==='success'?'green':'blue'}`} style={{ fontSize:10 }}>{n.type}</span>
                      </div>
                      <div style={{ fontSize:13, color:'var(--text2)', marginBottom:3 }}>{n.message}</div>
                      <div style={{ fontSize:11, color:'var(--text3)' }}>{n.created_at} · {n.category?.replace(/_/g,' ')}</div>
                    </div>
                    <div className="flex gap-6 flex-shrink-0">
                      {!n.is_read&&<button className="btn btn-ghost btn-sm" onClick={e=>{e.stopPropagation();handleReadNotif(n);}}>Mark read</button>}
                      <button className="btn btn-danger btn-sm" onClick={e=>{e.stopPropagation();handleDeleteNotif(n.id);}}>✕</button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* ===== CREATE REMINDER — STEP-BY-STEP WIZARD ===== */}
      <Modal open={createModal} onClose={()=>setCreateModal(false)} title={`⏰ Set Reminder — Step ${wizardStep} of 4`} width={560}>
        {/* Progress bar */}
        <div style={{ display:'flex', gap:6, marginBottom:20 }}>
          {[1,2,3,4].map(s=>(
            <div key={s} style={{ flex:1, height:4, borderRadius:4, background:s<=wizardStep?'var(--accent)':'var(--bg4)', transition:'background .3s' }} />
          ))}
        </div>

        {/* Step 1: Who to remind */}
        {wizardStep===1 && (
          <div>
            <div style={{ fontSize:16, fontWeight:700, marginBottom:6 }}>Who should be reminded?</div>
            <div style={{ fontSize:13, color:'var(--text2)', marginBottom:16 }}>
              Select the person who will receive the reminder popup on their screen — that can be you or any teammate.
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:8, maxHeight:320, overflowY:'auto' }}>
              {selectableUsers.map(u=>{
                const isSelected = form.target_user_id===u.id;
                return (
                  <div key={u.id} onClick={()=>{ setF('target_user_id',u.id); setF('timezone',u.timezone||'IST'); }}
                    style={{ display:'flex', alignItems:'center', gap:12, padding:'11px 14px', borderRadius:'var(--radius-sm)', border:`2px solid ${isSelected?'var(--accent)':'var(--border)'}`, background:isSelected?'var(--accent-bg)':'var(--bg3)', cursor:'pointer', transition:'all .15s' }}>
                    <div style={{ width:20, height:20, borderRadius:'50%', border:`2px solid ${isSelected?'var(--accent)':'var(--border2)'}`, background:isSelected?'var(--accent)':'transparent', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                      {isSelected&&<span style={{ color:'#fff', fontSize:12, fontWeight:700 }}>✓</span>}
                    </div>
                    <Avatar name={u.name} color={u.color} size="sm" />
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:14, fontWeight:600 }}>{u.name}{u.id===user?.id && <span style={{ fontSize:11, color:'var(--text3)', fontWeight:400 }}> · you</span>}</div>
                      <div style={{ fontSize:12, color:'var(--text2)' }}>{u.role} · {u.department}</div>
                    </div>
                    <span className={`badge ${u.timezone==='IST'?'badge-purple':'badge-teal'}`}>{u.timezone}</span>
                  </div>
                );
              })}
            </div>
            <div style={{ display:'flex', justifyContent:'flex-end', marginTop:16, paddingTop:12, borderTop:'1px solid var(--border)' }}>
              <button className="btn btn-accent" onClick={()=>setWizardStep(2)} disabled={!form.target_user_id}>
                Next: Add Message →
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Note / Message (optional) */}
        {wizardStep===2 && (
          <div>
            <div style={{ fontSize:16, fontWeight:700, marginBottom:4 }}>Add a note or message</div>
            <div style={{ fontSize:13, color:'var(--text2)', marginBottom:16 }}>
              Reminder for <strong style={{color:'var(--text)'}}>{selectedUser?.name}</strong>. This message is optional — it will show inside the reminder popup.
            </div>
            <FormGroup label="Note / Message" hint="Optional. Leave blank for a simple time-based reminder.">
              <textarea className="input" value={form.note} onChange={e=>setF('note',e.target.value)} placeholder="e.g. Call the client back about the proposal" style={{ minHeight:90 }} autoFocus />
            </FormGroup>
            <div style={{ display:'flex', justifyContent:'space-between', marginTop:16, paddingTop:12, borderTop:'1px solid var(--border)' }}>
              <button className="btn btn-ghost" onClick={()=>setWizardStep(1)}>← Back</button>
              <button className="btn btn-accent" onClick={()=>setWizardStep(3)}>Next: When →</button>
            </div>
          </div>
        )}

        {/* Step 3: When */}
        {wizardStep===3 && (
          <div>
            <div style={{ fontSize:16, fontWeight:700, marginBottom:4 }}>When should it fire?</div>
            <div style={{ fontSize:13, color:'var(--text2)', marginBottom:16 }}>Pick a quick option or choose an exact date & time.</div>

            {/* Modern quick-pick chips */}
            <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:8, marginBottom:16 }}>
              {quickPicks.map(q=>{
                const active = form.remind_at===q.value;
                return (
                  <button key={q.label} type="button" onClick={()=>setF('remind_at',q.value)}
                    style={{ textAlign:'left', padding:'12px 14px', borderRadius:'var(--radius-sm)', border:`2px solid ${active?'var(--accent)':'var(--border)'}`, background:active?'var(--accent-bg)':'var(--bg3)', cursor:'pointer', transition:'all .15s', color:'var(--text)' }}>
                    <div style={{ fontSize:13, fontWeight:600 }}>{q.label}</div>
                    <div style={{ fontSize:11, color:'var(--text3)', marginTop:2 }}>{new Date(q.value).toLocaleString(undefined,{ hour:'numeric', minute:'2-digit', month:'short', day:'numeric' })}</div>
                  </button>
                );
              })}
            </div>

            <FormGroup label="Exact date & time" required>
              <input className="input dt-modern" type="datetime-local" value={form.remind_at} min={minDT} onChange={e=>setF('remind_at',e.target.value)} />
            </FormGroup>
            {prettyWhen && (
              <div style={{ background:'var(--accent-bg)', border:'1px solid var(--accent-border)', borderRadius:'var(--radius-sm)', padding:'10px 12px', fontSize:13, marginBottom:16, color:'var(--accent2)', fontWeight:600 }}>
                ⏰ Will fire on {prettyWhen}
              </div>
            )}
            <FormGroup label="Timezone">
              <select className="input" value={form.timezone} onChange={e=>setF('timezone',e.target.value)}>
                <option value="IST">🇮🇳 India Standard Time (IST)</option>
                <option value="CST">🇺🇸 USA Chicago Time (CST)</option>
              </select>
            </FormGroup>
            <div style={{ display:'flex', justifyContent:'space-between', marginTop:16, paddingTop:12, borderTop:'1px solid var(--border)' }}>
              <button className="btn btn-ghost" onClick={()=>setWizardStep(2)}>← Back</button>
              <button className="btn btn-accent" onClick={()=>setWizardStep(4)} disabled={!form.remind_at}>Next: Interval →</button>
            </div>
          </div>
        )}

        {/* Step 4: Repeat interval + sound */}
        {wizardStep===4 && (
          <div>
            <div style={{ fontSize:16, fontWeight:700, marginBottom:4 }}>Repeat & Sound Settings</div>
            <div style={{ fontSize:13, color:'var(--text2)', marginBottom:16 }}>
              How often should this reminder repeat?
            </div>

            <FormGroup label="Repeat Interval" hint="Reminder will keep firing at this interval until it is dismissed">
              <select className="input" value={form.repeat_interval} onChange={e=>setF('repeat_interval',parseInt(e.target.value))}>
                {REPEAT_OPTIONS.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </FormGroup>

            {form.repeat_interval > 0 && (
              <FormGroup label="Stop repeating after (optional)" hint="Leave blank to repeat until dismissed">
                <input className="input dt-modern" type="datetime-local" value={form.repeat_until} min={form.remind_at} onChange={e=>setF('repeat_until',e.target.value)} />
              </FormGroup>
            )}

            <div style={{ marginBottom:16 }}>
              <div className="label">Alert Sound</div>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:8 }}>
                {SOUND_TONES.map(t=>(
                  <div key={t.value} onClick={()=>setF('sound_tone',t.value)}
                    style={{ padding:'10px 12px', borderRadius:'var(--radius-sm)', border:`2px solid ${form.sound_tone===t.value?'var(--accent)':'var(--border)'}`, background:form.sound_tone===t.value?'var(--accent-bg)':'var(--bg3)', cursor:'pointer', transition:'all .15s', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <div>
                      <div style={{ fontSize:14, fontWeight:600 }}>{t.label}</div>
                      <div style={{ fontSize:11, color:'var(--text3)' }}>{t.desc}</div>
                    </div>
                    <button onClick={e=>{e.stopPropagation();playPreviewTone(t.value);}}
                      style={{ fontSize:10, color:'var(--accent2)', background:'var(--accent-bg)', border:'1px solid var(--accent-border)', borderRadius:4, padding:'3px 8px', cursor:'pointer' }}>▶ Test</button>
                  </div>
                ))}
              </div>
            </div>

            {/* Final summary */}
            <div style={{ background:'var(--accent-bg)', border:'1px solid var(--accent-border)', borderRadius:'var(--radius-sm)', padding:'12px 14px', fontSize:12, lineHeight:1.8, marginBottom:16 }}>
              <div style={{ fontWeight:700, color:'var(--accent2)', marginBottom:6 }}>📋 Reminder Summary</div>
              <div>👤 Notify: <strong>{selectedUser?.name}</strong> ({selectedUser?.timezone})</div>
              {form.note && <div>📝 Message: <strong>{form.note}</strong></div>}
              <div>⏰ First alert: <strong>{prettyWhen || form.remind_at}</strong></div>
              {form.repeat_interval > 0 && <div>🔁 Repeats: <strong>{REPEAT_OPTIONS.find(o=>o.value===form.repeat_interval)?.label}</strong></div>}
              <div>🔔 Sound: <strong>{SOUND_TONES.find(t=>t.value===form.sound_tone)?.label}</strong></div>
            </div>

            <div style={{ display:'flex', justifyContent:'space-between', paddingTop:12, borderTop:'1px solid var(--border)' }}>
              <button className="btn btn-ghost" onClick={()=>setWizardStep(3)}>← Back</button>
              <button className="btn btn-accent" onClick={handleCreate} disabled={creating}>
                {creating?<><Spinner size={13}/> Setting…</>:'⏰ Set Reminder'}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
