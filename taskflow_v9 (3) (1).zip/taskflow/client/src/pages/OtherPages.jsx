import { useState, useEffect, useCallback } from 'react';
import { useAuth, useWS } from '../context/AuthContext';
import { Avatar, ProgressBar, PageLoader, EmptyState, Toggle, Modal, FormGroup, TZDate } from '../components/UI';
import { TaskModal, TaskCard } from '../components/TaskComponents';
import { getTasks, getUsers, getTeamClock, getProductivity, getClockHistory, updateSchedule, updateTask, TIMEZONES } from '../utils/api';
import toast from 'react-hot-toast';

// =================== KANBAN ===================
export function Kanban() {
  const { subscribe } = useWS();
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);

  const load = useCallback(async () => {
    try {
      const [t, u] = await Promise.all([getTasks({ limit: 200 }), getUsers()]);
      setTasks(t.tasks); setUsers(u);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (!subscribe) return;
    const u1 = subscribe('task:created', load);
    const u2 = subscribe('task:updated', load);
    const u3 = subscribe('task:deleted', load);
    return () => { u1(); u2(); u3(); };
  }, [subscribe, load]);

  const moveTask = async (taskId, newStatus) => {
    try {
      const updated = await updateTask(taskId, { status: newStatus });
      setTasks(ts => ts.map(t => t.id === taskId ? updated : t));
      toast.success(newStatus === 'closed' ? '✅ Task Closed!' : `Moved to ${newStatus}`);
    } catch { toast.error('Failed to move task'); }
  };

  const cols = [
    { key: 'pending',     label: '⏳ To Do',       color: 'var(--text2)',  accent: 'var(--bg4)' },
    { key: 'in-progress', label: '🔄 In Progress',  color: 'var(--amber)',  accent: 'rgba(245,158,11,.08)' },
    { key: 'closed',      label: '✅ Task Closed',  color: 'var(--green)',  accent: 'rgba(16,185,129,.06)' },
  ];

  if (loading) return <PageLoader />;

  return (
    <div className="fade-up">
      <div className="flex items-start justify-between mb-20">
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-.5px' }}>⋮⋮ Kanban Board</h1>
          <div style={{ fontSize: 13, color: 'var(--text2)', marginTop: 3 }}>
            {tasks.length} tasks · real-time sync active
          </div>
        </div>
        <button className="btn btn-accent" onClick={() => setModal(true)}>➕ New Task</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, minHeight: 500, alignItems: 'start' }}>
        {cols.map(col => {
          const colTasks = tasks.filter(t => t.status === col.key);
          return (
            <div key={col.key} style={{ background: col.accent, border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 14, minHeight: 300 }}>
              <div className="flex items-center justify-between mb-14">
                <span style={{ fontSize: 13, fontWeight: 600, color: col.color }}>{col.label}</span>
                <span style={{ background: 'var(--bg3)', fontSize: 11, padding: '2px 8px', borderRadius: 10, color: 'var(--text2)', fontWeight: 600 }}>{colTasks.length}</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {colTasks.map(t => {
                  const overdue = t.status !== 'closed' && t.due_date < new Date().toISOString().split('T')[0];
                  return (
                    <div key={t.id} style={{ background: 'var(--bg2)', border: `1px solid ${overdue ? 'var(--red)' : 'var(--border)'}`, borderRadius: 'var(--radius)', padding: '12px 14px', cursor: 'pointer', transition: 'all .15s' }}
                      onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-1px)'; e.currentTarget.style.boxShadow = 'var(--shadow-sm)'; }}
                      onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'none'; }}>
                      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8, lineHeight: 1.4 }}>{t.title}</div>
                      <div className="flex items-center justify-between mb-8">
                        <span style={{ background: t.priority === 'high' ? 'var(--red-bg)' : t.priority === 'medium' ? 'var(--amber-bg)' : 'var(--green-bg)', color: t.priority === 'high' ? 'var(--red)' : t.priority === 'medium' ? 'var(--amber)' : 'var(--green)', fontSize: 10, padding: '2px 6px', borderRadius: 4, fontWeight: 600 }}>{t.priority}</span>
                        <div className="flex items-center gap-6">
                          {t.assigned_to_name && <Avatar name={t.assigned_to_name} color={t.assigned_to_color} size="xs" />}
                          <span style={{ fontSize: 11, color: overdue ? 'var(--red)' : 'var(--text3)' }}>{t.due_date}</span>
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: 4 }}>
                        {cols.filter(c => c.key !== col.key).map(c => (
                          <button key={c.key} onClick={e => { e.stopPropagation(); moveTask(t.id, c.key); }}
                            style={{ flex: 1, fontSize: 10, padding: '4px 2px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 5, cursor: 'pointer', color: 'var(--text2)', transition: 'all .15s', textAlign: 'center' }}
                            onMouseEnter={e => { e.currentTarget.style.background = 'var(--accent-bg)'; e.currentTarget.style.color = 'var(--accent2)'; }}
                            onMouseLeave={e => { e.currentTarget.style.background = 'var(--bg3)'; e.currentTarget.style.color = 'var(--text2)'; }}>
                            {c.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
                <button className="btn btn-ghost" style={{ width: '100%', justifyContent: 'center', fontSize: 12, opacity: .6 }} onClick={() => setModal(true)}>+ Add here</button>
              </div>
            </div>
          );
        })}
      </div>
      <TaskModal open={modal} onClose={() => setModal(false)} onSave={load} users={users} />
    </div>
  );
}

// =================== TEAM ===================
export function Team() {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [teamClock, setTeamClock] = useState([]);
  const [loading, setLoading] = useState(true);
  const { subscribe } = useWS();
  const [tzTimes, setTzTimes] = useState({});

  const load = useCallback(async () => {
    try {
      const [u, t] = await Promise.all([getUsers(), getTeamClock()]);
      setUsers(u); setTeamClock(t);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (!subscribe) return;
    const u1 = subscribe('user:clockin', load);
    const u2 = subscribe('user:clockout', load);
    return () => { u1(); u2(); };
  }, [subscribe, load]);

  useEffect(() => {
    const tick = () => {
      const times = {};
      ['IST', 'CST'].forEach(tz => {
        const tzName = TIMEZONES[tz]?.tz;
        times[tz] = new Date().toLocaleTimeString('en-US', { timeZone: tzName, hour: '2-digit', minute: '2-digit', hour12: true });
      });
      setTzTimes(times);
    };
    tick(); const i = setInterval(tick, 60000); return () => clearInterval(i);
  }, []);

  if (loading) return <PageLoader />;

  const onlineCount = teamClock.filter(t => t.is_active).length;

  return (
    <div className="fade-up">
      <div className="flex items-start justify-between mb-20">
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-.5px' }}>👥 Team</h1>
          <div style={{ fontSize: 13, color: 'var(--text2)', marginTop: 3 }}>
            {users.length} members · <span style={{ color: 'var(--green)' }}>{onlineCount} online now</span>
          </div>
        </div>
        {/* TZ clocks */}
        <div style={{ display: 'flex', gap: 10 }}>
          {['IST', 'CST'].map(tz => (
            <div key={tz} style={{ background: 'var(--bg2)', border: `1px solid ${user.timezone === tz ? 'var(--accent)' : 'var(--border)'}`, borderRadius: 'var(--radius-sm)', padding: '8px 14px', textAlign: 'center' }}>
              <div style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--mono)' }}>{tzTimes[tz] || '—'}</div>
              <div style={{ fontSize: 10, color: 'var(--text3)' }}>{tz}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="card" style={{ overflow: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr><th>Employee</th><th>Department</th><th>Timezone</th><th>Status</th><th>Local Time</th><th>Today</th></tr>
          </thead>
          <tbody>
            {users.map(u => {
              const session = teamClock.find(t => t.id === u.id);
              const isOnline = !!session?.is_active;
              const mins = isOnline && session.clock_in ? Math.round((Date.now() - new Date(session.clock_in.replace(' ', 'T') + 'Z').getTime()) / 60000) : 0;
              return (
                <tr key={u.id}>
                  <td>
                    <div className="flex items-center gap-10">
                      <div style={{ position: 'relative' }}>
                        <Avatar name={u.name} color={u.color} size="sm" />
                        <div style={{ position: 'absolute', bottom: -1, right: -1, width: 9, height: 9, borderRadius: '50%', background: isOnline ? 'var(--green)' : 'var(--bg4)', border: '2px solid var(--bg2)' }} />
                      </div>
                      <div>
                        <div style={{ fontWeight: 500, fontSize: 13 }}>{u.name}</div>
                        <div style={{ fontSize: 11, color: 'var(--text2)' }}>{u.email}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div style={{ fontSize: 12 }}>{u.role}</div>
                    <div style={{ fontSize: 11, color: 'var(--text2)' }}>{u.department}</div>
                  </td>
                  <td>
                    <span className={`badge ${u.timezone === 'IST' ? 'badge-purple' : 'badge-teal'}`}>{u.timezone}</span>
                    <div style={{ fontSize: 10, color: 'var(--text3)', marginTop: 2 }}>{TIMEZONES[u.timezone]?.label?.split(' (')[0]}</div>
                  </td>
                  <td>
                    <span className={`badge ${isOnline ? 'badge-green' : 'badge-gray'}`}>
                      <span style={{ width: 6, height: 6, borderRadius: '50%', background: isOnline ? 'var(--green)' : 'var(--text3)', display: 'inline-block', marginRight: 4 }} />
                      {isOnline ? 'Online' : 'Offline'}
                    </span>
                  </td>
                  <td style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>{tzTimes[u.timezone] || '—'} <span style={{ fontSize: 10, color: 'var(--text3)' }}>{u.timezone}</span></td>
                  <td>
                    {isOnline ? (
                      <div>
                        <div style={{ fontSize: 12, fontFamily: 'var(--mono)', color: 'var(--green)' }}>⚡ {Math.floor(mins / 60)}h {mins % 60}m</div>
                        <ProgressBar value={Math.min(100, mins / 480 * 100)} height={3} color="var(--green)" />
                      </div>
                    ) : session?.duration_minutes ? (
                      <span style={{ fontSize: 12, color: 'var(--text2)', fontFamily: 'var(--mono)' }}>{Math.floor(session.duration_minutes / 60)}h {session.duration_minutes % 60}m</span>
                    ) : <span style={{ color: 'var(--text3)', fontSize: 12 }}>—</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// =================== WORK HOURS ===================
export function Hours() {
  const { user, schedule, setSchedule } = useAuth();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [localSched, setLocalSched] = useState([]);

  useEffect(() => {
    setLocalSched(schedule.length ? schedule : []);
    getClockHistory({ limit: 30 }).then(setHistory).finally(() => setLoading(false));
  }, [schedule]);

  const updateDay = (day, field, value) => setLocalSched(s => s.map(d => d.day_of_week === day ? { ...d, [field]: value } : d));

  const saveMySchedule = async () => {
    setSaving(true);
    try {
      const updated = await updateSchedule(user.id, localSched.map(d => ({ day_of_week: d.day_of_week, is_working: d.is_working ? 1 : 0, start_time: d.start_time, end_time: d.end_time })));
      setSchedule(updated);
      toast.success('✅ Schedule saved');
    } catch { toast.error('Failed to save'); }
    setSaving(false);
  };

  if (loading) return <PageLoader />;

  const totalHours = history.filter(s => s.duration_minutes).reduce((a, s) => a + (s.duration_minutes || 0), 0);
  const avgHours = history.filter(s => s.duration_minutes).length ? (totalHours / history.filter(s => s.duration_minutes).length / 60).toFixed(1) : 0;

  return (
    <div className="fade-up">
      <div className="flex items-start justify-between mb-20">
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-.5px' }}>🕐 Work Hours</h1>
          <div style={{ fontSize: 13, color: 'var(--text2)', marginTop: 3 }}>Your schedule & clock history</div>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <div className="stat-card" style={{ padding: '10px 18px' }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--accent)' }}>{(totalHours / 60).toFixed(1)}h</div>
            <div style={{ fontSize: 11, color: 'var(--text2)' }}>Total (30d)</div>
          </div>
          <div className="stat-card" style={{ padding: '10px 18px' }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--teal)' }}>{avgHours}h</div>
            <div style={{ fontSize: 11, color: 'var(--text2)' }}>Avg/day</div>
          </div>
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-title">📅 My Work Schedule</div>
          {localSched.map(d => (
            <div key={d.day_of_week} className="flex items-center gap-10" style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ width: 88, fontSize: 13, fontWeight: d.is_working ? 600 : 400, color: d.is_working ? 'var(--text)' : 'var(--text3)' }}>{d.day_of_week.slice(0, 3)}</div>
              <Toggle on={!!d.is_working} onChange={v => updateDay(d.day_of_week, 'is_working', v)} />
              <input type="time" className="input" value={d.start_time} onChange={e => updateDay(d.day_of_week, 'start_time', e.target.value)}
                style={{ width: 90, opacity: d.is_working ? 1 : .35, pointerEvents: d.is_working ? 'auto' : 'none' }} />
              <span style={{ color: 'var(--text3)' }}>→</span>
              <input type="time" className="input" value={d.end_time} onChange={e => updateDay(d.day_of_week, 'end_time', e.target.value)}
                style={{ width: 90, opacity: d.is_working ? 1 : .35, pointerEvents: d.is_working ? 'auto' : 'none' }} />
            </div>
          ))}
          <div style={{ marginTop: 16, display: 'flex', justifyContent: 'flex-end' }}>
            <button className="btn btn-accent" onClick={saveMySchedule} disabled={saving}>{saving ? 'Saving…' : 'Save Schedule'}</button>
          </div>
        </div>

        <div className="card">
          <div className="card-title">📋 Clock History</div>
          {history.length === 0 ? <EmptyState icon="🕐" title="No sessions yet" /> : (
            <div style={{ maxHeight: 420, overflowY: 'auto' }}>
              {history.map((s, i) => {
                const mins = s.duration_minutes || 0;
                const target = 480;
                const pct = Math.min(100, mins / target * 100);
                const color = pct >= 100 ? 'var(--green)' : pct >= 75 ? 'var(--amber)' : 'var(--red)';
                return (
                  <div key={s.id || i} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{s.date}</div>
                      <div style={{ fontSize: 11, color: 'var(--text2)', marginTop: 2 }}>
                        {s.clock_in?.split(' ')[1]?.slice(0, 5)} → {s.clock_out ? s.clock_out?.split(' ')[1]?.slice(0, 5) : '⚡ active'}
                      </div>
                      <div style={{ marginTop: 4 }}><ProgressBar value={pct} color={color} height={3} /></div>
                    </div>
                    <div style={{ fontSize: 14, fontWeight: 600, fontFamily: 'var(--mono)', color, textAlign: 'right' }}>
                      {s.clock_out ? `${Math.floor(mins / 60)}h${mins % 60}m` : <span style={{ color: 'var(--green)', fontSize: 12 }}>Active</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// =================== PRODUCTIVITY ===================
export function Productivity() {
  const T = new Date().toISOString().split('T')[0];
  const [period,    setPeriod]    = useState('week');
  const [dateFrom,  setDateFrom]  = useState('');
  const [dateTo,    setDateTo]    = useState('');
  const [customMode,setCustomMode]= useState(false);
  const [data, setData]           = useState(null);
  const [loading, setLoading]     = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const p = customMode && dateFrom && dateTo
        ? { date_from:dateFrom, date_to:dateTo }
        : { period };
      const { getProductivityReport } = await import('../utils/api');
      const d = await getProductivityReport(p);
      setData(d);
    } catch {} finally { setLoading(false); }
  }, [period, customMode, dateFrom, dateTo]);

  useEffect(() => { load(); }, [load]);

  const QUICK = [
    { l:'Today',     p:'today',   onClick:()=>{ setCustomMode(false); setPeriod('today'); } },
    { l:'Yesterday', p:'yesterday',onClick:()=>{ setCustomMode(false); setPeriod('yesterday'); } },
    { l:'This Week', p:'week',    onClick:()=>{ setCustomMode(false); setPeriod('week'); } },
    { l:'This Month',p:'month',   onClick:()=>{ setCustomMode(false); setPeriod('month'); } },
    { l:'Custom',    p:'custom',  onClick:()=>{ setCustomMode(true); } },
  ];

  if (loading&&!data) return <PageLoader />;

  const { userStats=[], deptStats=[] } = data||{};
  const totalClosed   = userStats.reduce((a,u)=>a+(u.closed||0),0);
  const totalAssigned = userStats.reduce((a,u)=>a+(u.assigned||0),0);
  const totalHours    = userStats.reduce((a,u)=>a+(u.hours_worked||0),0);
  const overallRate   = totalAssigned ? Math.round(totalClosed/totalAssigned*100) : 0;
  const activeLabel   = customMode ? `${dateFrom} – ${dateTo}` : QUICK.find(q=>q.p===period)?.l || period;

  return (
    <div className="fade-up">
      <div className="flex items-start justify-between mb-16">
        <div>
          <h1 style={{ fontSize:22, fontWeight:700, letterSpacing:'-.5px' }}>📈 Productivity</h1>
          <div style={{ fontSize:13, color:'var(--text2)', marginTop:3 }}>Team performance · <strong style={{color:'var(--accent2)'}}>{activeLabel}</strong></div>
        </div>
        <div className="flex gap-6 items-center flex-wrap">
          {QUICK.map(q=>(
            <button key={q.p} className={`btn btn-sm ${(!customMode&&period===q.p)||(customMode&&q.p==='custom')?'btn-accent':'btn-ghost'}`} onClick={q.onClick}>{q.l}</button>
          ))}
          <button className="btn btn-ghost btn-sm" onClick={load}>🔄</button>
        </div>
      </div>

      {customMode && (
        <div className="card card-sm mb-16" style={{ display:'flex', gap:12, alignItems:'flex-end' }}>
          <div><div className="label">From</div><input className="input" type="date" value={dateFrom} onChange={e=>setDateFrom(e.target.value)} max={T} /></div>
          <div><div className="label">To</div><input className="input" type="date" value={dateTo} onChange={e=>setDateTo(e.target.value)} max={T} /></div>
          <button className="btn btn-accent btn-sm" onClick={load} disabled={!dateFrom||!dateTo}>Apply</button>
        </div>
      )}

      <div className="stats-grid mb-20">
        {[
          { label:'Tasks Closed',   value:totalClosed,            color:'var(--green)' },
          { label:'Overall Rate',   value:overallRate+'%',        color:'var(--accent)' },
          { label:'Hours Logged',   value:totalHours.toFixed(1)+'h', color:'var(--teal)' },
          { label:'Total Assigned', value:totalAssigned,          color:'var(--text)' },
        ].map(s=>(
          <div key={s.label} className="stat-card">
            <div className="stat-value" style={{ color:s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2 mb-20">
        <div className="card">
          <div className="card-title">✅ Task Closed Rate by Employee</div>
          {userStats.length===0
            ? <div style={{color:'var(--text3)',fontSize:13,padding:'16px 0',textAlign:'center'}}>No data for this period</div>
            : userStats.map(u=>{
              const rate = u.assigned ? Math.round((u.closed||0)/u.assigned*100) : 0;
              return (
                <div key={u.id} style={{ padding:'9px 0', borderBottom:'1px solid var(--border)' }}>
                  <div className="flex items-center gap-8 mb-4">
                    <Avatar name={u.name} color={u.color} size="xs" />
                    <span style={{ fontSize:13, fontWeight:500, flex:1 }}>{u.name}</span>
                    <span style={{ fontSize:12, color:rate>=80?'var(--green)':rate>=50?'var(--amber)':'var(--red)', fontWeight:600 }}>{rate}%</span>
                    <span style={{ fontSize:11, color:'var(--text3)' }}>{u.closed||0}/{u.assigned}</span>
                  </div>
                  <ProgressBar value={rate} color={u.color} height={4} />
                </div>
              );
            })
          }
        </div>

        <div className="card">
          <div className="card-title">🕐 Hours Worked</div>
          {userStats.map(u=>{
            const h=u.hours_worked||0;
            const max=Math.max(...userStats.map(x=>x.hours_worked||0),1);
            return (
              <div key={u.id} style={{ padding:'9px 0', borderBottom:'1px solid var(--border)' }}>
                <div className="flex items-center gap-8 mb-4">
                  <Avatar name={u.name} color={u.color} size="xs" />
                  <span style={{ fontSize:13, fontWeight:500, flex:1 }}>{u.name}</span>
                  <span style={{ fontSize:12, fontFamily:'var(--mono)', color:'var(--text2)' }}>{h.toFixed(1)}h</span>
                </div>
                <ProgressBar value={(h/max)*100} color={u.color} height={4} />
              </div>
            );
          })}
        </div>
      </div>

      <div className="card">
        <div className="card-title">🏢 Department Overview</div>
        <table className="data-table">
          <thead><tr><th>Department</th><th>Members</th><th>Tasks</th><th>Closed</th><th>Completion Rate</th></tr></thead>
          <tbody>
            {deptStats.map(d=>{
              const rate=d.tasks?Math.round(d.closed/d.tasks*100):0;
              return (
                <tr key={d.department}>
                  <td style={{ fontWeight:600 }}>{d.department}</td>
                  <td>{d.members}</td><td>{d.tasks}</td>
                  <td style={{ color:'var(--green)', fontWeight:600 }}>{d.closed}</td>
                  <td>
                    <div className="flex items-center gap-10">
                      <div style={{ flex:1, maxWidth:140 }}><ProgressBar value={rate} color={rate>=80?'var(--green)':rate>=50?'var(--amber)':'var(--red)'} /></div>
                      <span style={{ fontSize:12, color:'var(--text2)', width:36 }}>{rate}%</span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
