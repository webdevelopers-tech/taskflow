import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { Avatar, PageLoader, EmptyState, SectionHeader } from '../components/UI';
import { getAuditLog, getUsers } from '../utils/api';

const ACTION_LABELS = {
  LOGIN:           { label:'Logged In',              icon:'🔐', color:'badge-blue' },
  CREATE:          { label:'Created Task',           icon:'✅', color:'badge-green' },
  CREATE_USER:     { label:'Added Employee',         icon:'👤', color:'badge-green' },
  CREATE_CATEGORY: { label:'Created Category',      icon:'📁', color:'badge-green' },
  UPDATE:          { label:'Updated Task',           icon:'✏️', color:'badge-amber' },
  UPDATE_USER:     { label:'Updated Employee',       icon:'👤', color:'badge-amber' },
  UPDATE_CATEGORY: { label:'Updated Category',      icon:'📁', color:'badge-amber' },
  PASSWORD_CHANGE: { label:'Changed Password',      icon:'🔒', color:'badge-amber' },
  DELETE:          { label:'Deleted Task',           icon:'🗑', color:'badge-red' },
  DEACTIVATE_USER: { label:'Deactivated Employee',  icon:'⛔', color:'badge-red' },
  DELETE_CATEGORY: { label:'Disabled Category',     icon:'📁', color:'badge-red' },
};

// Convert raw JSON diff into readable sentences
function describeChange(old_data, new_data, entity) {
  if (!old_data && !new_data) return null;
  try {
    const oldObj = old_data ? (typeof old_data==='string' ? JSON.parse(old_data) : old_data) : {};
    const newObj = new_data ? (typeof new_data==='string' ? JSON.parse(new_data) : new_data) : {};

    const FIELD_LABELS = {
      name:'Name', email:'Email', role:'Role', department:'Department', timezone:'Timezone',
      title:'Task title', status:'Status', priority:'Priority', due_date:'Due date',
      assigned_to:'Assigned to', category:'Category', description:'Description',
      company_name:'Company name', primary_color:'Primary color', sidebar_color:'Sidebar color',
      is_active:'Active status', color:'Color', is_admin:'Admin access',
    };

    const changes = [];
    const allKeys = new Set([...Object.keys(oldObj), ...Object.keys(newObj)]);
    const skipKeys = new Set(['id','updated_at','created_at','password','logo_url','favicon_url']);

    for (const key of allKeys) {
      if (skipKeys.has(key)) continue;
      const oldVal = oldObj[key];
      const newVal = newObj[key];
      if (oldVal===newVal) continue;
      const label = FIELD_LABELS[key] || key.replace(/_/g,' ');
      if (oldVal===undefined || oldVal===null) {
        changes.push(`Set ${label} to "${newVal}"`);
      } else if (newVal===undefined || newVal===null) {
        changes.push(`Cleared ${label}`);
      } else if (key==='is_active') {
        changes.push(newVal ? 'Activated account' : 'Deactivated account');
      } else if (key==='is_admin') {
        changes.push(newVal ? 'Granted admin access' : 'Removed admin access');
      } else if (key==='status') {
        const st = {pending:'Pending','in-progress':'In Progress',closed:'Task Closed'};
        changes.push(`Changed status: ${st[oldVal]||oldVal} → ${st[newVal]||newVal}`);
      } else if (key==='priority') {
        changes.push(`Changed priority: ${oldVal} → ${newVal}`);
      } else {
        const ov = String(oldVal).slice(0,40);
        const nv = String(newVal).slice(0,40);
        changes.push(`${label}: "${ov}" → "${nv}"`);
      }
    }
    return changes.length ? changes : null;
  } catch { return null; }
}

export default function Audit() {
  const { user } = useAuth();
  const [logs, setLogs]     = useState([]);
  const [users, setUsers]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ user_id:'', entity:'', action:'', date_from:'', date_to:'' });
  const [expanded, setExpanded] = useState(null);

  if (!user.is_admin) return <div style={{ padding:40, color:'var(--red)' }}>⛔ Admin access required.</div>;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const p = { limit:300 };
      if (filters.user_id)  p.user_id  = filters.user_id;
      if (filters.entity)   p.entity   = filters.entity;
      if (filters.action)   p.action   = filters.action;
      if (filters.date_from)p.date_from = filters.date_from;
      if (filters.date_to)  p.date_to   = filters.date_to;
      const [l, u] = await Promise.all([getAuditLog(p), getUsers()]);
      setLogs(l); setUsers(u);
    } catch {} finally { setLoading(false); }
  }, [filters]);

  useEffect(() => { load(); }, [load]);
  const set = (k,v) => setFilters(f=>({...f,[k]:v}));

  const entities    = [...new Set(logs.map(l=>l.entity).filter(Boolean))];
  const actionTypes = [...new Set(logs.map(l=>l.action).filter(Boolean))];

  return (
    <div className="fade-up">
      <SectionHeader title="🔍 Audit Logs" sub={`${logs.length} entries — Admin only`}
        action={<button className="btn btn-ghost" onClick={load}>🔄 Refresh</button>} />

      <div style={{ background:'rgba(239,68,68,.08)', border:'1px solid rgba(239,68,68,.25)', borderRadius:'var(--radius)', padding:'10px 16px', marginBottom:16, display:'flex', alignItems:'center', gap:10 }}>
        <span>🔒</span>
        <span style={{ fontSize:13 }}><strong>Secure Audit Log</strong> — Every action in the system is tracked. Visible only to Super Admins.</span>
      </div>

      <div className="card card-sm mb-16">
        <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:10 }}>
          <div><div className="label">Employee</div>
            <select className="input" value={filters.user_id} onChange={e=>set('user_id',e.target.value)}>
              <option value="">All Users</option>
              {users.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}
            </select></div>
          <div><div className="label">Entity</div>
            <select className="input" value={filters.entity} onChange={e=>set('entity',e.target.value)}>
              <option value="">All</option>
              {entities.map(e=><option key={e}>{e}</option>)}
            </select></div>
          <div><div className="label">Action</div>
            <select className="input" value={filters.action} onChange={e=>set('action',e.target.value)}>
              <option value="">All</option>
              {actionTypes.map(a=><option key={a}>{a}</option>)}
            </select></div>
          <div><div className="label">From Date</div><input className="input" type="date" value={filters.date_from} onChange={e=>set('date_from',e.target.value)} /></div>
          <div><div className="label">To Date</div><input className="input" type="date" value={filters.date_to} onChange={e=>set('date_to',e.target.value)} /></div>
        </div>
      </div>

      {loading ? <PageLoader /> : logs.length===0 ? <EmptyState icon="🔍" title="No audit logs" sub="No activity matching these filters" /> : (
        <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
          {logs.map(log => {
            const meta   = ACTION_LABELS[log.action] || { label:log.action?.replace(/_/g,' '), icon:'📝', color:'badge-gray' };
            const changes = describeChange(log.old_data, log.new_data, log.entity);
            const hasDetails = !!changes?.length;
            return (
              <div key={log.id} className="card card-sm" style={{ transition:'all .15s' }}>
                <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                  {/* Icon + action */}
                  <div style={{ width:36, height:36, borderRadius:'var(--radius-sm)', background:'var(--bg3)', border:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, flexShrink:0 }}>{meta.icon}</div>
                  {/* Main info */}
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
                      <span style={{ fontWeight:600, fontSize:13 }}>{log.user_name}</span>
                      <span className={`badge ${meta.color}`} style={{ fontSize:11 }}>{meta.label}</span>
                      {log.entity && log.entity!=='auth' && <span style={{ fontSize:11, color:'var(--text3)' }}>on {log.entity}</span>}
                    </div>
                    <div style={{ fontSize:11, color:'var(--text3)', marginTop:2 }}>
                      {log.created_at}
                      {log.ip_address && <span style={{ marginLeft:8, fontFamily:'var(--mono)', fontSize:10 }}>· {log.ip_address}</span>}
                    </div>
                    {/* Show first change inline */}
                    {changes?.length>0 && !expanded!==log.id && (
                      <div style={{ fontSize:12, color:'var(--text2)', marginTop:4 }}>{changes[0]}{changes.length>1&&` +${changes.length-1} more`}</div>
                    )}
                  </div>
                  {/* Expand button */}
                  {hasDetails && (
                    <button className="btn btn-ghost btn-sm" onClick={()=>setExpanded(expanded===log.id?null:log.id)} style={{ flexShrink:0 }}>
                      {expanded===log.id?'▲ Less':'▼ Details'}
                    </button>
                  )}
                </div>

                {/* Expanded details — readable */}
                {expanded===log.id && changes?.length>0 && (
                  <div style={{ marginTop:12, paddingTop:12, borderTop:'1px solid var(--border)' }}>
                    <div style={{ fontSize:11, color:'var(--text3)', marginBottom:8, textTransform:'uppercase', letterSpacing:'.5px', fontWeight:600 }}>What changed:</div>
                    <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
                      {changes.map((c,i)=>(
                        <div key={i} style={{ display:'flex', alignItems:'flex-start', gap:8, fontSize:13 }}>
                          <span style={{ color:'var(--accent2)', flexShrink:0 }}>•</span>
                          <span style={{ color:'var(--text)' }}>{c}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
