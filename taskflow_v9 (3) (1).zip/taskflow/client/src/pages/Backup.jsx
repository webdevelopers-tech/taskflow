import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { SectionHeader, PageLoader } from '../components/UI';
import { exportFull, exportBackup, exportTasks, exportEmployees, exportHistory, getTaskStats, getUsers, getCategories } from '../utils/api';
import toast from 'react-hot-toast';

export default function Backup() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [exportFilters, setExportFilters] = useState({ date_from:'', date_to:'', user_id:'' });
  const [users, setUsers] = useState([]);
  const [cats, setCats] = useState([]);

  if (!user.is_admin) return <div style={{ padding:40, color:'var(--red)' }}>⛔ Admin access required.</div>;

  useEffect(() => {
    Promise.all([getTaskStats(), getUsers(), getCategories()]).then(([s,u,c]) => {
      setStats(s); setUsers(u); setCats(c);
    }).finally(()=>setLoading(false));
  }, []);

  const set = (k,v) => setExportFilters(f=>({...f,[k]:v}));

  const items = [
    { label:'📊 Full Excel Export', sub:'All data in one Excel file — 10 sheets (Tasks, Users, History, Reminders, Audit, Analytics, Categories…)', badge:'XLSX', color:'var(--green)', action: () => { exportFull(); toast.success('Downloading full Excel export…'); } },
    { label:'🗄 JSON Backup', sub:'Complete database backup in JSON format — preserves all data, restorable', badge:'JSON', color:'var(--teal)', action: () => { exportBackup(); toast.success('Downloading JSON backup…'); } },
    { label:'✅ Tasks Export', sub:'Export filtered tasks with status, priority, assignee, dates', badge:'XLSX', color:'var(--accent)', action: () => { exportTasks(exportFilters); toast.success('Downloading tasks…'); } },
    { label:'👥 Employee Report', sub:'Performance report — completion rates, hours logged, overdue tasks', badge:'XLSX', color:'var(--purple)', action: () => { exportEmployees(); toast.success('Downloading employee report…'); } },
    { label:'📜 History Export', sub:'Task activity history with employee, date and action filters', badge:'XLSX', color:'var(--amber)', action: () => { exportHistory(exportFilters); toast.success('Downloading history…'); } },
  ];

  if (loading) return <PageLoader />;

  return (
    <div className="fade-up">
      <SectionHeader title="🗄 Backup & Export" sub="Download complete data exports — Admin only" />

      {/* Data overview */}
      <div className="stats-grid mb-20">
        {[
          { l:'Total Tasks',    v:stats?.total||0,       c:'var(--text)' },
          { l:'Closed Tasks',   v:stats?.closed||0,      c:'var(--green)' },
          { l:'Employees',      v:users.length,           c:'var(--accent)' },
          { l:'Categories',     v:cats.length,            c:'var(--amber)' },
        ].map(s=>(
          <div key={s.l} className="stat-card">
            <div className="stat-value" style={{ color:s.c }}>{s.v}</div>
            <div className="stat-label">{s.l}</div>
          </div>
        ))}
      </div>

      {/* Filters for filtered exports */}
      <div className="card card-sm mb-20">
        <div className="card-title">🔍 Export Filters (applies to Tasks & History exports)</div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12 }}>
          <div>
            <div className="label">Employee</div>
            <select className="input" value={exportFilters.user_id} onChange={e=>set('user_id',e.target.value)}>
              <option value="">All Employees</option>
              {users.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
          </div>
          <div>
            <div className="label">From Date</div>
            <input className="input" type="date" value={exportFilters.date_from} onChange={e=>set('date_from',e.target.value)} />
          </div>
          <div>
            <div className="label">To Date</div>
            <input className="input" type="date" value={exportFilters.date_to} onChange={e=>set('date_to',e.target.value)} />
          </div>
        </div>
      </div>

      {/* Export buttons */}
      <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
        {items.map((item,i) => (
          <div key={i} className="card card-sm" style={{ display:'flex', alignItems:'center', gap:16 }}>
            <div style={{ flex:1 }}>
              <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:4 }}>
                <span style={{ fontWeight:600, fontSize:14 }}>{item.label}</span>
                <span className="badge" style={{ background:item.color+'22', color:item.color, fontSize:10 }}>{item.badge}</span>
              </div>
              <div style={{ fontSize:12, color:'var(--text2)' }}>{item.sub}</div>
            </div>
            <button className="btn btn-ghost" onClick={item.action} style={{ flexShrink:0 }}>📥 Download</button>
          </div>
        ))}
      </div>

      <div style={{ marginTop:24, padding:'14px 16px', background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'var(--radius)', fontSize:12, color:'var(--text3)', lineHeight:1.7 }}>
        <strong style={{ color:'var(--text2)' }}>ℹ️ About exports:</strong> Excel exports include company branding, colored headers, and auto-formatted cells. JSON backup preserves complete database structure and can be used to restore data. Date filters apply to Tasks and History exports only. Full Export includes all data regardless of filters.
      </div>
    </div>
  );
}
