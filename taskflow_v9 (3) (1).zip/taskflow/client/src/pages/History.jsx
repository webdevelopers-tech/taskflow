import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { Avatar, PageLoader, EmptyState, SectionHeader } from '../components/UI';
import { getHistory, getUsers, exportHistory } from '../utils/api';

const ACTIONS = ['','task_created','task_closed','status_changed','priority_changed','due_date_changed','comment_added','task_reopened','assigned_to_changed'];

export default function History() {
  const { user } = useAuth();
  const [history, setHistory] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ user_id:'', action:'', date_from:'', date_to:'' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const p = { limit:200 };
      if (filters.user_id)  p.user_id  = filters.user_id;
      if (filters.action)   p.action   = filters.action;
      if (filters.date_from)p.date_from = filters.date_from;
      if (filters.date_to)  p.date_to   = filters.date_to;
      setHistory(await getHistory(p));
    } catch {} setLoading(false);
  }, [filters]);

  useEffect(() => { load(); getUsers().then(setUsers); }, [load]);

  const set = (k,v) => setFilters(f=>({...f,[k]:v}));

  const actionIcons = { task_created:'🆕', task_closed:'✅', status_changed:'🔄', priority_changed:'⚡', due_date_changed:'📅', comment_added:'💬', task_reopened:'↩️', assigned_to_changed:'👤' };

  const handleExport = () => {
    const p = {};
    if (filters.user_id) p.user_id = filters.user_id;
    if (filters.date_from) p.date_from = filters.date_from;
    if (filters.date_to)   p.date_to   = filters.date_to;
    exportHistory(p);
  };

  return (
    <div className="fade-up">
      <SectionHeader
        title="📜 Task History"
        sub="Complete audit trail of all task activities"
        action={
          <div className="flex gap-8">
            {user.is_admin && <button className="btn btn-ghost" onClick={handleExport}>📥 Export Excel</button>}
            <button className="btn btn-accent" onClick={load}>🔄 Refresh</button>
          </div>
        }
      />

      {/* Filters */}
      <div className="card card-sm mb-16">
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:12 }}>
          <div>
            <div className="label">Employee</div>
            <select className="input" value={filters.user_id} onChange={e=>set('user_id',e.target.value)}>
              <option value="">All Employees</option>
              {users.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
          </div>
          <div>
            <div className="label">Action Type</div>
            <select className="input" value={filters.action} onChange={e=>set('action',e.target.value)}>
              {ACTIONS.map(a=><option key={a} value={a}>{a||'All Actions'}</option>)}
            </select>
          </div>
          <div>
            <div className="label">From Date</div>
            <input className="input" type="date" value={filters.date_from} onChange={e=>set('date_from',e.target.value)} />
          </div>
          <div>
            <div className="label">To Date</div>
            <input className="input" type="date" value={filters.date_to} onChange={e=>set('date_to',e.target.value)} />
          </div>
        </div>
      </div>

      {loading ? <PageLoader /> : history.length===0 ? (
        <EmptyState icon="📜" title="No history found" sub="Try adjusting filters" />
      ) : (
        <div className="card" style={{ overflow:'auto' }}>
          <div style={{ marginBottom:12, fontSize:13, color:'var(--text2)' }}>{history.length} entries</div>
          <table className="data-table">
            <thead>
              <tr><th>When</th><th>Employee</th><th>Action</th><th>Task</th><th>Change</th></tr>
            </thead>
            <tbody>
              {history.map(h=>(
                <tr key={h.id}>
                  <td style={{ fontSize:12, color:'var(--text3)', fontFamily:'var(--mono)', whiteSpace:'nowrap' }}>{h.created_at}</td>
                  <td>
                    <div className="flex items-center gap-8">
                      <Avatar name={h.user_name} color={h.user_color} size="xs" />
                      <div>
                        <div style={{ fontSize:12, fontWeight:500 }}>{h.user_name}</div>
                        <div style={{ fontSize:11, color:'var(--text3)' }}>{h.department}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span style={{ fontSize:13 }}>{actionIcons[h.action]||'📝'} </span>
                    <span style={{ fontSize:12, color:'var(--text2)' }}>{h.action?.replace(/_/g,' ')}</span>
                  </td>
                  <td style={{ fontSize:12, maxWidth:200 }}>
                    <div style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{h.task_title||h.task_id}</div>
                  </td>
                  <td>
                    {h.old_value&&h.new_value ? (
                      <div className="flex items-center gap-6" style={{ fontSize:12 }}>
                        <span style={{ background:'var(--red-bg)', color:'var(--red)', padding:'2px 6px', borderRadius:4, textDecoration:'line-through' }}>{h.old_value}</span>
                        <span style={{ color:'var(--text3)' }}>→</span>
                        <span style={{ background:'var(--green-bg)', color:'var(--green)', padding:'2px 6px', borderRadius:4 }}>{h.new_value}</span>
                      </div>
                    ) : <span style={{ fontSize:12, color:'var(--text3)' }}>{h.new_value||h.old_value||'—'}</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
