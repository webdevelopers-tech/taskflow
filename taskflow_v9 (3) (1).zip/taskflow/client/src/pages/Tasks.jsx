import { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth, useWS } from '../context/AuthContext';
import { TaskCard, TaskModal } from '../components/TaskComponents';
import { EmptyState, PageLoader, SectionHeader } from '../components/UI';
import { getTasks, getUsers } from '../utils/api';

const FILTERS = [
  {k:'all',l:'All'},{k:'overdue',l:'🔴 Overdue'},{k:'pending',l:'⏳ Pending'},
  {k:'in-progress',l:'🔄 In Progress'},{k:'closed',l:'✅ Task Closed'},{k:'high',l:'🔥 High Priority'},
];

export function AllTasks() {
  const { subscribe } = useWS();
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState('all');
  const [assigneeF, setAssigneeF] = useState('');
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [searchParams] = useSearchParams();
  const searchQ = searchParams.get('search')||'';
  const highlightId = searchParams.get('highlight');

  const load = useCallback(async () => {
    setLoading(true);
    const p = { limit:200 };
    if (filter==='overdue') p.overdue='true';
    else if (filter==='pending') p.status='pending';
    else if (filter==='in-progress') p.status='in-progress';
    else if (filter==='closed') p.status='closed';
    else if (filter==='high') p.priority='high';
    if (assigneeF) p.assigned_to=assigneeF;
    if (searchQ) p.search=searchQ;
    try { const d=await getTasks(p); setTasks(d.tasks); } catch {}
    setLoading(false);
  }, [filter, assigneeF, searchQ]);

  useEffect(() => { load(); getUsers().then(setUsers); }, [load]);

  useEffect(() => {
    if (!subscribe) return;
    const u1 = subscribe('task:created', load);
    const u2 = subscribe('task:updated', load);
    const u3 = subscribe('task:deleted', load);
    return ()=>{u1();u2();u3();};
  }, [subscribe, load]);

  return (
    <div className="fade-up">
      <SectionHeader
        title="☑ All Tasks"
        sub={`${tasks.length} tasks · Real-time updates enabled`}
        action={<button className="btn btn-accent" onClick={()=>setModal(true)}>➕ New Task</button>}
      />
      <div className="card card-sm mb-16">
        <div className="filter-chips" style={{ marginBottom:searchQ?8:0 }}>
          {FILTERS.map(f=><span key={f.k} className={`chip ${filter===f.k?'active':''}`} onClick={()=>setFilter(f.k)}>{f.l}</span>)}
          <select className="input" style={{ width:'auto', padding:'5px 10px', fontSize:12, height:30 }} value={assigneeF} onChange={e=>setAssigneeF(e.target.value)}>
            <option value="">All Assignees</option>
            {users.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        </div>
        {searchQ && <div style={{ fontSize:13, color:'var(--text2)' }}>Showing results for <strong style={{color:'var(--text)'}}>{searchQ}</strong></div>}
      </div>
      {loading ? <PageLoader /> : tasks.length===0 ? (
        <EmptyState icon="☑" title="No tasks found" sub="Try a different filter" action={<button className="btn btn-accent" onClick={()=>setModal(true)}>➕ New Task</button>} />
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:9 }}>
          {tasks.map(t=>(
            <div key={t.id} style={{ outline: highlightId===t.id?'2px solid var(--accent)':'none', borderRadius:'var(--radius)', transition:'outline .3s' }}>
              <TaskCard task={t} onUpdate={u=>setTasks(ts=>ts.map(x=>x.id===u.id?u:x))} onDelete={id=>setTasks(ts=>ts.filter(x=>x.id!==id))} />
            </div>
          ))}
        </div>
      )}
      <TaskModal open={modal} onClose={()=>setModal(false)} onSave={load} users={users} />
    </div>
  );
}

export function MyTasks() {
  const { user } = useAuth(); const { subscribe } = useWS();
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const p = { assigned_to: user.id, limit:200 };
    if (filter==='pending') p.status='pending';
    else if (filter==='overdue') p.overdue='true';
    else if (filter==='closed') p.status='closed';
    else if (filter==='in-progress') p.status='in-progress';
    try { const d=await getTasks(p); setTasks(d.tasks); } catch {}
    setLoading(false);
  }, [filter, user.id]);

  useEffect(() => { load(); getUsers().then(setUsers); }, [load]);
  useEffect(() => {
    if (!subscribe) return;
    const u1=subscribe('task:created',load),u2=subscribe('task:updated',load);
    return ()=>{u1();u2();};
  }, [subscribe, load]);

  return (
    <div className="fade-up">
      <SectionHeader title="◎ My Tasks" sub="Tasks assigned to you" action={<button className="btn btn-accent" onClick={()=>setModal(true)}>➕ New Task</button>} />
      <div className="filter-chips">
        {[{k:'all',l:'All'},{k:'pending',l:'⏳ Pending'},{k:'in-progress',l:'🔄 In Progress'},{k:'overdue',l:'🔴 Overdue'},{k:'closed',l:'✅ Closed'}].map(f=>(
          <span key={f.k} className={`chip ${filter===f.k?'active':''}`} onClick={()=>setFilter(f.k)}>{f.l}</span>
        ))}
      </div>
      {loading ? <PageLoader /> : tasks.length===0 ? <EmptyState icon="🎉" title="All caught up!" sub="No tasks in this view" /> : (
        <div style={{ display:'flex', flexDirection:'column', gap:9 }}>
          {tasks.map(t=><TaskCard key={t.id} task={t} onUpdate={u=>setTasks(ts=>ts.map(x=>x.id===u.id?u:x))} onDelete={id=>setTasks(ts=>ts.filter(x=>x.id!==id))} />)}
        </div>
      )}
      <TaskModal open={modal} onClose={()=>setModal(false)} onSave={load} users={users} defaultAssignee={user.id} />
    </div>
  );
}
