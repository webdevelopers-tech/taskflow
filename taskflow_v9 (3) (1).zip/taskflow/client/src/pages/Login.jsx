import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Spinner } from '../components/UI';
import toast from 'react-hot-toast';

export default function Login() {
  const [email, setEmail] = useState('');
  const [pwd, setPwd] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, brand } = useAuth();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try { await login(email, pwd); navigate('/dashboard'); }
    catch { toast.error('Invalid email or password'); }
    setLoading(false);
  };

  const demos = [
    ['admin@taskflow.io','admin123','Super Admin','IST'],
    ['alex@taskflow.io','pass123','Sr. Developer','CST'],
    ['maya@taskflow.io','pass123','Designer','IST'],
    ['james@taskflow.io','pass123','Marketing','CST'],
  ];

  const bgColor = brand?.login_bg_color || '#0a0e1a';
  const primary  = brand?.primary_color  || '#6366f1';
  const logoText = brand?.login_logo_text || 'TF';
  const companyName = brand?.company_name || 'TaskFlow';
  const tagline = brand?.tagline || 'Office Collaboration Platform';

  return (
    <div style={{ minHeight:'100vh', background:bgColor, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}>
      <div style={{ background:'var(--bg2)', border:'1px solid var(--border2)', borderRadius:'var(--radius-xl)', padding:'44px 40px', width:420, maxWidth:'100%', boxShadow:'0 24px 80px rgba(0,0,0,.7)' }}>
        {/* Logo */}
        <div className="flex items-center gap-12 mb-32">
          {brand?.logo_url
            ? <img src={brand.logo_url} style={{ height:36, objectFit:'contain' }} alt="logo" />
            : <div style={{ width:44, height:44, background:primary, borderRadius:11, display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, fontWeight:800, color:'#fff', letterSpacing:'-1px' }}>{logoText}</div>
          }
          <div>
            <div style={{ fontSize:20, fontWeight:700, letterSpacing:'-.5px' }}>{companyName}</div>
            <div style={{ fontSize:11, color:'var(--text3)', letterSpacing:'.5px', textTransform:'uppercase' }}>{tagline}</div>
          </div>
        </div>

        <h2 style={{ fontSize:22, fontWeight:700, marginBottom:4, letterSpacing:'-.5px' }}>Welcome back</h2>
        <p style={{ color:'var(--text2)', fontSize:13, marginBottom:28 }}>Sign in to your workspace</p>

        <form onSubmit={submit}>
          {[['Email','email',email,setEmail,'name@company.com'],['Password','password',pwd,setPwd,'Enter your password']].map(([l,t,v,sv,ph])=>(
            <div key={l} style={{ marginBottom:14 }}>
              <label className="label">{l}</label>
              <input style={{ width:'100%', background:'var(--bg3)', border:'1px solid var(--border2)', borderRadius:'var(--radius-sm)', padding:'10px 14px', color:'var(--text)', fontSize:13, outline:'none', fontFamily:'var(--font)', transition:'all .2s' }}
                type={t} value={v} onChange={e=>sv(e.target.value)} placeholder={ph} autoFocus={l==='Email'}
                onFocus={e=>{e.target.style.borderColor=primary; e.target.style.boxShadow=`0 0 0 3px ${primary}22`;}}
                onBlur={e=>{e.target.style.borderColor='var(--border2)'; e.target.style.boxShadow='none';}}
              />
            </div>
          ))}
          <button type="submit" disabled={loading||!email||!pwd}
            style={{ width:'100%', background:loading?'var(--bg3)':primary, color:loading?'var(--text2)':'#fff', borderRadius:'var(--radius-sm)', padding:'11px 20px', fontSize:14, fontWeight:600, border:'none', cursor:loading?'not-allowed':'pointer', transition:'all .2s', display:'flex', alignItems:'center', justifyContent:'center', gap:8, marginTop:4 }}>
            {loading ? <><Spinner size={16}/> Signing in…</> : 'Sign In →'}
          </button>
        </form>

        <div style={{ marginTop:22, padding:14, background:'var(--accent-bg)', border:'1px solid var(--accent-border)', borderRadius:'var(--radius-sm)' }}>
          <p style={{ fontSize:11, color:'var(--text2)', marginBottom:8, fontWeight:600, textTransform:'uppercase', letterSpacing:'.5px' }}>Demo Accounts</p>
          {demos.map(([e,p,role,tz])=>(
            <button key={e} onClick={()=>{setEmail(e);setPwd(p);}}
              style={{ display:'block', width:'100%', textAlign:'left', padding:'5px 0', fontSize:12, color:'var(--text2)', background:'none', border:'none', cursor:'pointer', transition:'color .15s' }}
              onMouseEnter={el=>el.currentTarget.style.color='var(--accent2)'}
              onMouseLeave={el=>el.currentTarget.style.color='var(--text2)'}>
              <span style={{ color:'var(--accent2)', fontFamily:'var(--mono)', fontSize:11 }}>{e}</span>
              <span style={{ color:'var(--text3)' }}> · {p} · </span>{role} ({tz})
            </button>
          ))}
        </div>
        {brand?.footer_text && <p style={{ textAlign:'center', fontSize:11, color:'var(--text3)', marginTop:20 }}>{brand.footer_text}</p>}
      </div>
    </div>
  );
}
