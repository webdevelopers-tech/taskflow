import { useState, useEffect, useCallback } from 'react';
import { useAuth, useWS } from '../context/AuthContext';
import { Avatar, SectionHeader, Modal, FormGroup, Toggle, PageLoader, EmptyState } from '../components/UI';
import { getCategories, getCategory, createCategory, updateCategory, deleteCategory, updateCategoryMembers, getUsers } from '../utils/api';
import toast from 'react-hot-toast';

const PRESET_COLORS = ['#6366f1','#14b8a6','#f59e0b','#22c55e','#ef4444','#ec4899','#06b6d4','#8b5cf6','#f97316','#64748b','#e11d48','#0ea5e9'];
const PRESET_ICONS  = ['📁','📣','💻','👥','💼','🎧','💰','⚙','🤝','🏨','🔧','📊','🎯','🚀','📋','🔬'];

export default function Categories() {
  const { user } = useAuth();
  const { subscribe } = useWS();
  const [cats, setCats]       = useState([]);
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal]     = useState(false);
  const [membersModal, setMembersModal] = useState(false);
  const [editCat, setEditCat] = useState(null);
  const [membersCat, setMembersCat] = useState(null);
  const [selectedMembers, setSelectedMembers] = useState([]);

  if (!user.is_admin) return <div style={{ padding:40, color:'var(--red)' }}>⛔ Admin access required.</div>;

  const load = useCallback(async () => {
    try {
      const [c, u] = await Promise.all([getCategories({ all:'true' }), getUsers()]);
      setCats(c); setUsers(u);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!subscribe) return;
    const u1 = subscribe('category:created', load);
    const u2 = subscribe('category:updated', load);
    const u3 = subscribe('category:deleted', load);
    return () => { u1(); u2(); u3(); };
  }, [subscribe, load]);

  const openEdit = (cat=null) => { setEditCat(cat); setModal(true); };

  const openMembers = async (cat) => {
    setMembersCat(cat);
    try {
      const detail = await getCategory(cat.id);
      setSelectedMembers((detail.members||[]).map(m=>m.id));
    } catch { setSelectedMembers([]); }
    setMembersModal(true);
  };

  const handleToggleActive = async (cat) => {
    await updateCategory(cat.id, { is_active: cat.is_active ? 0 : 1 });
    toast.success(cat.is_active ? 'Category disabled' : 'Category enabled');
    load();
  };

  const saveMembers = async () => {
    await updateCategoryMembers(membersCat.id, selectedMembers);
    toast.success('✅ Members updated');
    setMembersModal(false); load();
  };

  if (loading) return <PageLoader />;

  const activeCats   = cats.filter(c=>c.is_active);
  const inactiveCats = cats.filter(c=>!c.is_active);

  return (
    <div className="fade-up">
      <SectionHeader
        title="📁 Category Management"
        sub={`${activeCats.length} active · ${inactiveCats.length} disabled`}
        action={<button className="btn btn-accent" onClick={()=>openEdit(null)}>➕ Add Category</button>}
      />

      <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:24 }}>
        {activeCats.map(cat => (
          <div key={cat.id} className="card card-sm" style={{ borderLeft:`4px solid ${cat.color}` }}>
            <div style={{ display:'flex', alignItems:'center', gap:16 }}>
              <div style={{ width:42, height:42, borderRadius:'var(--radius-sm)', background:cat.color+'22', border:`1px solid ${cat.color}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0 }}>{cat.icon||'📁'}</div>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <span style={{ fontWeight:600, fontSize:14 }}>{cat.name}</span>
                  <span style={{ width:10, height:10, borderRadius:'50%', background:cat.color, display:'inline-block' }} />
                  <span style={{ fontSize:11, color:'var(--text3)', fontFamily:'var(--mono)' }}>{cat.color}</span>
                </div>
                {cat.description && <div style={{ fontSize:12, color:'var(--text2)', marginTop:2 }}>{cat.description}</div>}
                <div style={{ fontSize:11, color:'var(--text3)', marginTop:3 }}>{cat.member_count||0} members assigned</div>
              </div>
              <div style={{ display:'flex', gap:8, alignItems:'center', flexShrink:0 }}>
                <Toggle on={!!cat.is_active} onChange={()=>handleToggleActive(cat)} />
                <button className="btn btn-ghost btn-sm" onClick={()=>openMembers(cat)}>👥 Members</button>
                <button className="btn btn-ghost btn-sm" onClick={()=>openEdit(cat)}>✎ Edit</button>
              </div>
            </div>
          </div>
        ))}
        {activeCats.length===0 && <EmptyState icon="📁" title="No active categories" sub="Add your first category above" />}
      </div>

      {inactiveCats.length>0 && (
        <div>
          <div style={{ fontSize:12, color:'var(--text3)', marginBottom:10, textTransform:'uppercase', letterSpacing:'.5px', fontWeight:600 }}>Disabled</div>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {inactiveCats.map(cat => (
              <div key={cat.id} className="card card-sm" style={{ opacity:.5 }}>
                <div style={{ display:'flex', alignItems:'center', gap:12, justifyContent:'space-between' }}>
                  <div className="flex items-center gap-10">
                    <span style={{ fontSize:18 }}>{cat.icon||'📁'}</span>
                    <span style={{ fontSize:13, textDecoration:'line-through', color:'var(--text3)' }}>{cat.name}</span>
                  </div>
                  <Toggle on={false} onChange={()=>handleToggleActive(cat)} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <CategoryModal open={modal} onClose={()=>setModal(false)} editData={editCat} onSave={()=>{ load(); setModal(false); }} />

      <Modal open={membersModal} onClose={()=>setMembersModal(false)} title={`👥 Assign Members — ${membersCat?.name}`} width={520}>
        <p style={{ fontSize:13, color:'var(--text2)', marginBottom:16 }}>Select employees to assign to this category.</p>
        <div style={{ maxHeight:360, overflowY:'auto', display:'flex', flexDirection:'column', gap:6 }}>
          {users.map(u => {
            const checked = selectedMembers.includes(u.id);
            return (
              <div key={u.id} onClick={()=>setSelectedMembers(m=>checked?m.filter(x=>x!==u.id):[...m,u.id])}
                style={{ display:'flex', alignItems:'center', gap:12, padding:'9px 12px', borderRadius:'var(--radius-sm)', border:`1px solid ${checked?'var(--accent)':'var(--border)'}`, background:checked?'var(--accent-bg)':'var(--bg3)', cursor:'pointer', transition:'all .15s' }}>
                <div style={{ width:18, height:18, borderRadius:4, border:`2px solid ${checked?'var(--accent)':'var(--border2)'}`, background:checked?'var(--accent)':'transparent', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                  {checked && <span style={{ color:'#fff', fontSize:11, fontWeight:700 }}>✓</span>}
                </div>
                <Avatar name={u.name} color={u.color} size="xs" />
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13, fontWeight:500 }}>{u.name}</div>
                  <div style={{ fontSize:11, color:'var(--text2)' }}>{u.role} · {u.department}</div>
                </div>
                <span className={`badge ${u.timezone==='IST'?'badge-purple':'badge-teal'}`}>{u.timezone}</span>
              </div>
            );
          })}
        </div>
        <div className="flex items-center justify-between mt-16 pt-12" style={{ borderTop:'1px solid var(--border)' }}>
          <span style={{ fontSize:12, color:'var(--text2)' }}>{selectedMembers.length} selected</span>
          <div className="flex gap-8">
            <button className="btn btn-ghost" onClick={()=>setMembersModal(false)}>Cancel</button>
            <button className="btn btn-accent" onClick={saveMembers}>Save Members</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function CategoryModal({ open, onClose, editData, onSave }) {
  const [form, setForm] = useState({ name:'', color:'#6366f1', icon:'📁', description:'', is_active:true, sort_order:0 });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (editData) setForm({ name:editData.name, color:editData.color, icon:editData.icon||'📁', description:editData.description||'', is_active:!!editData.is_active, sort_order:editData.sort_order||0 });
    else setForm({ name:'', color:'#6366f1', icon:'📁', description:'', is_active:true, sort_order:0 });
  }, [editData, open]);

  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const save = async () => {
    if (!form.name.trim()) return toast.error('Name required');
    setSaving(true);
    try {
      if (editData) await updateCategory(editData.id, form);
      else await createCategory(form);
      toast.success(editData?'✅ Category updated':'✅ Category created');
      onSave();
    } catch(e) { toast.error(e.response?.data?.error||'Failed'); }
    setSaving(false);
  };

  return (
    <Modal open={open} onClose={onClose} title={editData?'✎ Edit Category':'➕ New Category'} width={500}>
      <FormGroup label="Category Name" required>
        <input className="input" value={form.name} onChange={e=>set('name',e.target.value)} placeholder="e.g. Marketing, Support…" />
      </FormGroup>
      <FormGroup label="Description">
        <input className="input" value={form.description} onChange={e=>set('description',e.target.value)} placeholder="Optional description" />
      </FormGroup>
      <FormGroup label="Icon">
        <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:4 }}>
          {PRESET_ICONS.map(ic=>(
            <div key={ic} onClick={()=>set('icon',ic)} style={{ width:34, height:34, borderRadius:6, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, cursor:'pointer', border:`2px solid ${form.icon===ic?'var(--accent)':'var(--border)'}`, background:form.icon===ic?'var(--accent-bg)':'var(--bg3)', transition:'all .15s' }}>{ic}</div>
          ))}
        </div>
      </FormGroup>
      <FormGroup label="Color">
        <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
          {PRESET_COLORS.map(c=>(
            <div key={c} onClick={()=>set('color',c)} style={{ width:26, height:26, borderRadius:'50%', background:c, cursor:'pointer', border:form.color===c?'3px solid white':'3px solid transparent', boxShadow:form.color===c?`0 0 0 2px ${c}`:'none', transition:'all .15s' }} />
          ))}
          <input type="color" value={form.color} onChange={e=>set('color',e.target.value)} style={{ width:32, height:26, borderRadius:5, cursor:'pointer', border:'1px solid var(--border)', background:'var(--bg3)', padding:2 }} />
          <code style={{ fontSize:12, fontFamily:'var(--mono)', color:'var(--text2)' }}>{form.color}</code>
        </div>
      </FormGroup>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:16 }}>
        <Toggle on={form.is_active} onChange={v=>set('is_active',v)} />
        <span style={{ fontSize:13 }}>{form.is_active?'Active (visible in dropdowns)':'Disabled'}</span>
      </div>
      <div className="flex gap-10 justify-end pt-12" style={{ borderTop:'1px solid var(--border)' }}>
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-accent" onClick={save} disabled={saving}>{saving?'Saving…':editData?'Save Changes':'Create Category'}</button>
      </div>
    </Modal>
  );
}
