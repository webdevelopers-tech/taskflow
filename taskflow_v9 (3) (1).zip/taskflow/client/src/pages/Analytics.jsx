import { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Avatar, PageLoader, SectionHeader, ProgressBar, Modal } from '../components/UI';
import { getEmployeeAnalytics, getTaskAnalytics, getTaskStats, exportEmployees, getUsers, getCategories } from '../utils/api';
import { useAuth } from '../context/AuthContext';

const CT = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return <div style={{ background:'var(--bg2)', border:'1px solid var(--border2)', borderRadius:8, padding:'10px 14px', fontSize:12 }}>
    <div style={{ fontWeight:600, marginBottom:6 }}>{label}</div>
    {payload.map((p,i)=><div key={i} style={{ color:p.color }}>{p.name}: <strong>{p.value}</strong></div>)}
  </div>;
};

const TODAY = new Date().toISOString().split('T')[0];
const LAST7  = new Date(Date.now()-7*86400000).toISOString().split('T')[0];
const LAST30 = new Date(Date.now()-30*86400000).toISOString().split('T')[0];

export default function Analytics() {
  const { user } = useAuth();
  const [employees,   setEmployees]   = useState([]);
  const [taskData,    setTaskData]    = useState(null);
  const [stats,       setStats]       = useState(null);
  const [loading,     setLoading]     = useState(true);
  const [tab,         setTab]         = useState('overview');
  const [selectedEmp, setSelectedEmp] = useState(null); // for deep-dive modal
  const [empTasks,    setEmpTasks]    = useState(null);

  const [filters, setFilters] = useState({ user_id:'', department:'', status:'', priority:'', search:'', date_from:LAST30, date_to:TODAY });
  const setF = (k,v) => setFilters(f=>({...f,[k]:v}));

  const QUICK = [
    { label:'Today',    df:TODAY,  dt:TODAY },
    { label:'Last 7d',  df:LAST7,  dt:TODAY },
    { label:'Last 30d', df:LAST30, dt:TODAY },
    { label:'All time', df:'2020-01-01', dt:TODAY },
  ];

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [e, t, s] = await Promise.all([
        getEmployeeAnalytics(filters.department ? { department:filters.department } : {}),
        getTaskAnalytics(filters),
        getTaskStats(),
      ]);
      setEmployees(e); setTaskData(t); setStats(s);
    } catch {} finally { setLoading(false); }
  }, [filters]);

  useEffect(() => { load(); }, [load]);

  const openEmployeeDrilldown = async (emp) => {
    setSelectedEmp(emp);
    try {
      const d = await getTaskAnalytics({ user_id: emp.id, date_from: filters.date_from, date_to: filters.date_to });
      setEmpTasks(d);
    } catch { setEmpTasks(null); }
  };

  if (!user.is_admin) return <div style={{ padding:40, color:'var(--red)' }}>⛔ Admin access required.</div>;
  if (loading && !stats) return <PageLoader />;

  const depts   = [...new Set(employees.map(e=>e.department).filter(Boolean))];
  const summary = taskData?.summary || {};
  const tasks   = taskData?.tasks   || [];

  const empBarData  = employees.slice(0,8).map(e=>({ name:e.name.split(' ')[0], assigned:e.total_assigned||0, closed:e.total_closed||0, overdue:e.overdue||0 }));
  const speedData   = summary.speed ? [
    { name:'Fast ≤2d', value:summary.speed.fast,   fill:'#10b981' },
    { name:'Normal ≤7d',value:summary.speed.normal, fill:'#6366f1' },
    { name:'Slow >7d',  value:summary.speed.slow,   fill:'#f59e0b' },
  ] : [];
  const statusPie   = stats ? [
    { name:'Pending',    value:stats.pending,    color:'#f59e0b' },
    { name:'In Progress',value:stats.inProgress, color:'#6366f1' },
    { name:'Closed',     value:stats.closed,     color:'#10b981' },
  ] : [];

  return (
    <div className="fade-up">
      <SectionHeader
        title="📊 Analytics"
        sub="Real-time performance & task insights"
        action={<div className="flex gap-8">
          <button className="btn btn-ghost" onClick={exportEmployees}>📥 Export</button>
          <button className="btn btn-ghost btn-sm" onClick={load}>🔄</button>
        </div>}
      />

      {/* Filter bar */}
      <div className="card card-sm mb-16">
        <div style={{ display:'flex', gap:8, flexWrap:'wrap', alignItems:'flex-end' }}>
          <div>
            <div className="label">Quick Range</div>
            <div className="flex gap-6">
              {QUICK.map(r=>(
                <button key={r.label} className={`btn btn-sm ${filters.date_from===r.df&&filters.date_to===r.dt?'btn-accent':'btn-ghost'}`}
                  onClick={()=>setFilters(f=>({...f,date_from:r.df,date_to:r.dt}))}>{r.label}</button>
              ))}
            </div>
          </div>
          <div><div className="label">From</div><input className="input" type="date" value={filters.date_from} onChange={e=>setF('date_from',e.target.value)} /></div>
          <div><div className="label">To</div><input className="input" type="date" value={filters.date_to} onChange={e=>setF('date_to',e.target.value)} /></div>
          <div><div className="label">Dept</div>
            <select className="input" value={filters.department} onChange={e=>setF('department',e.target.value)}>
              <option value="">All</option>{depts.map(d=><option key={d}>{d}</option>)}
            </select>
          </div>
          <div><div className="label">Status</div>
            <select className="input" value={filters.status} onChange={e=>setF('status',e.target.value)}>
              <option value="">All</option><option value="pending">Pending</option><option value="in-progress">In Progress</option><option value="closed">Closed</option>
            </select>
          </div>
          <div><div className="label">Priority</div>
            <select className="input" value={filters.priority} onChange={e=>setF('priority',e.target.value)}>
              <option value="">All</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option>
            </select>
          </div>
          <div style={{ flex:2, minWidth:180 }}><div className="label">Search</div>
            <input className="input" value={filters.search} onChange={e=>setF('search',e.target.value)} placeholder="Task name, employee…" />
          </div>
        </div>
      </div>

      {/* Summary stats */}
      <div className="stats-grid mb-20">
        {[
          { l:'Total Filtered', v:summary.total||0,           c:'var(--text)' },
          { l:'Closed',         v:summary.closed||0,          c:'var(--green)' },
          { l:'Pending',        v:summary.pending||0,         c:'var(--amber)' },
          { l:'In Progress',    v:summary.inProgress||0,      c:'var(--accent)' },
          { l:'Overdue',        v:summary.overdue||0,         c:summary.overdue>0?'var(--red)':'var(--text3)' },
          { l:'Avg Close Days', v:summary.avgCloseDays||'—',  c:'var(--teal)' },
        ].map(s=>(
          <div key={s.l} className="stat-card">
            <div className="stat-value" style={{ color:s.c, fontSize:24 }}>{s.v}</div>
            <div className="stat-label">{s.l}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="tabs">
        {[['overview','📊 Overview'],['employees','👥 Employees'],['drilldown','🔍 Deep Dive'],['tasks','☑ Task List'],['speed','⚡ Speed']].map(([k,l])=>(
          <div key={k} className={`tab ${tab===k?'active':''}`} onClick={()=>setTab(k)}>{l}</div>
        ))}
      </div>

      {/* OVERVIEW */}
      {tab==='overview' && (
        <div>
          <div className="grid-2 mb-16">
            <div className="card">
              <div className="card-title">📊 Tasks per Employee</div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={empBarData} margin={{ left:-20 }}>
                  <XAxis dataKey="name" tick={{ fontSize:11, fill:'var(--text2)' }} />
                  <YAxis tick={{ fontSize:11, fill:'var(--text2)' }} allowDecimals={false} />
                  <Tooltip content={<CT/>} />
                  <Bar dataKey="assigned" name="Assigned" fill="#6366f1" radius={[3,3,0,0]} />
                  <Bar dataKey="closed"   name="Closed"   fill="#10b981" radius={[3,3,0,0]} />
                  <Bar dataKey="overdue"  name="Overdue"  fill="#ef4444" radius={[3,3,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="card">
              <div className="card-title">🥧 Status Distribution</div>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={statusPie} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                    {statusPie.map((e,i)=><Cell key={i} fill={e.color}/>)}
                  </Pie>
                  <Tooltip formatter={(v,n)=>[v,n]} contentStyle={{ background:'var(--bg2)', border:'1px solid var(--border2)', borderRadius:8, fontSize:12 }}/>
                </PieChart>
              </ResponsiveContainer>
              <div className="flex gap-14 justify-center">
                {statusPie.map(d=>(
                  <div key={d.name} style={{ textAlign:'center' }}>
                    <div style={{ width:10, height:10, borderRadius:'50%', background:d.color, margin:'0 auto 2px' }}/>
                    <div style={{ fontSize:11, color:'var(--text2)' }}>{d.name}</div>
                    <div style={{ fontSize:14, fontWeight:700, color:d.color }}>{d.value}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-title">📈 7-Day Completion Trend</div>
            <ResponsiveContainer width="100%" height={140}>
              <LineChart data={stats?.weeklyTrend||[]} margin={{ left:-20 }}>
                <XAxis dataKey="date" tick={{ fontSize:10, fill:'var(--text2)' }} tickFormatter={d=>d.slice(5)} />
                <YAxis tick={{ fontSize:11, fill:'var(--text2)' }} allowDecimals={false} />
                <Tooltip content={<CT/>} />
                <Line type="monotone" dataKey="closed" name="Closed" stroke="#6366f1" strokeWidth={2.5} dot={{ fill:'#6366f1', r:3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* EMPLOYEES TABLE */}
      {tab==='employees' && (
        <div className="card" style={{ overflow:'auto' }}>
          <div style={{ marginBottom:10, fontSize:13, color:'var(--text2)' }}>Click a row to view detailed employee analytics</div>
          <table className="data-table">
            <thead>
              <tr><th>#</th><th>Employee</th><th>Dept</th><th>Assigned</th><th>Closed</th><th>Pending</th><th>Overdue</th><th>Rate</th><th>Avg Days</th><th>Hours</th><th></th></tr>
            </thead>
            <tbody>
              {employees.map((e,i)=>{
                const rate=e.completion_rate||0;
                const rc=rate>=80?'var(--green)':rate>=50?'var(--amber)':'var(--red)';
                return (
                  <tr key={e.id} style={{ cursor:'pointer' }} onClick={()=>{ setSelectedEmp(e); openEmployeeDrilldown(e); setTab('drilldown'); }}>
                    <td style={{ textAlign:'center', fontSize:15 }}>{i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</td>
                    <td><div className="flex items-center gap-8"><Avatar name={e.name} color={e.color} size="xs"/><div><div style={{fontWeight:500,fontSize:13}}>{e.name}</div><div style={{fontSize:11,color:'var(--text3)'}}>{e.role}</div></div></div></td>
                    <td style={{ fontSize:12 }}>{e.department}</td>
                    <td style={{ fontWeight:600 }}>{e.total_assigned||0}</td>
                    <td style={{ color:'var(--green)', fontWeight:600 }}>{e.total_closed||0}</td>
                    <td style={{ color:'var(--amber)' }}>{e.pending||0}</td>
                    <td style={{ color:(e.overdue||0)>0?'var(--red)':'var(--text3)', fontWeight:(e.overdue||0)>0?600:400 }}>{e.overdue||0}</td>
                    <td><div className="flex items-center gap-6"><ProgressBar value={rate} color={rc} height={4}/><span style={{ fontSize:12, color:rc, fontWeight:600, width:38 }}>{rate}%</span></div></td>
                    <td style={{ fontSize:12, color:'var(--text2)' }}>{e.avg_days_to_close?e.avg_days_to_close+'d':'—'}</td>
                    <td style={{ fontSize:12, color:'var(--text2)' }}>{e.total_minutes?Math.round(e.total_minutes/60)+'h':'0h'}</td>
                    <td><button className="btn btn-ghost btn-sm" onClick={e2=>{e2.stopPropagation();setSelectedEmp(e);openEmployeeDrilldown(e);setTab('drilldown');}}>🔍 Deep Dive</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* EMPLOYEE DEEP DIVE */}
      {tab==='drilldown' && (
        <div>
          {!selectedEmp ? (
            <div style={{ textAlign:'center', padding:40, color:'var(--text3)' }}>
              <div style={{ fontSize:30, marginBottom:12 }}>🔍</div>
              <div style={{ fontSize:16, fontWeight:600, color:'var(--text2)' }}>Select an employee</div>
              <div style={{ fontSize:13, marginTop:6 }}>Go to the Employees tab and click any employee or "Deep Dive"</div>
              <button className="btn btn-accent" style={{ marginTop:16 }} onClick={()=>setTab('employees')}>View Employees →</button>
            </div>
          ) : (
            <div>
              {/* Employee header */}
              <div className="card mb-16">
                <div style={{ display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                  <Avatar name={selectedEmp.name} color={selectedEmp.color} size="xl" />
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:20, fontWeight:700 }}>{selectedEmp.name}</div>
                    <div style={{ fontSize:13, color:'var(--text2)', marginTop:2 }}>{selectedEmp.role} · {selectedEmp.department}</div>
                    <div className="flex gap-8 mt-8">
                      <span className={`badge ${selectedEmp.timezone==='IST'?'badge-purple':'badge-teal'}`}>{selectedEmp.timezone}</span>
                      <span style={{ fontSize:12, color:'var(--text3)' }}>{selectedEmp.email}</span>
                      <span style={{ fontSize:12, color:'var(--text3)' }}>Last login: {selectedEmp.last_login?.split(' ')[0]||'Never'}</span>
                    </div>
                  </div>
                  <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:14 }}>
                    {[
                      { l:'Assigned',  v:selectedEmp.total_assigned||0,  c:'var(--text)' },
                      { l:'Closed',    v:selectedEmp.total_closed||0,    c:'var(--green)' },
                      { l:'Pending',   v:selectedEmp.pending||0,          c:'var(--amber)' },
                      { l:'Overdue',   v:selectedEmp.overdue||0,          c:selectedEmp.overdue>0?'var(--red)':'var(--text3)' },
                      { l:'Rate',      v:(selectedEmp.completion_rate||0)+'%', c:selectedEmp.completion_rate>=80?'var(--green)':selectedEmp.completion_rate>=50?'var(--amber)':'var(--red)' },
                    ].map(s=>(
                      <div key={s.l} style={{ textAlign:'center', background:'var(--bg3)', borderRadius:'var(--radius-sm)', padding:'10px 8px' }}>
                        <div style={{ fontSize:22, fontWeight:700, color:s.c }}>{s.v}</div>
                        <div style={{ fontSize:10, color:'var(--text3)', marginTop:2 }}>{s.l}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div style={{ marginTop:14, paddingTop:12, borderTop:'1px solid var(--border)', display:'flex', gap:20, fontSize:12, color:'var(--text2)', flexWrap:'wrap' }}>
                  <span>⏱ Avg close time: <strong>{selectedEmp.avg_days_to_close ? selectedEmp.avg_days_to_close+'d' : '—'}</strong></span>
                  <span>🕐 Hours logged: <strong>{selectedEmp.total_minutes ? Math.round(selectedEmp.total_minutes/60)+'h' : '0h'}</strong></span>
                </div>
              </div>

              {/* Employee tasks */}
              {empTasks ? (
                <div>
                  <div style={{ fontWeight:600, fontSize:14, marginBottom:12 }}>
                    Tasks assigned to {selectedEmp.name.split(' ')[0]} ({empTasks.tasks?.length||0} in range)
                  </div>
                  <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                    {(empTasks.tasks||[]).slice(0,30).map(t=>(
                      <div key={t.id} style={{ background:'var(--bg2)', border:`1px solid var(--border)`, borderLeft:`3px solid ${t.status==='closed'?'var(--green)':t.status==='in-progress'?'var(--accent)':isOverdue(t.due_date)?'var(--red)':'var(--amber)'}`, borderRadius:'var(--radius-sm)', padding:'10px 14px', display:'flex', alignItems:'center', gap:12 }}>
                        <div style={{ flex:1, minWidth:0 }}>
                          <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', textDecoration:t.status==='closed'?'line-through':'none', opacity:t.status==='closed'?.7:1 }}>{t.title}</div>
                          <div style={{ fontSize:11, color:'var(--text3)', marginTop:2 }}>{t.category} · due {t.due_date} {t.age_days!=null?`· ${t.age_days}d old`:''}</div>
                        </div>
                        <span className={`badge badge-${t.priority==='high'?'red':t.priority==='medium'?'amber':'green'}`} style={{ fontSize:10 }}>{t.priority}</span>
                        <span className={`badge ${t.status==='closed'?'badge-green':t.status==='in-progress'?'badge-blue':'badge-amber'}`} style={{ fontSize:10 }}>{t.status==='closed'?'Closed':t.status}</span>
                      </div>
                    ))}
                    {(empTasks.tasks||[]).length>30 && <div style={{ textAlign:'center', fontSize:12, color:'var(--text3)', padding:8 }}>Showing 30 of {empTasks.tasks.length} tasks</div>}
                  </div>
                </div>
              ) : <div style={{ textAlign:'center', padding:30, color:'var(--text3)' }}>Loading employee tasks…</div>}

              <div style={{ marginTop:16 }}>
                <button className="btn btn-ghost" onClick={()=>setTab('employees')}>← Back to Employees</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TASK LIST */}
      {tab==='tasks' && (
        <div className="card" style={{ overflow:'auto' }}>
          <div style={{ marginBottom:10, fontSize:13, color:'var(--text2)' }}>{tasks.length} tasks matching filters</div>
          <table className="data-table">
            <thead>
              <tr><th>Title</th><th>Assignee</th><th>Dept</th><th>Priority</th><th>Status</th><th>Due</th><th>Age</th></tr>
            </thead>
            <tbody>
              {tasks.slice(0,100).map(t=>{
                const overdue = t.status!=='closed' && t.due_date<TODAY;
                return (
                  <tr key={t.id}>
                    <td style={{ maxWidth:260 }}><div style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', fontSize:13, fontWeight:500 }}>{t.title}</div></td>
                    <td><div className="flex items-center gap-6"><Avatar name={t.assignee||'?'} color={t.assignee_color} size="xs"/><span style={{ fontSize:12 }}>{t.assignee}</span></div></td>
                    <td style={{ fontSize:12, color:'var(--text2)' }}>{t.department}</td>
                    <td><span className={`badge badge-${t.priority==='high'?'red':t.priority==='medium'?'amber':'green'}`} style={{ fontSize:10 }}>{t.priority}</span></td>
                    <td><span className={`badge ${t.status==='closed'?'badge-green':t.status==='in-progress'?'badge-blue':'badge-amber'}`} style={{ fontSize:10 }}>{t.status==='closed'?'Closed':t.status}</span></td>
                    <td style={{ fontSize:12, color:overdue?'var(--red)':'var(--text2)' }}>{t.due_date}{overdue&&' ⚠'}</td>
                    <td style={{ fontSize:12, color:'var(--text3)' }}>{t.age_days!=null?t.age_days+'d':'—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {tasks.length>100 && <div style={{ padding:'10px 0', fontSize:12, color:'var(--text3)', textAlign:'center' }}>Showing first 100 of {tasks.length}</div>}
        </div>
      )}

      {/* SPEED */}
      {tab==='speed' && (
        <div className="grid-2">
          <div className="card">
            <div className="card-title">⚡ Completion Speed Buckets</div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={speedData} margin={{ left:-20 }}>
                <XAxis dataKey="name" tick={{ fontSize:11, fill:'var(--text2)' }} />
                <YAxis tick={{ fontSize:11, fill:'var(--text2)' }} allowDecimals={false} />
                <Tooltip content={<CT/>} />
                <Bar dataKey="value" name="Tasks" radius={[4,4,0,0]}>
                  {speedData.map((e,i)=><Cell key={i} fill={e.fill}/>)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div style={{ display:'flex', gap:16, marginTop:10, justifyContent:'center' }}>
              {speedData.map(d=>(
                <div key={d.name} style={{ textAlign:'center' }}>
                  <div style={{ fontSize:22, fontWeight:700, color:d.fill }}>{d.value}</div>
                  <div style={{ fontSize:11, color:'var(--text2)' }}>{d.name}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="card-title">🏆 Top Performers — Completion Rate</div>
            {employees.slice(0,7).map((e,i)=>{
              const rate=e.completion_rate||0;
              const rc=rate>=80?'var(--green)':rate>=50?'var(--amber)':'var(--red)';
              return (
                <div key={e.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 0', borderBottom:'1px solid var(--border)', cursor:'pointer' }} onClick={()=>{setSelectedEmp(e);openEmployeeDrilldown(e);setTab('drilldown');}}>
                  <span style={{ width:22, textAlign:'center', fontSize:15, flexShrink:0 }}>{i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</span>
                  <Avatar name={e.name} color={e.color} size="xs" />
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:13, fontWeight:500 }}>{e.name}</div>
                    <ProgressBar value={rate} color={rc} height={3} />
                  </div>
                  <span style={{ fontSize:13, color:rc, fontWeight:700, width:40, textAlign:'right' }}>{rate}%</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function isOverdue(dateStr) {
  return dateStr && dateStr < TODAY;
}
