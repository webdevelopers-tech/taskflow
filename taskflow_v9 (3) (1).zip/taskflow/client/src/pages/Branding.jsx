import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { SectionHeader, FormGroup, Spinner } from '../components/UI';
import { getBranding, updateBranding } from '../utils/api';
import toast from 'react-hot-toast';

const PRESETS = [
  { name: '🟣 Indigo (Default)', primary: '#6366f1', secondary: '#8b5cf6', accent: '#06b6d4', sidebar: '#0f172a', header: '#1e293b' },
  { name: '🔵 Blue Ocean',        primary: '#0ea5e9', secondary: '#3b82f6', accent: '#6366f1', sidebar: '#0c1a2e', header: '#0f2748' },
  { name: '🟢 Emerald',           primary: '#10b981', secondary: '#14b8a6', accent: '#6366f1', sidebar: '#0a1f1a', header: '#0d2b24' },
  { name: '🔴 Rose',              primary: '#f43f5e', secondary: '#ec4899', accent: '#f59e0b', sidebar: '#1f0a10', header: '#2d0d17' },
  { name: '🟠 Amber',             primary: '#f59e0b', secondary: '#f97316', accent: '#10b981', sidebar: '#1c1207', header: '#2a1b08' },
  { name: '⬛ Midnight',          primary: '#94a3b8', secondary: '#64748b', accent: '#6366f1', sidebar: '#020617', header: '#0f172a' },
];

const FONTS = ['Inter', 'Roboto', 'Open Sans', 'Lato', 'Poppins', 'Nunito', 'Montserrat'];

export default function Branding() {
  const { user, applyBrand } = useAuth();
  const [form, setForm]     = useState({});
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [preview, setPreview] = useState(false);

  if (!user.is_admin) return <div style={{ padding: 40, color: 'var(--red)' }}>⛔ Admin access required.</div>;

  useEffect(() => {
    getBranding().then(b => { setForm(b || {}); }).finally(() => setLoading(false));
  }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const applyPreset = (preset) => {
    setForm(f => ({ ...f, primary_color: preset.primary, secondary_color: preset.secondary, accent_color: preset.accent, sidebar_color: preset.sidebar, header_color: preset.header }));
    toast.success(`Applied ${preset.name} preset`);
  };

  const save = async () => {
    setSaving(true);
    try {
      const updated = await updateBranding(form);
      applyBrand(updated);
      toast.success('✅ Branding saved & applied!');
    } catch { toast.error('Failed to save branding'); }
    setSaving(false);
  };

  const previewBrand = () => {
    applyBrand(form);
    setPreview(true);
    setTimeout(() => setPreview(false), 2000);
    toast.success('👁 Preview applied!');
  };

  if (loading) return <div style={{ padding: 40 }}>Loading…</div>;

  return (
    <div className="fade-up">
      <SectionHeader
        title="🎨 Branding"
        sub="Customize your company's look and feel"
        action={
          <div className="flex gap-8">
            <button className="btn btn-ghost" onClick={previewBrand}>👁 Preview</button>
            <button className="btn btn-accent" onClick={save} disabled={saving}>{saving ? <><Spinner size={13} /> Saving…</> : '💾 Save Branding'}</button>
          </div>
        }
      />

      <div className="grid-2">
        {/* Company identity */}
        <div>
          <div className="card mb-16">
            <div className="card-title">🏢 Company Identity</div>
            <FormGroup label="Company Name" hint="Shown in header, login page, and exports">
              <input className="input" value={form.company_name || ''} onChange={e => set('company_name', e.target.value)} placeholder="Acme Corporation" />
            </FormGroup>
            <FormGroup label="Tagline" hint="Shown on login page">
              <input className="input" value={form.tagline || ''} onChange={e => set('tagline', e.target.value)} placeholder="Office Collaboration Platform" />
            </FormGroup>
            <FormGroup label="Footer Text">
              <input className="input" value={form.footer_text || ''} onChange={e => set('footer_text', e.target.value)} placeholder="© 2025 Acme. All rights reserved." />
            </FormGroup>
            <FormGroup label="Logo URL" hint="Hosted image URL (PNG/SVG recommended, ~120×40px)">
              <input className="input" value={form.logo_url || ''} onChange={e => set('logo_url', e.target.value)} placeholder="https://yourcompany.com/logo.png" />
            </FormGroup>
            {form.logo_url && (
              <div style={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: 14, marginTop: -8, marginBottom: 12 }}>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 8 }}>Logo preview:</div>
                <img src={form.logo_url} style={{ maxHeight: 40, objectFit: 'contain' }} alt="logo preview" onError={e => e.target.style.display = 'none'} />
              </div>
            )}
            <FormGroup label="Login Logo Text" hint="Fallback text when no logo URL (2 characters)">
              <input className="input" value={form.login_logo_text || ''} maxLength={3} onChange={e => set('login_logo_text', e.target.value)} placeholder="TF" style={{ width: 80 }} />
            </FormGroup>
            <FormGroup label="Font Family">
              <select className="input" value={form.font_family || 'Inter'} onChange={e => set('font_family', e.target.value)}>
                {FONTS.map(f => <option key={f}>{f}</option>)}
              </select>
            </FormGroup>
          </div>

          {/* Color presets */}
          <div className="card">
            <div className="card-title">⚡ Quick Presets</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {PRESETS.map(p => (
                <button key={p.name} onClick={() => applyPreset(p)}
                  style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', cursor: 'pointer', transition: 'all .15s', textAlign: 'left' }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.background = 'var(--accent-bg)'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--bg3)'; }}>
                  <div style={{ display: 'flex', gap: 4 }}>
                    {[p.primary, p.secondary, p.accent, p.sidebar].map((c, i) => (
                      <div key={i} style={{ width: 14, height: 14, borderRadius: '50%', background: c, flexShrink: 0 }} />
                    ))}
                  </div>
                  <span style={{ fontSize: 13 }}>{p.name}</span>
                  <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text3)' }}>Apply →</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Colors */}
        <div>
          <div className="card mb-16">
            <div className="card-title">🎨 Color Palette</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              {[
                { k: 'primary_color',   l: 'Primary Color',   hint: 'Buttons, active links' },
                { k: 'secondary_color', l: 'Secondary Color',  hint: 'Hover states, gradients' },
                { k: 'accent_color',    l: 'Accent Color',     hint: 'Highlights, badges' },
                { k: 'sidebar_color',   l: 'Sidebar BG',       hint: 'Left navigation' },
                { k: 'header_color',    l: 'Header BG',        hint: 'Top bar background' },
                { k: 'login_bg_color',  l: 'Login BG',         hint: 'Login page background' },
              ].map(({ k, l, hint }) => (
                <div key={k}>
                  <div className="label">{l}</div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <input type="color" value={form[k] || '#6366f1'} onChange={e => set(k, e.target.value)}
                      style={{ width: 44, height: 36, borderRadius: 'var(--radius-sm)', cursor: 'pointer', border: '1px solid var(--border)', padding: 2, background: 'var(--bg3)' }} />
                    <input className="input" value={form[k] || ''} onChange={e => set(k, e.target.value)} placeholder="#6366f1"
                      style={{ fontFamily: 'var(--mono)', fontSize: 12 }} />
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 3 }}>{hint}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Live color preview */}
          <div className="card">
            <div className="card-title">👁 Live Preview</div>
            <div style={{ borderRadius: 'var(--radius)', overflow: 'hidden', border: '1px solid var(--border)' }}>
              {/* Mock header */}
              <div style={{ background: form.header_color || 'var(--bg2)', padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 24, height: 24, borderRadius: 6, background: form.primary_color || 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 800, color: '#fff' }}>{form.login_logo_text?.slice(0, 2) || 'TF'}</div>
                <span style={{ fontSize: 13, fontWeight: 700 }}>{form.company_name || 'TaskFlow'}</span>
                <div style={{ marginLeft: 'auto', width: 24, height: 24, borderRadius: '50%', background: form.primary_color || 'var(--accent)' }} />
              </div>
              {/* Mock sidebar + content */}
              <div style={{ display: 'flex', height: 160 }}>
                <div style={{ width: 120, background: form.sidebar_color || 'var(--bg2)', padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {['Dashboard', 'Tasks', 'Team', 'Reminders'].map((l, i) => (
                    <div key={l} style={{ fontSize: 11, padding: '5px 8px', borderRadius: 5, background: i === 0 ? `${form.primary_color || '#6366f1'}22` : 'transparent', color: i === 0 ? form.primary_color || 'var(--accent)' : '#94a3b8' }}>{l}</div>
                  ))}
                </div>
                <div style={{ flex: 1, background: 'var(--bg)', padding: 12 }}>
                  <div style={{ height: 8, background: form.primary_color || 'var(--accent)', borderRadius: 4, marginBottom: 8, width: '60%' }} />
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                    {[1, 2, 3, 4].map(n => <div key={n} style={{ height: 28, background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 6 }} />)}
                  </div>
                  <div style={{ marginTop: 8, height: 24, background: form.accent_color || 'var(--teal)', borderRadius: 5, width: 80, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, color: '#fff', fontWeight: 600 }}>New Task</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
