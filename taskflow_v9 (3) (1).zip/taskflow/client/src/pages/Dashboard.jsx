import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth, useWS } from '../context/AuthContext';
import { Avatar, ProgressBar, PageLoader, SectionHeader, TZDate } from '../components/UI';
import { getTasks, getTaskStats, clockIn, clockOut, clockPause, clockResume, clockBreak, getTodayClock, getActivity, getUsers, TIMEZONES } from '../utils/api';
import toast from 'react-hot-toast';

const TZ_LIST = [
  { key:'IST', label:'India (IST)', city:'Mumbai' },
  { key:'CST', label:'Chicago (CST)', city:'Chicago' },
];

const QUOTES = [
  "Great things are not done by impulse, but by a series of small things brought together.",
  "The secret of getting ahead is getting started.",
  "Focus on being productive instead of busy.",
  "Success is the sum of small efforts, repeated day in and day out.",
  "Work hard in silence, let your success be the noise.",
  "The only way to do great work is to love what you do.",
  "Every day is a new opportunity to improve yourself.",
  "Don't watch the clock; do what it does — keep going.",
  "Your time is limited, don't waste it living someone else's life.",
  "Quality means doing it right when no one is looking.",
  "Small daily improvements are the key to staggering long-term results.",
  "Productivity is never an accident. It is always the result of commitment.",
];

const STATUS_CONFIG = {
  working:    { label:'Working',    color:'var(--green)',  dot:'var(--green)',  icon:'⚡' },
  'on-break': { label:'On Break',   color:'var(--amber)',  dot:'var(--amber)',  icon:'☕' },
  paused:     { label:'Paused',     color:'var(--teal)',   dot:'var(--teal)',   icon:'⏸' },
  'clocked-out':{ label:'Offline',  color:'var(--text3)',  dot:'var(--bg4)',    icon:'⭕' },
  offline:    { label:'Offline',    color:'var(--text3)',  dot:'var(--bg4)',    icon:'⭕' },
};

export default function Dashboard() {
  const { user } = useAuth();
  const { subscribe } = useWS();
  const [stats, setStats]           = useState(null);
  const [myTasks, setMyTasks]       = useState([]);
  const [activity, setActivity]     = useState([]);
  const [users, setUsers]           = useState([]);
  const [clockState, setClockState] = useState({ session:null, totalMinutesToday:0, breaks:[], activeBreak:null });
  const [clocking, setClocking]     = useState(false);
  const [tzTimes, setTzTimes]       = useState({});
  const [elapsed, setElapsed]       = useState(0);
  const [loading, setLoading]       = useState(true);
  const [quote] = useState(QUOTES[Math.floor(Math.random()*QUOTES.length)]);
  const [teamStatus, setTeamStatus] = useState({});

  const loadAll = useCallback(async () => {
    try {
      const [s,t,a,u,c] = await Promise.all([
        getTaskStats(), getTasks({assigned_to:user.id,limit:8,status:'pending'}),
        getActivity({limit:10}), getUsers(), getTodayClock()
      ]);
      setStats(s); setMyTasks(t.tasks); setActivity(a); setUsers(u); setClockState(c);
    } catch {} finally { setLoading(false); }
  }, [user.id]);

  useEffect(() => { loadAll(); }, [loadAll]);

  useEffect(() => {
    if (!subscribe) return;
    const u1 = subscribe('task:updated', ()=>{ getTaskStats().then(setStats); });
    const u2 = subscribe('task:created', ()=>{ getTaskStats().then(setStats); });
    const u3 = subscribe('user:status',  (msg)=>{
      setTeamStatus(prev=>({...prev, [msg.userId]: msg.status}));
    });
    return ()=>{ u1();u2();u3(); };
  }, [subscribe, user.id]);

  // TZ clocks
  useEffect(() => {
    const tick = () => {
      const times = {};
      TZ_LIST.forEach(({key}) => {
        times[key] = new Date().toLocaleTimeString('en-US',{timeZone:TIMEZONES[key]?.tz,hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});
      });
      setTzTimes(times);
    };
    tick(); const i=setInterval(tick,1000); return ()=>clearInterval(i);
  }, []);

  // Elapsed timer
  useEffect(() => {
    const s = clockState.session;
    if (!s || s.clock_out || s.status==='paused' || s.status==='on-break') return;
    const ci = new Date(s.clock_in.replace(' ','T')+'Z');
    const update = () => setElapsed(Date.now()-ci.getTime()-((s.paused_minutes||0)*60000));
    update(); const i=setInterval(update,1000); return ()=>clearInterval(i);
  }, [clockState.session]);

  const handleClock = async (action) => {
    setClocking(true);
    try {
      if (action==='in')     { await clockIn();     toast.success('🟢 Clocked in!'); }
      if (action==='out')    { await clockOut();    toast.success('🔴 Clocked out!'); }
      if (action==='pause')  { await clockPause();  toast.success('⏸ Paused'); }
      if (action==='resume') { await clockResume(); toast.success('▶ Resumed'); }
      if (action==='break')  { await clockBreak('break');  toast.success('☕ On break'); }
      if (action==='lunch')  { await clockBreak('lunch');  toast.success('🍽 Lunch break'); }
      setClockState(await getTodayClock());
    } catch(e) { toast.error(e.response?.data?.error||'Error'); }
    setClocking(false);
  };

  const fmtMs = (ms) => {
    const h=Math.floor(ms/3600000),m=Math.floor((ms%3600000)/60000),s=Math.floor((ms%60000)/1000);
    return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  };
  const fmtMins = (m) => `${Math.floor(m/60)}h ${m%60}m`;

  const session     = clockState.session;
  const isClockedIn = session && !session.clock_out;
  const isPaused    = session?.status === 'paused';
  const isOnBreak   = session?.status === 'on-break';
  const isWorking   = isClockedIn && !isPaused && !isOnBreak;
  const totalMins   = clockState.totalMinutesToday||0;
  const myWorkStatus= isPaused?'paused':isOnBreak?'on-break':isWorking?'working':'offline';
  const greet       = ()=>{ const h=new Date().getHours(); return h<12?'Good morning':h<17?'Good afternoon':'Good evening'; };

  if (loading) return <PageLoader />;

  return (
    <div className="fade-up">
      <SectionHeader
        title={`${greet()}, ${user.name.split(' ')[0]}! 👋`}
        sub={new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})+` · ${TIMEZONES[user.timezone]?.label}`}
      />

      {/* TZ Clocks */}
      <div style={{ display:'flex', gap:12, marginBottom:20 }}>
        {TZ_LIST.map(({key,label,city})=>(
          <div key={key} style={{ background:'var(--bg2)', border:`1px solid ${user.timezone===key?'var(--accent)':'var(--border)'}`, borderRadius:'var(--radius)', padding:'14px 20px', flex:1 }}>
            <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.7px', marginBottom:4 }}>{city}</div>
            <div style={{ fontSize:22, fontWeight:700, fontFamily:'var(--mono)', letterSpacing:'-1px', marginBottom:2 }}>{tzTimes[key]||'—'}</div>
            <div style={{ fontSize:11, color:user.timezone===key?'var(--accent2)':'var(--text2)' }}>{label} {user.timezone===key&&'← Your TZ'}</div>
          </div>
        ))}
      </div>

      {/* Stats */}
      <div className="stats-grid mb-20">
        {[
          { label:'My Pending',   value:stats?.myPending??'—',   color:'var(--accent)' },
          { label:'Overdue',      value:stats?.overdue??'—',     color:'var(--red)' },
          { label:'Closed Today', value:stats?.closedToday??'—', color:'var(--green)' },
          { label:'Total Tasks',  value:stats?.total??'—',       color:'var(--text)' },
        ].map(s=>(
          <div key={s.label} className="stat-card">
            <div className="stat-value" style={{ color:s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2 mb-20">
        {/* My pending tasks */}
        <div className="card">
          <div className="card-title">⏳ My Pending Tasks</div>
          {myTasks.length===0
            ? <div style={{textAlign:'center',padding:'20px 0',color:'var(--text3)',fontSize:13}}>🎉 All caught up!</div>
            : <div style={{display:'flex',flexDirection:'column',gap:8}}>
                {myTasks.slice(0,5).map(t=>(
                  <div key={t.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 12px', background:'var(--bg3)', borderRadius:'var(--radius-sm)', borderLeft:`3px solid ${t.priority==='high'?'var(--red)':t.priority==='medium'?'var(--amber)':'var(--green)'}` }}>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{t.title}</div>
                      <div style={{ fontSize:11, color:'var(--text2)', marginTop:2 }}><TZDate value={t.due_date} /> · {t.category}</div>
                    </div>
                    <span style={{ fontSize:10, padding:'2px 7px', borderRadius:4, background:t.priority==='high'?'var(--red-bg)':t.priority==='medium'?'var(--amber-bg)':'var(--green-bg)', color:t.priority==='high'?'var(--red)':t.priority==='medium'?'var(--amber)':'var(--green)', fontWeight:600 }}>{t.priority}</span>
                  </div>
                ))}
              </div>
          }
        </div>

        {/* Live activity — newest first (already sorted DESC from API) */}
        <div className="card">
          <div className="card-title">📡 Live Activity</div>
          <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
            {activity.length===0 && <div style={{ color:'var(--text3)', fontSize:13, padding:'16px 0', textAlign:'center' }}>No activity yet</div>}
            {activity.map((a,i)=>(
              <div key={a.id||i} style={{ display:'flex', alignItems:'flex-start', gap:10, padding:'8px 0', borderBottom:i<activity.length-1?'1px solid var(--border)':'none' }}>
                <div style={{ width:7, height:7, borderRadius:'50%', background:a.user_color||'var(--accent)', marginTop:5, flexShrink:0 }} />
                <div style={{ flex:1, minWidth:0 }}>
                  <span style={{ fontSize:13 }}><strong>{a.user_name}</strong> {a.action}{a.meta?`: ${a.meta}`:''}</span>
                  <div style={{ fontSize:11, color:'var(--text3)' }}>{a.created_at}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid-2">
        {/* Work Session — full controls */}
        <div className="card">
          <div className="card-title">🕐 Work Session</div>

          {/* Status + timer */}
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
            <div>
              <div style={{ fontSize:34, fontWeight:700, letterSpacing:'-2px', fontFamily:'var(--mono)', color: isWorking?'var(--green)':isPaused?'var(--amber)':isOnBreak?'var(--amber)':'var(--text)' }}>
                {isClockedIn ? fmtMs(elapsed) : fmtMins(totalMins)}
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginTop:4 }}>
                <div style={{ width:8, height:8, borderRadius:'50%', background:STATUS_CONFIG[myWorkStatus]?.dot||'var(--bg4)', boxShadow:isWorking?'0 0 6px var(--green)':'' }} />
                <span style={{ fontSize:12, color:STATUS_CONFIG[myWorkStatus]?.color||'var(--text2)', fontWeight:500 }}>
                  {STATUS_CONFIG[myWorkStatus]?.icon} {STATUS_CONFIG[myWorkStatus]?.label}
                </span>
                {isOnBreak && clockState.activeBreak && (
                  <span style={{ fontSize:11, color:'var(--amber)' }}>({clockState.activeBreak.break_type})</span>
                )}
              </div>
            </div>
            {/* Primary action button */}
            {!isClockedIn && (
              <button className="btn btn-success" onClick={()=>handleClock('in')} disabled={clocking} style={{ padding:'9px 18px' }}>🟢 Clock In</button>
            )}
            {isWorking && (
              <button className="btn btn-danger" onClick={()=>handleClock('out')} disabled={clocking} style={{ padding:'9px 18px' }}>🔴 Clock Out</button>
            )}
            {(isPaused||isOnBreak) && (
              <button className="btn btn-success" onClick={()=>handleClock('resume')} disabled={clocking} style={{ padding:'9px 18px' }}>▶ Resume</button>
            )}
          </div>

          {/* Secondary actions */}
          {isWorking && (
            <div style={{ display:'flex', gap:8, marginBottom:14, flexWrap:'wrap' }}>
              <button className="btn btn-ghost btn-sm" onClick={()=>handleClock('pause')} disabled={clocking}>⏸ Pause</button>
              <button className="btn btn-ghost btn-sm" onClick={()=>handleClock('break')} disabled={clocking}>☕ Break</button>
              <button className="btn btn-ghost btn-sm" onClick={()=>handleClock('lunch')} disabled={clocking}>🍽 Lunch</button>
            </div>
          )}

          {/* Progress bar */}
          <div style={{ fontSize:12, color:'var(--text2)', marginBottom:6, display:'flex', justifyContent:'space-between' }}>
            <span>8h workday</span>
            <span>{fmtMins(totalMins)} / 8h</span>
          </div>
          <ProgressBar value={Math.min(100,(totalMins/480)*100)} color={isWorking?'var(--green)':isPaused?'var(--amber)':'var(--accent)'} />

          {/* Motivational quote when not clocked in */}
          {!isClockedIn && (
            <div style={{ marginTop:16, padding:'12px 14px', background:'var(--accent-bg)', borderRadius:'var(--radius-sm)', border:'1px solid var(--accent-border)' }}>
              <div style={{ fontSize:11, color:'var(--accent2)', fontWeight:600, marginBottom:4, textTransform:'uppercase', letterSpacing:'.5px' }}>💡 Thought of the day</div>
              <div style={{ fontSize:12, color:'var(--text2)', lineHeight:1.6, fontStyle:'italic' }}>"{quote}"</div>
            </div>
          )}
        </div>

        {/* Team Status */}
        <div className="card">
          <div className="card-title">👥 Team Status</div>
          <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
            {users.map(u=>{
              // Live status from WS or clock session
              const liveStatus = teamStatus[u.id];
              const us   = stats?.byUser?.find(s=>s.id===u.id)||{};
              const rate = us.total ? Math.round((us.closed||0)/us.total*100) : 0;
              // Determine display status
              const displayStatus = u.id===user.id ? myWorkStatus : (liveStatus||'offline');
              const sc = STATUS_CONFIG[displayStatus]||STATUS_CONFIG.offline;
              return (
                <div key={u.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 0', borderBottom:'1px solid var(--border)' }}>
                  <div style={{ position:'relative', flexShrink:0 }}>
                    <Avatar name={u.name} color={u.color} size="sm" />
                    <div style={{ position:'absolute', bottom:-1, right:-1, width:10, height:10, borderRadius:'50%', background:sc.dot, border:'2px solid var(--bg2)', boxShadow:displayStatus==='working'?'0 0 5px var(--green)':'' }} />
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{u.name}</div>
                    <div style={{ fontSize:11, color:'var(--text2)' }}>{u.role} · {u.timezone}</div>
                  </div>
                  <div style={{ textAlign:'right', flexShrink:0 }}>
                    <div style={{ fontSize:11, color:sc.color, fontWeight:600 }}>{sc.icon} {sc.label}</div>
                    <div style={{ fontSize:11, color:'var(--text3)', marginTop:1 }}>{rate}% · {us.closed||0}/{us.total||0}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
