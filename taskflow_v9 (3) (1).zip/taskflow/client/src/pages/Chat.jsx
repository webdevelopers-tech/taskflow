import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth, useWS } from '../context/AuthContext';
import { Avatar, PageLoader, Spinner } from '../components/UI';
import { getChatMessages, sendChatMessage, deleteChatMsg, getUsers, uploadChatAttachment, chatAttachmentDownloadUrl, chatAttachmentPreviewUrl } from '../utils/api';
import toast from 'react-hot-toast';

function getFileIcon(mime) {
  if (mime?.startsWith('image/'))   return '🖼';
  if (mime?.includes('pdf'))        return '📄';
  if (mime?.includes('word'))       return '📝';
  if (mime?.includes('excel')||mime?.includes('spreadsheet')) return '📊';
  if (mime?.includes('zip'))        return '🗜';
  return '📎';
}
function formatSize(b) {
  if (b<1024) return b+'B';
  if (b<1048576) return (b/1024).toFixed(1)+'KB';
  return (b/1048576).toFixed(1)+'MB';
}

export default function Chat() {
  const { user } = useAuth();
  const { subscribe, connected } = useWS();
  const [users, setUsers]           = useState([]);
  const [activeRoom, setActiveRoom] = useState('general');
  const [messages, setMessages]     = useState([]);
  const [input, setInput]           = useState('');
  const [sending, setSending]       = useState(false);
  const [uploading, setUploading]   = useState(false);
  const [uploadPct, setUploadPct]   = useState(0);
  const [loading, setLoading]       = useState(true);
  const [onlineUsers, setOnlineUsers] = useState(new Set());
  const [previewUrl, setPreviewUrl] = useState(null);
  const bottomRef = useRef(null);
  const inputRef  = useRef(null);
  const fileRef   = useRef(null);

  const isDM = activeRoom !== 'general';
  const dmUser = isDM ? users.find(u=>u.id===activeRoom) : null;

  const loadMessages = useCallback(async () => {
    setLoading(true);
    try {
      const p = isDM ? { recipient_id: activeRoom, limit:100 } : { room:'general', limit:100 };
      setMessages(await getChatMessages(p));
    } catch {} finally { setLoading(false); }
  }, [activeRoom, isDM]);

  useEffect(() => { getUsers().then(setUsers); }, []);
  useEffect(() => { loadMessages(); }, [loadMessages]);

  useEffect(() => {
    if (!subscribe) return;
    const unsub = subscribe('chat:message', (msg) => {
      const isForMe = (
        (msg.room === activeRoom && !msg.dm) ||
        (msg.dm && (msg.message?.sender_id===activeRoom || msg.message?.sender_id===user.id) && isDM)
      );
      if (isForMe) setMessages(prev => [...prev, msg.message]);
    });
    const uStatus = subscribe('user:status', (msg) => {
      setOnlineUsers(prev => {
        const next = new Set(prev);
        if (msg.status==='working'||msg.status==='on-break'||msg.status==='paused') next.add(msg.userId);
        else next.delete(msg.userId);
        return next;
      });
    });
    const uDeleted = subscribe('chat:deleted', (msg) => {
      setMessages(prev=>prev.filter(m=>m.id!==msg.messageId));
    });
    return ()=>{unsub();uStatus();uDeleted();};
  }, [subscribe, activeRoom, isDM, user.id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior:'smooth' });
  }, [messages]);

  const send = async (e) => {
    e?.preventDefault();
    if (!input.trim() || sending) return;
    setSending(true);
    try {
      const payload = isDM
        ? { content:input, recipient_id:activeRoom }
        : { content:input, room:'general' };
      await sendChatMessage(payload);
      setInput('');
      inputRef.current?.focus();
    } catch { toast.error('Failed to send'); }
    setSending(false);
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this message?')) return;
    await deleteChatMsg(id);
    setMessages(prev=>prev.filter(m=>m.id!==id));
  };

  const formatTime = (ts) => {
    if (!ts) return '';
    const d = new Date(ts.replace(' ','T')+'Z');
    const now = new Date();
    const isToday = d.toDateString()===now.toDateString();
    return isToday ? d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:true}) : d.toLocaleDateString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:true});
  };

  // Group consecutive messages from same sender
  const grouped = messages.reduce((acc, msg, i) => {
    const prev = messages[i-1];
    const sameUser = prev?.sender_id === msg.sender_id && (new Date(msg.created_at) - new Date(prev.created_at)) < 5*60000;
    acc.push({ ...msg, grouped: sameUser });
    return acc;
  }, []);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 25*1024*1024) return toast.error('Max file size is 25MB');
    setUploading(true); setUploadPct(0);
    try {
      const msg = await uploadChatAttachment(isDM?null:'general', isDM?activeRoom:null, file, setUploadPct);
      setMessages(prev=>[...prev, msg]);
    } catch(e) { toast.error(e.response?.data?.error||'Upload failed'); }
    setUploading(false); setUploadPct(0);
    e.target.value='';
  };

  return (
    <div style={{ display:'flex', height:'100%', gap:0, margin:-24, overflow:'hidden' }}>
      {/* Sidebar */}
      <div style={{ width:220, background:'var(--bg2)', borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', flexShrink:0 }}>
        <div style={{ padding:'16px 16px 10px', borderBottom:'1px solid var(--border)' }}>
          <div style={{ fontWeight:700, fontSize:15, letterSpacing:'-.3px' }}>💬 Team Chat</div>
          <div style={{ fontSize:11, color:'var(--text3)', marginTop:2 }}>
            {connected ? <span style={{color:'var(--green)'}}>● Live</span> : '○ Connecting…'}
          </div>
        </div>

        {/* Group chat */}
        <div style={{ padding:'8px 8px 4px' }}>
          <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.7px', padding:'4px 8px', fontWeight:600 }}>Channels</div>
          <div onClick={()=>setActiveRoom('general')}
            style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 10px', borderRadius:'var(--radius-sm)', cursor:'pointer', background:activeRoom==='general'?'var(--accent-bg)':'transparent', color:activeRoom==='general'?'var(--accent2)':'var(--text2)', transition:'all .13s' }}
            onMouseEnter={e=>{ if(activeRoom!=='general'){e.currentTarget.style.background='var(--bg3)';} }}
            onMouseLeave={e=>{ if(activeRoom!=='general'){e.currentTarget.style.background='transparent';} }}>
            <span style={{ fontSize:16 }}>👥</span>
            <span style={{ fontSize:13, fontWeight:500 }}>General</span>
          </div>
        </div>

        {/* DM list */}
        <div style={{ padding:'4px 8px 4px', flex:1, overflowY:'auto' }}>
          <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.7px', padding:'4px 8px', fontWeight:600 }}>Direct Messages</div>
          {users.filter(u=>u.id!==user.id).map(u=>{
            const isOnline = onlineUsers.has(u.id);
            const active   = activeRoom===u.id;
            return (
              <div key={u.id} onClick={()=>setActiveRoom(u.id)}
                style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 10px', borderRadius:'var(--radius-sm)', cursor:'pointer', background:active?'var(--accent-bg)':'transparent', color:active?'var(--accent2)':'var(--text2)', transition:'all .13s' }}
                onMouseEnter={e=>{ if(!active) e.currentTarget.style.background='var(--bg3)'; }}
                onMouseLeave={e=>{ if(!active) e.currentTarget.style.background='transparent'; }}>
                <div style={{ position:'relative', flexShrink:0 }}>
                  <Avatar name={u.name} color={u.color} size="xs" />
                  <div style={{ position:'absolute', bottom:-1, right:-1, width:7, height:7, borderRadius:'50%', background:isOnline?'var(--green)':'var(--bg4)', border:'1.5px solid var(--bg2)' }} />
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:12, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{u.name.split(' ')[0]}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Chat area */}
      <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
        {/* Header */}
        <div style={{ padding:'14px 20px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:12, flexShrink:0 }}>
          {isDM ? (
            <>
              <Avatar name={dmUser?.name||'?'} color={dmUser?.color} size="sm" />
              <div>
                <div style={{ fontWeight:600, fontSize:14 }}>{dmUser?.name}</div>
                <div style={{ fontSize:11, color:'var(--text2)' }}>{dmUser?.role} · {onlineUsers.has(activeRoom)?<span style={{color:'var(--green)'}}>Online</span>:'Offline'}</div>
              </div>
            </>
          ) : (
            <>
              <div style={{ width:34, height:34, borderRadius:'var(--radius-sm)', background:'var(--accent-bg)', border:'1px solid var(--accent-border)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16 }}>👥</div>
              <div>
                <div style={{ fontWeight:600, fontSize:14 }}># General</div>
                <div style={{ fontSize:11, color:'var(--text2)' }}>{users.length} members · Team group chat</div>
              </div>
            </>
          )}
        </div>

        {/* Messages */}
        <div style={{ flex:1, overflowY:'auto', padding:'12px 20px', display:'flex', flexDirection:'column', gap:2 }}>
          {loading ? (
            <div style={{ textAlign:'center', padding:40, color:'var(--text3)' }}>Loading…</div>
          ) : messages.length===0 ? (
            <div style={{ textAlign:'center', padding:'40px 20px' }}>
              <div style={{ fontSize:32, marginBottom:12 }}>{isDM ? '💬' : '👥'}</div>
              <div style={{ fontWeight:600, color:'var(--text2)', marginBottom:4 }}>{isDM?`Start a conversation with ${dmUser?.name}`:'Welcome to General chat!'}</div>
              <div style={{ fontSize:12, color:'var(--text3)' }}>Messages saved 7 days · Files supported</div>
            </div>
          ) : grouped.map(msg => {
            const isMe = msg.sender_id===user.id;
            const att  = msg.attachment;
            const isImg = att?.mime_type?.startsWith('image/');
            return (
              <div key={msg.id} style={{ display:'flex', alignItems:'flex-end', gap:10, marginTop:msg.grouped?1:10, flexDirection:isMe?'row-reverse':'row' }}>
                {!msg.grouped && !isMe && <Avatar name={msg.sender_name||'?'} color={msg.sender_color} size="xs" style={{ flexShrink:0, marginBottom:2 }} />}
                {msg.grouped && !isMe && <div style={{ width:20, flexShrink:0 }} />}
                <div style={{ maxWidth:'70%' }}>
                  {!msg.grouped && (
                    <div style={{ fontSize:11, color:'var(--text3)', marginBottom:3, textAlign:isMe?'right':'left' }}>
                      {!isMe && <span style={{ fontWeight:600, color:'var(--text2)', marginRight:6 }}>{msg.sender_name}</span>}
                      {formatTime(msg.created_at)}
                    </div>
                  )}
                  <div style={{ display:'flex', alignItems:'flex-end', gap:6, flexDirection:isMe?'row-reverse':'row' }}>
                    {/* Attachment bubble */}
                    {att ? (
                      <div style={{ background:isMe?'var(--accent)':'var(--bg3)', borderRadius:isMe?'16px 4px 16px 16px':'4px 16px 16px 16px', border:isMe?'none':'1px solid var(--border)', overflow:'hidden', maxWidth:280 }}>
                        {isImg ? (
                          <img src={chatAttachmentPreviewUrl(att.id)} alt={att.original_name}
                            style={{ maxWidth:260, maxHeight:200, display:'block', cursor:'pointer', borderRadius:6 }}
                            onClick={()=>setPreviewUrl({ url:chatAttachmentPreviewUrl(att.id), name:att.original_name, isImg:true })}
                            onError={e=>e.target.style.display='none'} />
                        ) : (
                          <div style={{ padding:'10px 14px', display:'flex', alignItems:'center', gap:10 }}>
                            <span style={{ fontSize:22 }}>{getFileIcon(att.mime_type)}</span>
                            <div style={{ flex:1, minWidth:0 }}>
                              <div style={{ fontSize:12, fontWeight:600, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', color:isMe?'#fff':'var(--text)' }}>{att.original_name}</div>
                              <div style={{ fontSize:10, color:isMe?'rgba(255,255,255,.7)':'var(--text3)', marginTop:1 }}>{formatSize(att.file_size)}</div>
                            </div>
                          </div>
                        )}
                        <div style={{ padding:'6px 12px', borderTop:`1px solid ${isMe?'rgba(255,255,255,.2)':'var(--border)'}`, display:'flex', gap:6 }}>
                          <a href={chatAttachmentDownloadUrl(att.id)} download={att.original_name} style={{ fontSize:11, color:isMe?'rgba(255,255,255,.9)':'var(--accent2)', textDecoration:'none' }}>📥 Download</a>
                          {!isImg && att.mime_type?.includes('pdf') && (
                            <span style={{ fontSize:11, color:isMe?'rgba(255,255,255,.7)':'var(--text3)', cursor:'pointer' }} onClick={()=>setPreviewUrl({url:chatAttachmentPreviewUrl(att.id),name:att.original_name})}>👁 Preview</span>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div style={{ padding:'9px 13px', borderRadius:isMe?'16px 4px 16px 16px':'4px 16px 16px 16px', background:isMe?'var(--accent)':'var(--bg3)', color:isMe?'#fff':'var(--text)', fontSize:13, lineHeight:1.5, wordBreak:'break-word', border:isMe?'none':'1px solid var(--border)' }}>
                        {msg.content}
                      </div>
                    )}
                    {(msg.sender_id===user.id||user.is_admin) && (
                      <button onClick={()=>handleDelete(msg.id)} style={{ opacity:0, width:18, height:18, borderRadius:'50%', background:'var(--red-bg)', border:'none', cursor:'pointer', fontSize:9, color:'var(--red)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}
                        onMouseEnter={e=>e.currentTarget.style.opacity=1}
                        onMouseLeave={e=>e.currentTarget.style.opacity=0}>✕</button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={{ padding:'12px 20px', borderTop:'1px solid var(--border)', flexShrink:0 }}>
          {uploading && (
            <div style={{ marginBottom:8 }}>
              <div style={{ background:'var(--bg3)', borderRadius:4, height:3, overflow:'hidden' }}>
                <div style={{ height:'100%', background:'var(--accent)', width:uploadPct+'%', transition:'width .2s' }} />
              </div>
              <div style={{ fontSize:10, color:'var(--text3)', marginTop:2 }}>Uploading… {uploadPct}%</div>
            </div>
          )}
          <form onSubmit={send} style={{ display:'flex', gap:8 }}>
            <input ref={fileRef} type="file" style={{ display:'none' }} onChange={handleFileUpload}
              accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.doc,.docx,.xls,.xlsx,.zip,.txt,.csv" />
            <button type="button" className="btn btn-ghost btn-icon" onClick={()=>fileRef.current?.click()} disabled={uploading} title="Attach file" style={{ flexShrink:0 }}>📎</button>
            <input ref={inputRef} className="input" value={input} onChange={e=>setInput(e.target.value)}
              placeholder={isDM?`Message ${dmUser?.name}…`:'Message #general…'}
              style={{ flex:1 }}
              onKeyDown={e=>{ if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();} }}
            />
            <button type="submit" className="btn btn-accent" disabled={!input.trim()||sending} style={{ padding:'8px 18px', flexShrink:0 }}>
              {sending?<Spinner size={13}/>:'Send ↵'}
            </button>
          </form>
          <div style={{ fontSize:10, color:'var(--text3)', marginTop:4 }}>Enter to send · 📎 attach files (25MB max) · 7-day history</div>
        </div>
      </div>

      {/* File preview overlay */}
      {previewUrl && (
        <div onClick={()=>setPreviewUrl(null)} style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.88)', zIndex:800, display:'flex', alignItems:'center', justifyContent:'center', backdropFilter:'blur(4px)' }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:'var(--bg2)', borderRadius:'var(--radius-lg)', overflow:'hidden', maxWidth:'92vw', maxHeight:'92vh', display:'flex', flexDirection:'column', boxShadow:'0 24px 80px rgba(0,0,0,.7)' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 16px', borderBottom:'1px solid var(--border)' }}>
              <span style={{ fontSize:13, fontWeight:600 }}>{previewUrl.name}</span>
              <div style={{ display:'flex', gap:8 }}>
                <a href={previewUrl.url.replace('/preview','/download')} download className="btn btn-ghost btn-sm">📥 Download</a>
                <button className="btn btn-ghost btn-sm" onClick={()=>setPreviewUrl(null)}>✕</button>
              </div>
            </div>
            <div style={{ overflow:'auto', display:'flex', alignItems:'center', justifyContent:'center', padding:8, flex:1 }}>
              {previewUrl.isImg
                ? <img src={previewUrl.url} alt={previewUrl.name} style={{ maxWidth:'86vw', maxHeight:'84vh', objectFit:'contain', borderRadius:6 }} />
                : <iframe src={previewUrl.url} style={{ width:'80vw', height:'80vh', border:'none' }} title={previewUrl.name} />
              }
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
