import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Avatar, SectionHeader, FormGroup, Toggle, Spinner, ProgressBar } from '../components/UI';
import { updateProfile, changePassword, getTasks } from '../utils/api';
import { useEffect } from 'react';
import toast from 'react-hot-toast';

const COLORS = ['#6366f1', '#14b8a6', '#ec4899', '#f59e0b', '#22c55e', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#0ea5e9'];
const TIMEZONES = [
  { value: 'IST', label: '🇮🇳 India Standard Time (IST +5:30)', city: 'Mumbai / Delhi / Bangalore' },
  { value: 'CST', label: '🇺🇸 USA Chicago Time (CST -6:00)',     city: 'Chicago / Houston / Dallas' },
];

export default function Profile() {
  const { user, setUser, refreshMe } = useAuth();
  const [tab, setTab]     = useState('profile');
  const [form, setForm]   = useState({ name: user.name, timezone: user.timezone, color: user.color, avatar_url: user.avatar_url || '' });
  const [pwd, setPwd]     = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [saving, setSaving]  = useState(false);
  const [pwdSaving, setPwdSaving] = useState(false);
  const [taskStats, setTaskStats] = useState(null);

  useEffect(() => {
    import('../utils/api').then(({ getTasks: gt }) => {
      gt({ assigned_to: user.id, limit: 200 }).then(d => {
        const today = new Date().toISOString().split('T')[0];
        const tasks = d.tasks;
        setTaskStats({
          total:   tasks.length,
          closed:  tasks.filter(t => t.status === 'closed').length,
          pending: tasks.filter(t => t.status === 'pending').length,
          inProgress: tasks.filter(t => t.status === 'in-progress').length,
          overdue: tasks.filter(t => t.status !== 'closed' && t.due_date < today).length,
        });
      });
    });
  }, [user.id]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const save = async () => {
    if (!form.name.trim()) return toast.error('Name required');
    setSaving(true);
    try {
      const updated = await updateProfile(form);
      setUser(updated);
      toast.success('✅ Profile updated!');
    } catch (e) { toast.error(e.response?.data?.error || 'Update failed'); }
    setSaving(false);
  };

  const changePwd = async () => {
    if (pwd.newPassword !== pwd.confirm) return toast.error('Passwords do not match');
    if (pwd.newPassword.length < 6) return toast.error('Password must be at least 6 characters');
    setPwdSaving(true);
    try {
      await changePassword({ currentPassword: pwd.currentPassword, newPassword: pwd.newPassword });
      toast.success('✅ Password changed!');
      setPwd({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (e) { toast.error(e.response?.data?.error || 'Password change failed'); }
    setPwdSaving(false);
  };

  const tz = TIMEZONES.find(t => t.value === (form.timezone || user.timezone));
  const completionRate = taskStats?.total ? Math.round(taskStats.closed / taskStats.total * 100) : 0;

  return (
    <div className="fade-up">
      <SectionHeader title="👤 Profile" sub="Your account settings and preferences" />

      {/* Profile hero card */}
      <div className="card mb-20" style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
        <div className="flex items-center gap-20">
          <div style={{ position: 'relative' }}>
            {form.avatar_url
              ? <img src={form.avatar_url} style={{ width: 72, height: 72, borderRadius: '50%', objectFit: 'cover', border: `3px solid ${form.color}` }} alt="avatar" onError={e => e.target.style.display = 'none'} />
              : <Avatar name={user.name} color={form.color} size="xl" />
            }
            <div style={{ position: 'absolute', bottom: 0, right: 0, width: 20, height: 20, borderRadius: '50%', background: 'var(--green)', border: '2px solid var(--bg2)' }} title="Online" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-.5px', marginBottom: 3 }}>{user.name}</div>
            <div style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 8 }}>{user.role} · {user.department}</div>
            <div className="flex items-center gap-10">
              <span className={`badge ${user.timezone === 'IST' ? 'badge-purple' : 'badge-teal'}`}>{user.timezone}</span>
              {user.is_admin && <span className="badge badge-red">⚙ Admin</span>}
              <span style={{ fontSize: 12, color: 'var(--text3)' }}>{user.email}</span>
            </div>
          </div>
          {taskStats && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 20, minWidth: 320 }}>
              {[
                { l: 'Assigned', v: taskStats.total, c: 'var(--text)' },
                { l: 'Closed', v: taskStats.closed, c: 'var(--green)' },
                { l: 'Pending', v: taskStats.pending, c: 'var(--amber)' },
                { l: 'Overdue', v: taskStats.overdue, c: taskStats.overdue > 0 ? 'var(--red)' : 'var(--text3)' },
              ].map(s => (
                <div key={s.l} style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 24, fontWeight: 700, color: s.c, letterSpacing: '-1px' }}>{s.v}</div>
                  <div style={{ fontSize: 11, color: 'var(--text3)' }}>{s.l}</div>
                </div>
              ))}
            </div>
          )}
        </div>
        {taskStats?.total > 0 && (
          <div style={{ marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--border)' }}>
            <div className="flex items-center justify-between mb-6">
              <span style={{ fontSize: 12, color: 'var(--text2)' }}>Overall Completion Rate</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: completionRate >= 80 ? 'var(--green)' : completionRate >= 50 ? 'var(--amber)' : 'var(--red)' }}>{completionRate}%</span>
            </div>
            <ProgressBar value={completionRate} color={completionRate >= 80 ? 'var(--green)' : completionRate >= 50 ? 'var(--amber)' : 'var(--red)'} height={6} />
          </div>
        )}
      </div>

      <div className="tabs">
        {[['profile', '👤 Edit Profile'], ['timezone', '🌍 Timezone'], ['password', '🔒 Password'], ['preferences', '⚙ Preferences']].map(([k, l]) => (
          <div key={k} className={`tab ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{l}</div>
        ))}
      </div>

      {tab === 'profile' && (
        <div className="card" style={{ maxWidth: 520 }}>
          <FormGroup label="Full Name" required>
            <input className="input" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Your full name" />
          </FormGroup>
          <FormGroup label="Avatar URL" hint="Hosted image URL for your profile photo">
            <input className="input" value={form.avatar_url} onChange={e => set('avatar_url', e.target.value)} placeholder="https://example.com/photo.jpg" />
          </FormGroup>
          <FormGroup label="Avatar Color" hint="Used when no photo is set">
            <div className="flex items-center gap-8" style={{ flexWrap: 'wrap' }}>
              {COLORS.map(c => (
                <div key={c} onClick={() => set('color', c)} style={{ width: 28, height: 28, borderRadius: '50%', background: c, cursor: 'pointer', border: form.color === c ? '3px solid white' : '3px solid transparent', boxShadow: form.color === c ? `0 0 0 2px ${c}` : 'none', transition: 'all .15s' }} />
              ))}
              <input type="color" value={form.color} onChange={e => set('color', e.target.value)} style={{ width: 32, height: 28, borderRadius: 5, cursor: 'pointer', border: '1px solid var(--border)', background: 'var(--bg3)', padding: 2 }} title="Custom color" />
            </div>
          </FormGroup>
          <div style={{ marginTop: 8 }} />
          <button className="btn btn-accent" onClick={save} disabled={saving}>{saving ? <><Spinner size={13}/> Saving…</> : '💾 Save Profile'}</button>
        </div>
      )}

      {tab === 'timezone' && (
        <div className="card" style={{ maxWidth: 520 }}>
          <div className="card-title">🌍 Timezone Preference</div>
          <p style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 20, lineHeight: 1.6 }}>
            Select your timezone. All task dates, reminders, history, and real-time updates will automatically display in your selected timezone.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 24 }}>
            {TIMEZONES.map(t => (
              <div key={t.value} onClick={() => set('timezone', t.value)}
                style={{ padding: '16px 18px', borderRadius: 'var(--radius)', border: `2px solid ${form.timezone === t.value ? 'var(--accent)' : 'var(--border)'}`, background: form.timezone === t.value ? 'var(--accent-bg)' : 'var(--bg3)', cursor: 'pointer', transition: 'all .2s' }}>
                <div className="flex items-center justify-between mb-4">
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{t.label}</span>
                  {form.timezone === t.value && <span className="badge badge-blue">✓ Selected</span>}
                </div>
                <div style={{ fontSize: 12, color: 'var(--text2)' }}>📍 {t.city}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4, fontFamily: 'var(--mono)' }}>
                  Current time: {new Date().toLocaleTimeString('en-US', { timeZone: t.value === 'IST' ? 'Asia/Kolkata' : 'America/Chicago', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })} {t.value}
                </div>
              </div>
            ))}
          </div>
          <div style={{ background: 'var(--accent-bg)', border: '1px solid var(--accent-border)', borderRadius: 'var(--radius-sm)', padding: '10px 14px', fontSize: 12, color: 'var(--text2)', marginBottom: 20 }}>
            ℹ️ Only IST and CST/CDT are supported. These are the two official timezones for this platform.
          </div>
          <button className="btn btn-accent" onClick={save} disabled={saving}>{saving ? <><Spinner size={13}/> Saving…</> : '🌍 Save Timezone'}</button>
        </div>
      )}

      {tab === 'password' && (
        <div className="card" style={{ maxWidth: 420 }}>
          <div className="card-title">🔒 Change Password</div>
          <FormGroup label="Current Password">
            <input className="input" type="password" value={pwd.currentPassword} onChange={e => setPwd(p => ({ ...p, currentPassword: e.target.value }))} placeholder="Your current password" />
          </FormGroup>
          <FormGroup label="New Password" hint="At least 6 characters">
            <input className="input" type="password" value={pwd.newPassword} onChange={e => setPwd(p => ({ ...p, newPassword: e.target.value }))} placeholder="New password" />
          </FormGroup>
          <FormGroup label="Confirm New Password">
            <input className="input" type="password" value={pwd.confirm} onChange={e => setPwd(p => ({ ...p, confirm: e.target.value }))} placeholder="Repeat new password" />
          </FormGroup>
          {pwd.newPassword && pwd.confirm && pwd.newPassword !== pwd.confirm && (
            <div style={{ color: 'var(--red)', fontSize: 12, marginBottom: 12, background: 'var(--red-bg)', padding: '8px 12px', borderRadius: 6 }}>⚠ Passwords do not match</div>
          )}
          <button className="btn btn-accent" onClick={changePwd} disabled={pwdSaving || !pwd.currentPassword || !pwd.newPassword || pwd.newPassword !== pwd.confirm}>
            {pwdSaving ? <><Spinner size={13}/> Saving…</> : '🔒 Change Password'}
          </button>
        </div>
      )}

      {tab === 'preferences' && (
        <div className="card" style={{ maxWidth: 480 }}>
          <div className="card-title">⚙ Notification Preferences</div>
          <p style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 16 }}>Manage which notifications you receive:</p>
          {[
            ['Task assignments', 'Get notified when a task is assigned to you'],
            ['Task updates', 'Get notified when tasks you own are updated'],
            ['Comments', 'Get notified on new comments on your tasks'],
            ['Priority changes', 'Alert when task priority is changed'],
            ['Due date reminders', 'Reminders for upcoming due dates'],
            ['Task closed', 'Notification when your tasks are closed'],
          ].map(([label, hint]) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 0', borderBottom: '1px solid var(--border)' }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{label}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)' }}>{hint}</div>
              </div>
              <Toggle on={true} onChange={() => toast('Coming soon!')} />
            </div>
          ))}
          <div style={{ marginTop: 16 }}>
            <div className="flex items-center gap-8">
              <span style={{ fontSize: 13 }}>Account ID</span>
              <code style={{ fontFamily: 'var(--mono)', fontSize: 11, background: 'var(--bg3)', padding: '3px 8px', borderRadius: 4, color: 'var(--text2)' }}>{user.id}</code>
            </div>
            <div className="flex items-center gap-8 mt-8">
              <span style={{ fontSize: 13 }}>Member since</span>
              <span style={{ fontSize: 12, color: 'var(--text2)' }}>{user.created_at?.split(' ')[0]}</span>
            </div>
            <div className="flex items-center gap-8 mt-8">
              <span style={{ fontSize: 13 }}>Login count</span>
              <span style={{ fontSize: 12, color: 'var(--text2)' }}>{user.login_count || 1} times</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
