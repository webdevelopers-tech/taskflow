import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, WSProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import { AllTasks, MyTasks } from './pages/Tasks';
import { Kanban, Team, Hours, Productivity } from './pages/OtherPages';
import Admin from './pages/Admin';
import Analytics from './pages/Analytics';
import Audit from './pages/Audit';
import Branding from './pages/Branding';
import Profile from './pages/Profile';
import Reminders from './pages/Reminders';
import History from './pages/History';
import Categories from './pages/Categories';
import Backup from './pages/Backup';
import Chat from './pages/Chat';
import { Spinner } from './components/UI';

function ProtectedRoute({ children, adminOnly = false }) {
  const { user, loading, brand } = useAuth();
  if (loading) return (
    <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', flexDirection: 'column', gap: 16 }}>
      <div style={{ width: 44, height: 44, background: 'var(--accent)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 800, color: 'white' }}>
        {brand?.login_logo_text || 'TF'}
      </div>
      <Spinner size={22} />
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && !user.is_admin) return <Navigate to="/dashboard" replace />;
  return <Layout>{children}</Layout>;
}

function PublicRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to="/dashboard" replace />;
  return children;
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <WSProvider>
          <Routes>
            <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
            <Route path="/dashboard"    element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/tasks"        element={<ProtectedRoute><AllTasks /></ProtectedRoute>} />
            <Route path="/my-tasks"     element={<ProtectedRoute><MyTasks /></ProtectedRoute>} />
            <Route path="/kanban"       element={<ProtectedRoute><Kanban /></ProtectedRoute>} />
            <Route path="/team"         element={<ProtectedRoute><Team /></ProtectedRoute>} />
            <Route path="/hours"        element={<ProtectedRoute><Hours /></ProtectedRoute>} />
            <Route path="/productivity" element={<ProtectedRoute><Productivity /></ProtectedRoute>} />
            <Route path="/reminders"    element={<ProtectedRoute><Reminders /></ProtectedRoute>} />
            <Route path="/chat"         element={<ProtectedRoute><Chat /></ProtectedRoute>} />
            <Route path="/history"      element={<ProtectedRoute><History /></ProtectedRoute>} />
            <Route path="/profile"      element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            {/* Admin-only routes */}
            <Route path="/admin"        element={<ProtectedRoute adminOnly><Admin /></ProtectedRoute>} />
            <Route path="/analytics"    element={<ProtectedRoute adminOnly><Analytics /></ProtectedRoute>} />
            <Route path="/audit"        element={<ProtectedRoute adminOnly><Audit /></ProtectedRoute>} />
            <Route path="/branding"     element={<ProtectedRoute adminOnly><Branding /></ProtectedRoute>} />
            <Route path="/categories"   element={<ProtectedRoute adminOnly><Categories /></ProtectedRoute>} />
            <Route path="/backup"       element={<ProtectedRoute adminOnly><Backup /></ProtectedRoute>} />
            <Route path="*"             element={<Navigate to="/dashboard" replace />} />
          </Routes>
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: { background: 'var(--bg2)', color: 'var(--text)', border: '1px solid var(--border2)', borderRadius: 'var(--radius)', fontFamily: 'var(--font)', fontSize: 13, maxWidth: 400 },
              success: { iconTheme: { primary: 'var(--green)', secondary: 'white' } },
              error:   { iconTheme: { primary: 'var(--red)',   secondary: 'white' } },
            }}
          />
        </WSProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
