import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth, useWS } from '../context/AuthContext';
import { Avatar, LiveClock, Spinner } from './UI';
import { getNotifications, markAllRead, deleteNotif, markRead } from '../utils/api';
import { formatDateTime } from '../utils/api';
import toast from 'react-hot-toast';

const NAV = [
  { path:'/dashboard',    label:'Dashboard',     icon:'⊞' },
  null,
  { path:'/tasks',        label:'All Tasks',      icon:'☑', badge:'overdue' },
  { path:'/my-tasks',     label:'My Tasks',       icon:'◎', badge:'my' },
  { path:'/kanban',       label:'Kanban Board',   icon:'⋮⋮' },
  null,
  { path:'/reminders',    label:'Reminders',      icon:'🔔', badge:'notif' },
  { path:'/chat',         label:'Team Chat',      icon:'💬', badge:'chat' },
  { path:'/history',      label:'Task History',   icon:'📜' },
  { path:'/team',         label:'Team',           icon:'👥' },
  { path:'/hours',        label:'Work Hours',     icon:'🕐' },
  { path:'/productivity', label:'Productivity',   icon:'📈' },
];
const ADMIN_NAV = [
  { path:'/admin',       label:'Admin Panel',    icon:'⚙' },
  { path:'/analytics',   label:'Analytics',      icon:'📊' },
  { path:'/audit',       label:'Audit Logs',     icon:'🔍' },
  { path:'/branding',    label:'Branding',       icon:'🎨' },
  { path:'/categories',  label:'Categories',     icon:'📁' },
  { path:'/backup',      label:'Backup & Export',icon:'🗄' },
];

// ===== SOUND ENGINE — 4 distinct tones =====
let audioCtx = null;

function getAudioCtx() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  return audioCtx;
}

// tone: 'bell' | 'chime' | 'alert' | 'success' | 'warning' | 'error'
function playTone(tone = 'bell') {
  try {
    const ctx = getAudioCtx();
    const gain = ctx.createGain();
    gain.connect(ctx.destination);

    const play = (freq, start, dur, type = 'sine', vol = 0.3) => {
      const osc = ctx.createOscillator();
      const g   = ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
      g.gain.setValueAtTime(vol, ctx.currentTime + start);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur);
    };

    switch (tone) {
      case 'bell':    play(880, 0, .4); play(1100, .08, .35); play(880, .2, .3); break;
      case 'chime':   play(1047, 0, .3); play(1319, .12, .3); play(1568, .24, .4); break;
      case 'alert':   play(660, 0, .15, 'square', .2); play(660, .2, .15, 'square', .2); play(880, .4, .25, 'square', .2); break;
      case 'success': play(523, 0, .2); play(659, .15, .2); play(784, .3, .4); break;
      case 'warning': play(440, 0, .2, 'triangle', .25); play(330, .25, .3, 'triangle', .2); break;
      case 'error':   play(220, 0, .25, 'sawtooth', .15); play(165, .3, .4, 'sawtooth', .15); break;
      default:        play(880, 0, .3);
    }
  } catch {}
}

// Expose for other components
export { playTone };

export default function Layout({ children }) {
  const { user, logout, brand } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { connected, subscribe } = useWS();
  const [notifications, setNotifications] = useState([]);
  const [unread,     setUnread]     = useState(0);
  const [chatUnread, setChatUnread] = useState(0);
  const [showNotifs, setShowNotifs] = useState(false);
  const [badges,     setBadges]     = useState({ overdue:0, my:0 });
  const [soundEnabled, setSoundEnabled] = useState(() => localStorage.getItem('soundEnabled') !== 'false');
  // Persistent reminder popup (stays until dismissed)
  const [reminderPopup, setReminderPopup]     = useState(null);
  const [reminderSoundRef, setReminderSoundRef] = useState(null);
  const notifRef = useRef(null);

  const toggleSound = () => {
    setSoundEnabled(v => { localStorage.setItem('soundEnabled', !v); return !v; });
  };

  // Stop repeating reminder sound
  const stopReminderSound = (intervalId) => {
    if (intervalId) clearInterval(intervalId);
    setReminderSoundRef(null);
  };

  const loadNotifs = async () => {
    try {
      const d = await getNotifications({ limit:30 });
      setNotifications(d.notifications); setUnread(d.unread);
    } catch {}
  };

  useEffect(() => { loadNotifs(); }, []);

  // WS: general notifications — brief toast
  useEffect(() => {
    if (!subscribe) return;
    return subscribe('notification:new', (msg) => {
      if (msg.notification?.user_id === user?.id) {
        loadNotifs();
        if (soundEnabled) playTone('bell');
        toast.custom(() => (
          <div className="slide-in" style={{ background:'var(--bg2)', border:'1px solid var(--border2)', borderLeft:`3px solid var(--accent)`, borderRadius:'var(--radius)', padding:'12px 16px', minWidth:280, maxWidth:360, boxShadow:'var(--shadow)' }}>
            <div style={{ fontWeight:600, fontSize:13, marginBottom:3 }}>{msg.notification.title}</div>
            <div style={{ fontSize:12, color:'var(--text2)' }}>{msg.notification.message}</div>
          </div>
        ), { duration:5000 });
      }
    });
  }, [subscribe, user, soundEnabled]);

  // WS: reminder fires — PERSISTENT popup + REPEATING SOUND until dismissed
  useEffect(() => {
    if (!subscribe) return;
    return subscribe('reminder:fire', (msg) => {
      loadNotifs();

      if (soundEnabled) {
        const tone = msg.reminder?.sound_tone || 'alert';
        // Play immediately
        playTone(tone);
        // Keep repeating every 8 seconds until user dismisses
        const intervalId = setInterval(() => {
          playTone(tone);
        }, 8000);
        setReminderSoundRef(prev => {
          if (prev) clearInterval(prev); // clear any previous
          return intervalId;
        });
      }

      // Fetch full task details and show the popup
      import('../utils/api').then(({ getTask }) => {
        if (msg.reminder?.task_id) {
          getTask(msg.reminder.task_id).then(taskDetail => {
            setReminderPopup({ ...msg.reminder, taskDetail, arrivedAt: Date.now() });
          }).catch(() => {
            setReminderPopup({ ...msg.reminder, arrivedAt: Date.now() });
          });
        } else {
          setReminderPopup({ ...msg.reminder, arrivedAt: Date.now() });
        }
      });
    });
  }, [subscribe, soundEnabled]);

  // WS task updates refresh badges
  useEffect(() => {
    if (!subscribe) return;
    const refresh = async () => {
      try {
        const s = await import('../utils/api').then(m => m.getTaskStats());
        setBadges({ overdue: s.overdue, my: s.myPending });
        setUnread(s.myOverdue || 0);
      } catch {}
    };
    const u1 = subscribe('task:created', refresh);
    const u2 = subscribe('task:updated', refresh);
    // Chat DMs — increment badge if not on chat page
    const u3 = subscribe('chat:message', (msg) => {
      if (msg.dm && msg.message?.sender_id !== user?.id) {
        if (!window.location.pathname.startsWith('/chat')) setChatUnread(c=>c+1);
      }
    });
    return () => { u1(); u2(); u3(); };
  }, [subscribe, user]);

  // Close notif panel on outside click
  useEffect(() => {
    const h = (e) => { if (notifRef.current && !notifRef.current.contains(e.target)) setShowNotifs(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const handleMarkAll = async () => {
    await markAllRead();
    setNotifications(n => n.map(x=>({...x,is_read:1}))); setUnread(0);
  };

  const handleDelete = async (id, e) => {
    e.stopPropagation();
    await deleteNotif(id);
    setNotifications(n => n.filter(x=>x.id!==id));
  };

  const handleReadNotif = async (n) => {
    if (!n.is_read) await markRead(n.id);
    setNotifications(prev => prev.map(x=>x.id===n.id?{...x,is_read:1}:x));
    setUnread(u => Math.max(0,u-(!n.is_read?1:0)));
    if (n.task_id) navigate(`/tasks?highlight=${n.task_id}`);
    setShowNotifs(false);
  };

  const sidebarBg = brand?.sidebar_color || 'var(--bg2)';
  const headerBg  = brand?.header_color  || 'var(--bg2)';

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100vh' }}>
      {/* HEADER */}
      <header style={{ height:'var(--header-h)', background:headerBg, borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', padding:'0 18px', gap:14, flexShrink:0, zIndex:100 }}>
        {/* Logo */}
        <div className="flex items-center gap-10" style={{ width:'var(--sidebar-w)', flexShrink:0 }}>
          {brand?.logo_url
            ? <img src={brand.logo_url} style={{ height:30, objectFit:'contain' }} alt="logo" />
            : <div style={{ width:32, height:32, background:'var(--accent)', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', fontSize:13, fontWeight:800, color:'#fff', letterSpacing:'-1px' }}>{brand?.login_logo_text||'TF'}</div>
          }
          <div>
            <div style={{ fontSize:15, fontWeight:700, letterSpacing:'-.5px' }}>{brand?.company_name||'TaskFlow'}</div>
          </div>
          {connected && <span style={{ width:6, height:6, borderRadius:'50%', background:'var(--green)', boxShadow:'0 0 6px var(--green)' }} title="Live" />}
        </div>

        {/* Search */}
        <div style={{ flex:1, maxWidth:380, position:'relative' }}>
          <span style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'var(--text3)', fontSize:15 }}>⌕</span>
          <input className="input" placeholder="Search tasks…" style={{ paddingLeft:32, height:36 }}
            onKeyDown={e=>e.key==='Enter'&&navigate(`/tasks?search=${e.target.value}`)} />
        </div>

        <div className="flex items-center gap-12" style={{ marginLeft:'auto' }}>
          {/* Timezone clock */}
          <div style={{ background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'var(--radius-sm)', padding:'5px 10px', display:'flex', alignItems:'center', gap:6 }}>
            <span style={{ fontSize:11, color:'var(--text3)' }}>🌍</span>
            <LiveClock />
          </div>

          {/* Sound toggle */}
          <button onClick={toggleSound} style={{ width:32, height:32, borderRadius:'var(--radius-sm)', background:soundEnabled?'var(--accent-bg)':'var(--bg3)', border:`1px solid ${soundEnabled?'var(--accent-border)':'var(--border)'}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, cursor:'pointer', transition:'all .2s' }} title={soundEnabled?'Mute notifications':'Unmute notifications'}>
            {soundEnabled ? '🔊' : '🔇'}
          </button>

          {/* Notifications */}
          <div ref={notifRef} style={{ position:'relative' }}>
            <button onClick={()=>setShowNotifs(v=>!v)} style={{ width:36, height:36, borderRadius:'var(--radius-sm)', background:'var(--bg3)', border:`1px solid ${showNotifs?'var(--accent)':'var(--border)'}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, cursor:'pointer', transition:'all .2s', position:'relative' }}>
              🔔
              {unread>0 && (
                <span className="notif-badge" style={{ fontSize:9 }}>{unread>99?'99+':unread}</span>
              )}
            </button>

            {showNotifs && (
              <div style={{ position:'absolute', right:0, top:44, width:360, background:'var(--bg2)', border:'1px solid var(--border2)', borderRadius:'var(--radius-lg)', boxShadow:'var(--shadow)', zIndex:400, overflow:'hidden' }} className="slide-in">
                <div style={{ padding:'14px 16px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                  <div>
                    <span style={{ fontWeight:700, fontSize:14 }}>Notifications</span>
                    {unread>0 && <span className="badge badge-red" style={{ marginLeft:8 }}>{unread}</span>}
                  </div>
                  <div className="flex gap-8">
                    <button className="btn btn-ghost btn-sm" onClick={handleMarkAll}>Mark all read</button>
                    <button className="btn btn-ghost btn-sm" onClick={()=>navigate('/reminders')}>View all</button>
                  </div>
                </div>

                <div style={{ maxHeight:380, overflowY:'auto' }}>
                  {notifications.length===0
                    ? <div style={{ padding:24, textAlign:'center', color:'var(--text3)', fontSize:13 }}>No notifications</div>
                    : notifications.map(n => (
                      <div key={n.id} onClick={()=>handleReadNotif(n)}
                        style={{ padding:'12px 14px', borderBottom:'1px solid var(--border)', cursor:'pointer', background:n.is_read?'transparent':'var(--accent-bg)', transition:'background .15s', display:'flex', alignItems:'flex-start', gap:10 }}
                        onMouseEnter={e=>e.currentTarget.style.background='var(--bg3)'}
                        onMouseLeave={e=>e.currentTarget.style.background=n.is_read?'transparent':'var(--accent-bg)'}
                      >
                        <div style={{ fontSize:16, marginTop:1 }}>{n.title.split(' ')[0]}</div>
                        <div style={{ flex:1, minWidth:0 }}>
                          {!n.is_read && <div style={{ width:6, height:6, borderRadius:'50%', background:'var(--accent)', display:'inline-block', marginRight:6, marginBottom:1 }} />}
                          <span style={{ fontSize:12, fontWeight: n.is_read?400:600 }}>{n.title.slice(2).trim()}</span>
                          <div style={{ fontSize:11, color:'var(--text2)', marginTop:2, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{n.message}</div>
                          <div style={{ fontSize:10, color:'var(--text3)', marginTop:3 }}>{n.created_at}</div>
                        </div>
                        <button onClick={e=>handleDelete(n.id,e)} style={{ fontSize:12, color:'var(--text3)', padding:'2px 5px', borderRadius:4, background:'var(--bg3)', cursor:'pointer', flexShrink:0 }} onMouseEnter={e=>e.currentTarget.style.color='var(--red)'} onMouseLeave={e=>e.currentTarget.style.color='var(--text3)'}>✕</button>
                      </div>
                    ))
                  }
                </div>
              </div>
            )}
          </div>

          {/* User */}
          <div className="flex items-center gap-8" style={{ cursor:'pointer', padding:'4px 8px', borderRadius:'var(--radius-sm)', border:'1px solid transparent', transition:'all .15s' }}
            onClick={()=>navigate('/profile')}
            onMouseEnter={e=>e.currentTarget.style.borderColor='var(--border2)'}
            onMouseLeave={e=>e.currentTarget.style.borderColor='transparent'}>
            <Avatar name={user.name} color={user.color} size="sm" />
            <div style={{ lineHeight:1.3 }}>
              <div style={{ fontSize:12, fontWeight:600 }}>{user.name.split(' ')[0]}</div>
              <div style={{ fontSize:10, color:'var(--text3)' }}>{user.timezone}</div>
            </div>
          </div>
        </div>
      </header>

      <div style={{ display:'flex', flex:1, overflow:'hidden' }}>
        {/* SIDEBAR */}
        <nav style={{ width:'var(--sidebar-w)', background:sidebarBg, borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', flexShrink:0, overflowY:'auto', padding:'10px 0' }}>
          <div style={{ padding:'6px 16px 4px', fontSize:10, textTransform:'uppercase', letterSpacing:1, color:'var(--text3)', fontWeight:600 }}>Workspace</div>

          {NAV.map((item, i) => {
            if (!item) return <div key={i} style={{ height:1, background:'var(--border)', margin:'5px 12px' }} />;
            const active = pathname === item.path || (item.path !== '/dashboard' && pathname.startsWith(item.path));
            const badge = item.badge==='overdue'?badges.overdue : item.badge==='my'?badges.my : item.badge==='notif'?unread : item.badge==='chat'?chatUnread : 0;
            return <NavItem key={item.path} item={item} active={active} badge={badge} onClick={()=>navigate(item.path)} />;
          })}

          {user.is_admin && <>
            <div style={{ height:1, background:'var(--border)', margin:'5px 12px' }} />
            <div style={{ padding:'6px 16px 4px', fontSize:10, textTransform:'uppercase', letterSpacing:1, color:'var(--text3)', fontWeight:600 }}>Admin</div>
            {ADMIN_NAV.map(item => (
              <NavItem key={item.path} item={item} active={pathname.startsWith(item.path)} onClick={()=>navigate(item.path)} />
            ))}
          </>}

          {/* User card */}
          <div style={{ marginTop:'auto', padding:'12px 14px', borderTop:'1px solid var(--border)' }}>
            <div className="flex items-center gap-10" style={{ marginBottom:8 }} onClick={()=>navigate('/profile')} style={{ cursor:'pointer', display:'flex', alignItems:'center', gap:10, marginBottom:8, padding:6, borderRadius:'var(--radius-sm)', transition:'background .15s' }}
              onMouseEnter={e=>e.currentTarget.style.background='var(--bg3)'}
              onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
              <Avatar name={user.name} color={user.color} size="sm" />
              <div style={{ flex:1, overflow:'hidden' }}>
                <div style={{ fontSize:12, fontWeight:600, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{user.name}</div>
                <div style={{ fontSize:10, color:'var(--text2)' }}>{user.role}</div>
              </div>
            </div>
            <button className="btn btn-danger btn-sm" style={{ width:'100%', justifyContent:'center' }} onClick={logout}>Sign Out</button>
          </div>
        </nav>

        {/* MAIN */}
        <main style={{ flex:1, overflowY:'auto', background:'var(--bg)', padding:24 }}>
          {children}
        </main>
      </div>


      {/* ===== ENTERPRISE REMINDER POPUP — repeating sound, full task actions ===== */}
      {reminderPopup && (
        <ReminderActionPopup
          reminder={reminderPopup}
          soundEnabled={soundEnabled}
          onClose={(markDone) => {
            stopReminderSound(reminderSoundRef);
            if (markDone) playTone('success');
            setReminderPopup(null);
            loadNotifs();
          }}
          navigate={navigate}
        />
      )}
    </div>
  );
}

function NavItem({ item, active, badge, onClick }) {
  return (
    <div onClick={onClick} style={{ display:'flex', alignItems:'center', gap:10, padding:'7px 14px', borderRadius:'var(--radius-sm)', margin:'1px 8px', cursor:'pointer', color:active?'var(--accent2)':'var(--text2)', background:active?'var(--accent-bg)':'transparent', fontSize:13, fontWeight:active?500:400, transition:'all .13s', position:'relative' }}
      onMouseEnter={e=>{ if(!active){ e.currentTarget.style.background='var(--bg3)'; e.currentTarget.style.color='var(--text)'; }}}
      onMouseLeave={e=>{ if(!active){ e.currentTarget.style.background='transparent'; e.currentTarget.style.color='var(--text2)'; }}}>
      {active && <div style={{ position:'absolute', left:-8, top:'50%', transform:'translateY(-50%)', width:3, height:18, background:'var(--accent)', borderRadius:'0 3px 3px 0' }} />}
      <span style={{ width:18, textAlign:'center', fontSize:14 }}>{item.icon}</span>
      {item.label}
      {badge>0 && <span style={{ marginLeft:'auto', background:'var(--red)', color:'#fff', fontSize:10, padding:'2px 6px', borderRadius:9, fontWeight:600 }}>{badge>99?'99+':badge}</span>}
    </div>
  );
}
// ===== ENTERPRISE REMINDER ACTION POPUP =====
// Stays on screen, sound repeats, full task actions available
function ReminderActionPopup({ reminder, soundEnabled, onClose, navigate }) {
  const [status, setStatus]   = useState('idle'); // idle | completing | updating
  const [taskStatus, setTaskStatus] = useState(reminder.taskDetail?.status || reminder.task_status || 'pending');
  const [note, setNote]       = useState('');
  const [showNote, setShowNote] = useState(false);
  const [snoozing, setSnoozing] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  // Track elapsed time since popup appeared
  React.useEffect(() => {
    const start = reminder.arrivedAt || Date.now();
    const t = setInterval(() => setElapsed(Math.floor((Date.now()-start)/1000)), 1000);
    return () => clearInterval(t);
  }, [reminder.arrivedAt]);

  const fmtElapsed = (s) => s<60?`${s}s`:s<3600?`${Math.floor(s/60)}m ${s%60}s`:`${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m`;

  const priorityColor = { high:'var(--red)', medium:'var(--amber)', low:'var(--green)' };
  const pColor = priorityColor[reminder.priority] || 'var(--amber)';
  const isRepeating = (reminder.repeat_interval || 0) > 0;
  const intervalLabel = reminder.repeat_interval >= 60 
    ? `every ${Math.round(reminder.repeat_interval/60)}h`
    : reminder.repeat_interval > 0 ? `every ${reminder.repeat_interval}m` : 'once';

  const handleMarkComplete = async () => {
    setStatus('completing');
    try {
      const { updateTask, updateTaskReminder } = await import('../utils/api');
      // Mark task as closed
      await updateTask(reminder.task_id, { status: 'closed' });
      setTaskStatus('closed');
      // Mark reminder as completed
      await updateTaskReminder(reminder.id, { status: 'completed' });
      toast.success('✅ Task closed & reminder stopped!');
      onClose(true);
    } catch(e) {
      toast.error('Failed to update task');
      setStatus('idle');
    }
  };

  const handleUpdateStatus = async (newStatus) => {
    setStatus('updating');
    try {
      const { updateTask } = await import('../utils/api');
      await updateTask(reminder.task_id, { status: newStatus });
      setTaskStatus(newStatus);
      toast.success(`Status updated to ${newStatus}`);
      setStatus('idle');
    } catch { toast.error('Failed'); setStatus('idle'); }
  };

  const handleSnooze = async (mins) => {
    setSnoozing(true);
    try {
      const { updateTaskReminder } = await import('../utils/api');
      await updateTaskReminder(reminder.id, { snooze_minutes: mins });
      toast.success(`⏸ Snoozed ${mins >= 60 ? Math.round(mins/60)+'h' : mins+'m'}`);
      onClose(false);
    } catch { toast.error('Failed'); setSnoozing(false); }
  };

  const handleDismiss = async () => {
    try {
      const { updateTaskReminder } = await import('../utils/api');
      await updateTaskReminder(reminder.id, { status: 'completed' });
    } catch {}
    onClose(false);
  };

  return (
    <div style={{
      position:'fixed', inset:0, zIndex:9999,
      background:'rgba(0,0,0,0.82)',
      backdropFilter:'blur(8px)',
      display:'flex', alignItems:'center', justifyContent:'center',
      animation:'fadeUp .15s ease'
    }}>
      <div style={{
        background:'var(--bg2)',
        border:`3px solid ${pColor}`,
        borderRadius:'var(--radius-xl)',
        width:500, maxWidth:'95vw',
        maxHeight:'92vh', overflowY:'auto',
        boxShadow:`0 0 80px ${pColor}44, 0 24px 80px rgba(0,0,0,.8)`,
        animation:'fadeUp .2s ease',
      }}>
        {/* Header strip */}
        <div style={{ background:pColor, padding:'12px 20px', display:'flex', alignItems:'center', gap:12, borderRadius:'calc(var(--radius-xl) - 3px) calc(var(--radius-xl) - 3px) 0 0' }}>
          <div style={{ fontSize:24, animation:'ping 1s ease infinite' }}>⏰</div>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:800, fontSize:14, color:'#fff', letterSpacing:'.5px', textTransform:'uppercase' }}>
              REMINDER ALERT {isRepeating && `· ${intervalLabel}`}
            </div>
            <div style={{ fontSize:11, color:'rgba(255,255,255,.8)', marginTop:1 }}>
              Active for {fmtElapsed(elapsed)} · {isRepeating ? 'Sound repeating until dismissed' : 'One-time reminder'}
            </div>
          </div>
          <div style={{ background:'rgba(0,0,0,.2)', borderRadius:6, padding:'3px 8px', fontSize:11, color:'rgba(255,255,255,.9)', fontWeight:600 }}>
            {reminder.timezone}
          </div>
        </div>

        <div style={{ padding:'24px 24px 20px' }}>
          {/* Task / reminder info */}
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:20, fontWeight:700, letterSpacing:'-.4px', lineHeight:1.3, marginBottom:8 }}>
              {reminder.task_title || 'Reminder'}
            </div>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap', alignItems:'center' }}>
              {reminder.task_id && (
                <span className={`badge badge-${reminder.priority==='high'?'red':reminder.priority==='medium'?'amber':'green'}`}>
                  {reminder.priority} priority
                </span>
              )}
              {reminder.task_id && (
                <span className={`badge ${taskStatus==='closed'?'badge-green':taskStatus==='in-progress'?'badge-blue':'badge-amber'}`}>
                  {taskStatus==='closed'?'✅ Closed':taskStatus==='in-progress'?'🔄 In Progress':'⏳ Pending'}
                </span>
              )}
              {reminder.task_due_date && (
                <span style={{ fontSize:11, color:'var(--text3)' }}>📅 Due: {reminder.task_due_date}</span>
              )}
            </div>
          </div>

          {/* Reminder message */}
          {reminder.note && (
            <div style={{ background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'var(--radius-sm)', padding:'12px 14px', marginBottom:16, fontSize:13, color:'var(--text)', lineHeight:1.6, borderLeft:`3px solid ${pColor}` }}>
              <div style={{ fontSize:10, fontWeight:700, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.5px', marginBottom:4 }}>Reminder Note</div>
              {reminder.note}
            </div>
          )}

          {/* Task description if available */}
          {reminder.taskDetail?.description && (
            <div style={{ background:'var(--bg3)', borderRadius:'var(--radius-sm)', padding:'10px 12px', marginBottom:16, fontSize:12, color:'var(--text2)', lineHeight:1.5 }}>
              {reminder.taskDetail.description.slice(0,200)}{reminder.taskDetail.description.length>200?'…':''}
            </div>
          )}

          {/* TASK STATUS UPDATE — directly in popup */}
          {reminder.task_id && taskStatus !== 'closed' && (
            <div style={{ marginBottom:16 }}>
              <div style={{ fontSize:11, fontWeight:700, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.5px', marginBottom:8 }}>Update Task Status</div>
              <div style={{ display:'flex', gap:8 }}>
                {[['in-progress','🔄 Start Working'],['closed','✅ Mark Complete']].map(([s,l])=>(
                  <button key={s}
                    className={`btn btn-sm ${taskStatus===s?'btn-accent':'btn-ghost'}`}
                    onClick={()=>s==='closed'?handleMarkComplete():handleUpdateStatus(s)}
                    disabled={status!=='idle'}>
                    {status!=='idle' && taskStatus!==s?<Spinner size={11}/>:l}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Snooze options */}
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:11, fontWeight:700, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.5px', marginBottom:8 }}>Snooze Reminder</div>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              {[[10,'10 min'],[30,'30 min'],[60,'1 hour'],[240,'4 hours']].map(([m,l])=>(
                <button key={m} className="btn btn-ghost btn-sm" onClick={()=>handleSnooze(m)} disabled={snoozing}>
                  😴 {l}
                </button>
              ))}
            </div>
          </div>

          {/* Add note (task-bound reminders only) */}
          {reminder.task_id && (showNote ? (
            <div style={{ marginBottom:16 }}>
              <textarea className="input" value={note} onChange={e=>setNote(e.target.value)}
                placeholder="Add a progress note…" style={{ minHeight:60 }} autoFocus />
              <div style={{ display:'flex', gap:8, marginTop:8 }}>
                <button className="btn btn-ghost btn-sm" onClick={()=>setShowNote(false)}>Cancel</button>
                <button className="btn btn-accent btn-sm" onClick={async()=>{
                  if (!note.trim()) return;
                  try {
                    const { addComment } = await import('../utils/api');
                    await addComment(reminder.task_id, note);
                    toast.success('💬 Note added to task');
                    setNote(''); setShowNote(false);
                  } catch { toast.error('Failed'); }
                }}>Add Note</button>
              </div>
            </div>
          ) : (
            <button className="btn btn-ghost btn-sm" style={{ marginBottom:16 }} onClick={()=>setShowNote(true)}>
              💬 Add Note to Task
            </button>
          ))}
        </div>

        {/* Footer actions */}
        <div style={{ borderTop:'1px solid var(--border)', padding:'14px 24px', display:'flex', gap:10, justifyContent:'space-between', alignItems:'center', background:'var(--bg3)', borderRadius:`0 0 calc(var(--radius-xl) - 3px) calc(var(--radius-xl) - 3px)` }}>
          <button className="btn btn-ghost btn-sm" onClick={()=>{ navigate('/reminders'); onClose(false); }}>
            📋 All Reminders
          </button>
          <div style={{ display:'flex', gap:8 }}>
            {reminder.task_id && (
              <button className="btn btn-ghost btn-sm" onClick={()=>{ navigate(`/tasks?highlight=${reminder.task_id}`); onClose(false); }}>
                🔗 Open Task
              </button>
            )}
            <button className="btn btn-danger btn-sm" onClick={handleDismiss}>
              ✕ Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
