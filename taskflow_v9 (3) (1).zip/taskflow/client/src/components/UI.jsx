import { useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { formatDateTime, formatDate, isOverdue, TIMEZONES } from '../utils/api';

export function Avatar({ name='?', color='#6366f1', size='md', className='' }) {
  const initials = name.split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase();
  return <div className={`avatar avatar-${size} ${className}`} style={{ background:color }} title={name}>{initials}</div>;
}

// Timezone-aware date display
export function TZDate({ value, showTime=false }) {
  const { user } = useAuth();
  const tz = user?.timezone || 'IST';
  const overdue = !showTime && isOverdue(value);
  return (
    <span style={{ color: overdue?'var(--red)':'inherit' }}>
      {showTime ? formatDateTime(value,tz) : formatDate(value,tz)}
      {overdue && ' ⚠'}
    </span>
  );
}

// Live clock
export function LiveClock() {
  const { user } = useAuth();
  const tz = user?.timezone || 'IST';
  const ref = useRef(null);
  useEffect(() => {
    const tick = () => {
      if (ref.current) {
        const tzName = TIMEZONES[tz]?.tz || 'Asia/Kolkata';
        const abbr   = TIMEZONES[tz]?.abbr || 'IST';
        ref.current.textContent = new Date().toLocaleTimeString('en-US', { timeZone:tzName, hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:true })+' '+abbr;
      }
    };
    tick();
    const i = setInterval(tick, 1000);
    return () => clearInterval(i);
  }, [tz]);
  return <span ref={ref} className="mono" style={{ fontSize:12, letterSpacing:'-.3px' }} />;
}

export function PriorityBadge({ priority }) {
  const map = { high:['badge-red','🔴'], medium:['badge-amber','🟡'], low:['badge-green','🟢'] };
  const [cls, icon] = map[priority]||['badge-gray','⚪'];
  return <span className={`badge ${cls}`}>{icon} {priority}</span>;
}

export function StatusBadge({ status }) {
  const map = {
    pending:     ['badge-amber', '⏳', 'Pending'],
    'in-progress':['badge-blue', '🔄', 'In Progress'],
    closed:      ['badge-green', '✅', 'Task Closed'],
  };
  const [cls, icon, label] = map[status]||['badge-gray','?',status];
  return <span className={`badge ${cls}`}>{icon} {label}</span>;
}

export function CategoryBadge({ category, color }) {
  const map = { design:'badge-purple', development:'badge-blue', marketing:'badge-amber', hr:'badge-teal', finance:'badge-green', legal:'badge-amber', general:'badge-gray', operations:'badge-gray', sales:'badge-teal', support:'badge-blue', accounts:'badge-purple', hospitality:'badge-amber', installation:'badge-gray', 'customer-service':'badge-teal' };
  if (color) {
    return <span className="badge" style={{ background:color+'22', color }}>{category}</span>;
  }
  return <span className={`badge ${map[category]||'badge-gray'}`}>{category}</span>;
}

export function Spinner({ size=18 }) {
  return <div className="spinner" style={{ width:size, height:size }} />;
}

export function PageLoader() {
  return <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', flex:1 }}><Spinner size={28} /></div>;
}

export function Modal({ open, onClose, title, children, width=560 }) {
  const overlayRef = useRef(null);
  useEffect(() => {
    if (open) document.body.style.overflow='hidden';
    else document.body.style.overflow='';
    return () => { document.body.style.overflow=''; };
  }, [open]);
  useEffect(() => {
    const h = (e) => { if (e.key==='Escape') onClose(); };
    if (open) window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div ref={overlayRef} onClick={e=>{if(e.target===overlayRef.current)onClose();}}
      style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.75)', zIndex:500, display:'flex', alignItems:'center', justifyContent:'center', backdropFilter:'blur(6px)', animation:'fadeUp .2s ease' }}>
      <div style={{ background:'var(--bg2)', border:'1px solid var(--border2)', borderRadius:'var(--radius-lg)', padding:28, width, maxWidth:'95vw', maxHeight:'90vh', overflowY:'auto', boxShadow:'var(--shadow)', animation:'fadeUp .22s ease' }}>
        <div className="flex items-center justify-between mb-16">
          <h2 style={{ fontSize:17, fontWeight:700, letterSpacing:'-.3px' }}>{title}</h2>
          <button onClick={onClose} style={{ width:30, height:30, borderRadius:'var(--radius-sm)', background:'var(--bg3)', border:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text2)', cursor:'pointer', transition:'all .15s' }}
            onMouseEnter={e=>{e.currentTarget.style.background='var(--red-bg)'; e.currentTarget.style.color='var(--red)';}}
            onMouseLeave={e=>{e.currentTarget.style.background='var(--bg3)'; e.currentTarget.style.color='var(--text2)';}}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function FormGroup({ label, children, required, hint }) {
  return (
    <div className="mb-16">
      <label className="label">{label}{required && <span style={{color:'var(--red)',marginLeft:3}}>*</span>}</label>
      {children}
      {hint && <div style={{fontSize:11,color:'var(--text3)',marginTop:4}}>{hint}</div>}
    </div>
  );
}

export function ProgressBar({ value, color='var(--accent)', height=6 }) {
  return (
    <div className="progress-bar" style={{ height }}>
      <div className="progress-fill" style={{ width:`${Math.min(100,Math.max(0,value))}%`, background:color }} />
    </div>
  );
}

export function EmptyState({ icon='📋', title='Nothing here', sub='', action }) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon">{icon}</div>
      <div className="empty-state-title">{title}</div>
      {sub && <div className="empty-state-sub">{sub}</div>}
      {action && <div style={{marginTop:16}}>{action}</div>}
    </div>
  );
}

export function Toggle({ on, onChange }) {
  return <div className={`toggle ${on?'on':''}`} onClick={()=>onChange(!on)} />;
}

export function SectionHeader({ title, sub, action }) {
  return (
    <div className="flex items-start justify-between mb-24">
      <div>
        <h1 style={{ fontSize:22, fontWeight:700, letterSpacing:'-.5px' }}>{title}</h1>
        {sub && <div style={{ fontSize:13, color:'var(--text2)', marginTop:3 }}>{sub}</div>}
      </div>
      {action}
    </div>
  );
}

export function NotifTypeIcon({ category }) {
  const icons = { task_assigned:'📋', task_closed:'✅', task_updated:'✏️', task_reopened:'🔄', comment_added:'💬', priority_changed:'⚡', due_date_changed:'📅', task_overdue:'🔴', general:'🔔' };
  return <span>{icons[category]||'🔔'}</span>;
}
