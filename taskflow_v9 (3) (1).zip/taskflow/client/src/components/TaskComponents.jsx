import React, { useState, useEffect, useRef } from 'react';
import { Avatar, PriorityBadge, StatusBadge, CategoryBadge, Modal, FormGroup, Spinner, TZDate } from './UI';
import AttachmentPanel from './AttachmentPanel';
import { updateTask, deleteTask, createTask, addComment, getTask } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { isOverdue, formatDateTime } from '../utils/api';
import toast from 'react-hot-toast';

export function TaskCard({ task, onUpdate, onDelete, compact=false }) {
  const { user } = useAuth();
  const [loading,       setLoading]       = useState(false);
  const [detail,        setDetail]        = useState(false);
  const [quickReminder, setQuickReminder] = useState(false);
  const overdue    = task.status!=='closed' && isOverdue(task.due_date);
  const isCreator  = task.assigned_by===user.id;
  const isAssignee = task.assigned_to===user.id;
  const canEdit    = user.is_admin || isCreator || isAssignee; // any involved person
  const canFullEdit= user.is_admin || isCreator || isAssignee; // all can edit content
  const canDelete  = user.is_admin || isCreator;

  const toggleClose = async (e) => {
    e.stopPropagation(); setLoading(true);
    try {
      const newStatus = task.status==='closed' ? 'pending' : 'closed';
      const updated = await updateTask(task.id, { status: newStatus });
      onUpdate?.(updated);
      toast.success(newStatus==='closed' ? '✅ Task Closed!' : '🔄 Task Reopened');
    } catch { toast.error('Failed to update'); }
    setLoading(false);
  };

  const handleDelete = async (e) => {
    e.stopPropagation();
    if (!confirm(`Delete "${task.title}"?`)) return;
    try { await deleteTask(task.id); onDelete?.(task.id); toast.success('Task deleted'); }
    catch { toast.error('Failed to delete'); }
  };

  const leftColor = overdue ? 'var(--red)' : task.priority==='high' ? 'var(--red)' : task.priority==='medium' ? 'var(--amber)' : 'var(--green)';

  return (
    <>
      <div onClick={()=>setDetail(true)} style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'var(--radius)', padding:'14px 16px', transition:'all .18s', cursor:'pointer', display:'flex', alignItems:'flex-start', gap:14, borderLeft:`3px solid ${leftColor}`, opacity:task.status==='closed'?.6:1 }}
        onMouseEnter={e=>{ e.currentTarget.style.borderColor='var(--border2)'; e.currentTarget.style.transform='translateY(-1px)'; e.currentTarget.style.boxShadow='var(--shadow-sm)'; }}
        onMouseLeave={e=>{ e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.transform='none'; e.currentTarget.style.boxShadow='none'; }}>
        {/* Checkbox */}
        <div onClick={toggleClose} style={{ width:22, height:22, borderRadius:'50%', border:`2px solid ${task.status==='closed'?'var(--green)':'var(--border2)'}`, cursor:'pointer', flexShrink:0, marginTop:1, display:'flex', alignItems:'center', justifyContent:'center', background:task.status==='closed'?'var(--green)':'transparent', transition:'all .2s' }}>
          {loading ? <Spinner size={11} /> : task.status==='closed' && <span style={{color:'#fff',fontSize:11,fontWeight:700}}>✓</span>}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:13, fontWeight:500, marginBottom:6, textDecoration:task.status==='closed'?'line-through':'none', color:task.status==='closed'?'var(--text2)':'var(--text)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{task.title}</div>
          {!compact && (
            <div className="flex items-center gap-6" style={{ flexWrap:'wrap' }}>
              <CategoryBadge category={task.category} />
              <PriorityBadge priority={task.priority} />
              <span style={{ fontSize:11 }}><TZDate value={task.due_date} /></span>
              {task.assigned_to_name && <span style={{ display:'flex', alignItems:'center', gap:5, fontSize:11, color:'var(--text2)' }}><Avatar name={task.assigned_to_name} color={task.assigned_to_color} size="xs" />{task.assigned_to_name}</span>}
            </div>
          )}
          {compact && <div className="flex gap-6 items-center"><PriorityBadge priority={task.priority} /><span style={{fontSize:11}}><TZDate value={task.due_date} /></span></div>}
        </div>
        <div style={{ display:'flex', gap:5, flexShrink:0 }}>
          <button className="btn btn-ghost btn-icon btn-sm" title="Set reminder" onClick={e=>{e.stopPropagation();setQuickReminder(true);}}>⏰</button>
          {canEdit && <button className="btn btn-ghost btn-icon btn-sm" title="Edit task" onClick={e=>{e.stopPropagation();setDetail(true);}}>✎</button>}
          {canDelete && <button className="btn btn-danger btn-icon btn-sm" onClick={handleDelete}>✕</button>}
        </div>
      </div>
      <TaskDetailModal taskId={task.id} open={detail} onClose={()=>setDetail(false)} onUpdate={onUpdate} />
      <QuickReminderModal open={quickReminder} onClose={()=>setQuickReminder(false)} task={task} />
    </>
  );
}

function TaskDetailModal({ taskId, open, onClose, onUpdate }) {
  const { user } = useAuth();
  const [task, setTask]       = useState(null);
  const [comment, setComment] = useState('');
  const [saving, setSaving]   = useState(false);
  const [loading, setLoading] = useState(true);
  const [detailTab, setDetailTab] = useState('details');

  useEffect(() => {
    if (!open || !taskId) return;
    setLoading(true);
    setDetailTab('details');
    getTask(taskId).then(t => { setTask(t); setLoading(false); }).catch(() => setLoading(false));
  }, [open, taskId]);

  if (!open) return null;
  const overdue    = task && task.status!=='closed' && isOverdue(task.due_date);
  const isCreator  = task && task.assigned_by===user.id;
  const isAssignee = task && task.assigned_to===user.id;
  const canEdit    = task && (user.is_admin || isCreator || isAssignee);
  const canFullEdit= task && (user.is_admin || isCreator || isAssignee); // all involved can edit

  const handleStatus = async (status) => {
    try {
      const updated = await updateTask(task.id, { status });
      setTask(t => ({...t,...updated}));
      onUpdate?.(updated);
      toast.success(status==='closed'?'✅ Task Closed!':status==='in-progress'?'🔄 In Progress':'⏳ Set to Pending');
    } catch { toast.error('Update failed'); }
  };

  const handleComment = async () => {
    if (!comment.trim()) return;
    setSaving(true);
    try {
      const c = await addComment(task.id, comment);
      setTask(t => ({...t, comments:[...(t.comments||[]),c]}));
      setComment('');
      toast.success('💬 Comment added');
    } catch { toast.error('Failed'); }
    setSaving(false);
  };

  // Action icons per history event
  const histIcon = (action) => {
    const m = { task_created:'🆕',task_closed:'✅',status_changed:'🔄',priority_changed:'⚡',due_date_changed:'📅',comment_added:'💬',task_reopened:'↩️',assigned_to_changed:'👤',attachment_added:'📎',attachment_removed:'🗑' };
    return m[action]||'📝';
  };

  return (
    <Modal open={open} onClose={onClose} title={loading?'Loading…':task?.title||'Task Details'} width={660}>
      {loading ? <div style={{textAlign:'center',padding:40}}><Spinner size={24}/></div> : !task ? <p>Not found</p> : (
        <>
          {/* Badges row */}
          <div className="flex gap-6 mb-12" style={{ flexWrap:'wrap' }}>
            <PriorityBadge priority={task.priority} />
            <StatusBadge status={task.status} />
            <CategoryBadge category={task.category} />
            {overdue && <span className="badge badge-red">⚠ Overdue</span>}
            {task.project && <span className="badge badge-gray">📁 {task.project}</span>}
          </div>

          {/* Tabs */}
          <div style={{ display:'flex', borderBottom:'1px solid var(--border)', marginBottom:16, gap:2 }}>
            {[['details','📋 Details'],['attachments','📎 Attachments'],['history','📜 History'],['comments','💬 Comments']].map(([k,l])=>(
              <div key={k} onClick={()=>setDetailTab(k)}
                style={{ padding:'7px 14px', fontSize:12, fontWeight:detailTab===k?600:400, color:detailTab===k?'var(--accent2)':'var(--text2)', borderBottom:`2px solid ${detailTab===k?'var(--accent)':'transparent'}`, marginBottom:-1, cursor:'pointer', transition:'all .15s', borderRadius:'var(--radius-sm) var(--radius-sm) 0 0' }}>{l}</div>
            ))}
          </div>

          {/* DETAILS TAB */}
          {detailTab==='details' && (
            <>
              {task.description && <p style={{ fontSize:13, color:'var(--text2)', lineHeight:1.7, marginBottom:14, background:'var(--bg3)', padding:12, borderRadius:'var(--radius-sm)' }}>{task.description}</p>}
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px 16px', fontSize:13, marginBottom:14 }}>
                <div><span style={{color:'var(--text3)'}}>Assigned to: </span><span style={{display:'inline-flex',alignItems:'center',gap:5}}><Avatar name={task.assigned_to_name||'?'} color={task.assigned_to_color} size="xs"/>{task.assigned_to_name}</span></div>
                <div><span style={{color:'var(--text3)'}}>Assigned by: </span>{task.assigned_by_name}</div>
                <div><span style={{color:'var(--text3)'}}>Due Date: </span><TZDate value={task.due_date} /></div>
                <div><span style={{color:'var(--text3)'}}>Created: </span><TZDate value={task.created_at} showTime /></div>
                {task.closed_by_name && <div><span style={{color:'var(--text3)'}}>Closed by: </span>{task.closed_by_name}</div>}
                {task.completed_at  && <div><span style={{color:'var(--text3)'}}>Closed on: </span><TZDate value={task.completed_at} /></div>}
                {task.project && <div><span style={{color:'var(--text3)'}}>Project: </span>{task.project}</div>}
              </div>
              {/* Status change — assignee and creator can do this */}
              {canEdit && (
                <div className="mb-14">
                  <div className="label" style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <span>Change Status</span>
                    {canFullEdit && <EditTaskInline task={task} onSaved={(u)=>{ setTask(t=>({...t,...u})); onUpdate?.(u); }} />}
                  </div>
                  <div className="flex gap-8">
                    {[['pending','⏳ Pending'],['in-progress','🔄 In Progress'],['closed','✅ Task Closed']].map(([s,l])=>(
                      <button key={s} className={`btn btn-sm ${task.status===s?'btn-accent':'btn-ghost'}`} onClick={()=>handleStatus(s)}>{l}</button>
                    ))}
                  </div>

                </div>
              )}
              <div className="label">Add Comment</div>
              <textarea className="input" value={comment} onChange={e=>setComment(e.target.value)} placeholder="Write a comment…" style={{ minHeight:70 }} />
              <div className="flex justify-end gap-8 mt-10">
                <button className="btn btn-ghost btn-sm" onClick={onClose}>Close</button>
                <button className="btn btn-accent btn-sm" onClick={handleComment} disabled={saving||!comment.trim()}>{saving?<Spinner size={12}/>:'💬 Post Comment'}</button>
              </div>
            </>
          )}

          {/* ATTACHMENTS TAB */}
          {detailTab==='attachments' && (
            <AttachmentPanel taskId={task.id} canEdit={canEdit} />
          )}

          {/* HISTORY TAB — timeline format */}
          {detailTab==='history' && (
            <div>
              <div style={{ fontSize:12, color:'var(--text3)', marginBottom:12 }}>{task.history?.length||0} activity entries</div>
              {(!task.history||task.history.length===0)
                ? <div style={{ textAlign:'center', padding:'24px 0', color:'var(--text3)', fontSize:13 }}>No history yet</div>
                : <div style={{ position:'relative', paddingLeft:24 }}>
                    {/* Timeline line */}
                    <div style={{ position:'absolute', left:8, top:0, bottom:0, width:2, background:'var(--border)', borderRadius:2 }} />
                    {task.history.map((h,i)=>(
                      <div key={h.id} style={{ position:'relative', marginBottom:12, paddingLeft:16 }}>
                        {/* Timeline dot */}
                        <div style={{ position:'absolute', left:-20, top:8, width:14, height:14, borderRadius:'50%', background:'var(--bg2)', border:'2px solid var(--accent)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:8 }}>{histIcon(h.action)}</div>
                        <div style={{ background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'var(--radius-sm)', padding:'9px 12px' }}>
                          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:h.old_value||h.new_value?4:0 }}>
                            <Avatar name={h.user_name} color={h.user_color} size="xs" />
                            <span style={{ fontSize:12, fontWeight:600 }}>{h.user_name}</span>
                            <span style={{ fontSize:12, color:'var(--text2)' }}>{h.action?.replace(/_/g,' ')}</span>
                            <span style={{ marginLeft:'auto', fontSize:10, color:'var(--text3)', flexShrink:0 }}>{h.created_at}</span>
                          </div>
                          {(h.old_value||h.new_value) && (
                            <div style={{ display:'flex', alignItems:'center', gap:6, fontSize:11, marginTop:4 }}>
                              {h.old_value && <span style={{ background:'var(--red-bg)', color:'var(--red)', padding:'2px 6px', borderRadius:4, textDecoration:'line-through' }}>{h.old_value}</span>}
                              {h.old_value && h.new_value && <span style={{ color:'var(--text3)' }}>→</span>}
                              {h.new_value && <span style={{ background:'var(--green-bg)', color:'var(--green)', padding:'2px 6px', borderRadius:4 }}>{h.new_value}</span>}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
              }
            </div>
          )}

          {/* COMMENTS TAB */}
          {detailTab==='comments' && (
            <div>
              <div style={{ maxHeight:320, overflowY:'auto', display:'flex', flexDirection:'column', gap:8, marginBottom:16 }}>
                {(!task.comments||task.comments.length===0)
                  ? <div style={{ textAlign:'center', padding:'24px 0', color:'var(--text3)', fontSize:13 }}>No comments yet</div>
                  : task.comments.map(c=>(
                    <div key={c.id} style={{ background:'var(--bg3)', padding:'10px 12px', borderRadius:'var(--radius-sm)', border:'1px solid var(--border)' }}>
                      <div className="flex items-center gap-8 mb-5">
                        <Avatar name={c.user_name} color={c.user_color} size="xs" />
                        <span style={{ fontWeight:600, fontSize:12 }}>{c.user_name}</span>
                        <span style={{ fontSize:10, color:'var(--text3)', marginLeft:'auto' }}>{c.created_at}</span>
                      </div>
                      <p style={{ color:'var(--text2)', fontSize:13, lineHeight:1.5 }}>{c.content}</p>
                    </div>
                  ))
                }
              </div>
              <div className="label">Add Comment</div>
              <textarea className="input" value={comment} onChange={e=>setComment(e.target.value)} placeholder="Write a comment…" style={{ minHeight:70 }} />
              <div className="flex justify-end gap-8 mt-10">
                <button className="btn btn-ghost btn-sm" onClick={onClose}>Close</button>
                <button className="btn btn-accent btn-sm" onClick={handleComment} disabled={saving||!comment.trim()}>{saving?<Spinner size={12}/>:'💬 Post Comment'}</button>
              </div>
            </div>
          )}
        </>
      )}
    </Modal>
  );
}

// Inline edit button — opens TaskModal with existing task
function EditTaskInline({ task, onSaved }) {
  const [open, setOpen] = useState(false);
  const [users, setUsers] = useState([]);
  useEffect(() => { if (open) import('../utils/api').then(m=>m.getUsers().then(setUsers).catch(()=>{})); }, [open]);
  return (
    <>
      <button className="btn btn-ghost btn-sm" onClick={()=>setOpen(true)}>✏️ Edit Task</button>
      <TaskModal open={open} onClose={()=>setOpen(false)} editTask={task} users={users} onSave={(u)=>{ onSaved?.(u); setOpen(false); }} />
    </>
  );
}

// Quick reminder modal — for ⏰ button on task cards
const QUICK_TONES = [
  { value:'bell','label':'🔔 Bell'},{ value:'chime','label':'🎵 Chime'},
  { value:'alert','label':'🚨 Alert'},{ value:'success','label':'✅ Success'},
];

function quickPlayTone(tone) {
  try {
    const ctx = new (window.AudioContext||window.webkitAudioContext)();
    const osc = ctx.createOscillator(), g = ctx.createGain();
    osc.connect(g); g.connect(ctx.destination);
    const freqs = { bell:[880,1100], chime:[1047,1568], alert:[660,880], success:[523,784] };
    const [f1,f2] = freqs[tone]||[880,660];
    osc.type = tone==='alert'?'square':'sine';
    osc.frequency.setValueAtTime(f1, ctx.currentTime);
    osc.frequency.setValueAtTime(f2, ctx.currentTime+0.15);
    g.gain.setValueAtTime(0.3, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime+0.5);
    osc.start(); osc.stop(ctx.currentTime+0.5);
  } catch {}
}

function QuickReminderModal({ open, onClose, task }) {
  const { user } = useAuth();
  const minDT = new Date(Date.now()+60000).toISOString().slice(0,16);
  const [form, setForm] = useState({ remind_at:'', timezone:user?.timezone||'IST', note:'', sound_tone:'bell' });
  const [saving, setSaving] = useState(false);
  const setF = (k,v) => setForm(f=>({...f,[k]:v}));

  useEffect(()=>{ if(open) setForm({ remind_at:'', timezone:user?.timezone||'IST', note:'', sound_tone:'bell' }); },[open]);

  const save = async () => {
    if (!form.remind_at) return toast.error('Select date & time');
    setSaving(true);
    try {
      const { createTaskReminder } = await import('../utils/api');
      // Always target the task's assigned person — whoever they are
      // If the current user IS the assignee, they set it for themselves
      // If current user is creator/admin, they set it for the assignee
      const targetUserId = task.assigned_to;
      await createTaskReminder({ task_id:task.id, ...form, target_user_id:targetUserId });
      const isForSelf = targetUserId === user.id;
      toast.success(isForSelf ? '⏰ Reminder set for yourself!' : `⏰ Reminder set for ${task.assigned_to_name||'assignee'}!`);
      onClose();
    } catch(e){ toast.error(e.response?.data?.error||'Failed'); }
    setSaving(false);
  };

  return (
    <Modal open={open} onClose={onClose} title={`⏰ Reminder — ${task?.title?.slice(0,40)}`} width={440}>
      <FormGroup label="Date & Time" required>
        <input className="input" type="datetime-local" value={form.remind_at} min={minDT} onChange={e=>setF('remind_at',e.target.value)} />
      </FormGroup>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:14 }}>
        <FormGroup label="Timezone">
          <select className="input" value={form.timezone} onChange={e=>setF('timezone',e.target.value)}>
            <option value="IST">🇮🇳 IST</option><option value="CST">🇺🇸 CST</option>
          </select>
        </FormGroup>
        <div>
          <div className="label">Sound Tone</div>
          <div style={{ display:'flex', gap:5, flexWrap:'wrap', marginTop:5 }}>
            {QUICK_TONES.map(t=>(
              <span key={t.value} onClick={()=>setF('sound_tone',t.value)}
                className={`chip ${form.sound_tone===t.value?'active':''}`}
                style={{ fontSize:11, display:'flex', alignItems:'center', gap:3 }}>
                {t.label}
                <span onClick={e=>{e.stopPropagation();quickPlayTone(t.value);}} style={{ fontSize:9, cursor:'pointer', color:'var(--accent2)' }}>▶</span>
              </span>
            ))}
          </div>
        </div>
      </div>
      <FormGroup label="Note / Message">
        <input className="input" value={form.note} onChange={e=>setF('note',e.target.value)} placeholder="Reminder message… (optional)" />
      </FormGroup>
      <div className="flex gap-10 justify-end pt-12" style={{ borderTop:'1px solid var(--border)' }}>
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-accent" onClick={save} disabled={saving||!form.remind_at}>{saving?<Spinner size={13}/>:'⏰ Set Reminder'}</button>
      </div>
    </Modal>
  );
}

export function TaskModal({ open, onClose, onSave, editTask, users, defaultAssignee }) {
  const { user } = useAuth();
  const today = new Date().toISOString().split('T')[0];
  const blank = { title:'', description:'', assigned_to:defaultAssignee||user?.id||'', priority:'medium', status:'pending', category:'general', due_date:'', project:'', tags:'' };
  const [form, setForm] = useState(blank);
  const [saving, setSaving] = useState(false);
  const [categories, setCategories] = useState([]);
  const [tab, setTab] = useState('details');
  // Reminder state
  const [reminders, setReminders] = useState([]);
  const [newRem, setNewRem] = useState({ remind_at:'', timezone: user?.timezone||'IST', note:'' });
  const [remSaving, setRemSaving] = useState(false);
  // Attachment state for new task creation
  const [pendingFiles, setPendingFiles] = useState([]);
  const [uploadingFiles, setUploadingFiles] = useState(false);
  const fileInputRef = React.useRef(null);

  // Permission: only admin/creator can reassign; assignees can edit everything else
  const isCreatorOfEditTask = editTask && editTask.assigned_by === user.id;
  const canReassign = !editTask || user.is_admin || isCreatorOfEditTask;

  useEffect(() => {
    if (open) {
      setForm(editTask ? { title:editTask.title, description:editTask.description||'', assigned_to:editTask.assigned_to, priority:editTask.priority, status:editTask.status, category:editTask.category, due_date:editTask.due_date, project:editTask.project||'', tags:editTask.tags||'' } : {...blank, assigned_to:defaultAssignee||user?.id||''});
      setTab('details');
      setPendingFiles([]);
      // Load categories
      import('../utils/api').then(m => m.getCategories().then(c => setCategories(c)).catch(()=>{}));
      // Load existing reminders if editing
      if (editTask) {
        import('../utils/api').then(m => m.getTaskReminders({ task_id: editTask.id }).then(setReminders).catch(()=>{}));
      } else { setReminders([]); }
    }
  }, [open, editTask]);

  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const setRem = (k,v) => setNewRem(r=>({...r,[k]:v}));

  const save = async () => {
    if (!form.title.trim()) return toast.error('Title required');
    if (!form.due_date) return toast.error('Due date required');
    setSaving(true);
    try {
      const result = editTask ? await updateTask(editTask.id, form) : await createTask(form);
      // Upload any pending attachments after task is created
      if (pendingFiles.length > 0 && result.id) {
        const { uploadTaskAttachment } = await import('../utils/api');
        setUploadingFiles(true);
        for (const file of pendingFiles) {
          try { await uploadTaskAttachment(result.id, file, ()=>{}); } catch {}
        }
        setUploadingFiles(false);
        setPendingFiles([]);
        toast.success(`📎 ${pendingFiles.length} file(s) attached`);
      }
      onSave?.(result);
      toast.success(editTask ? '✏️ Task updated' : '✅ Task created');
      onClose();
    } catch (e) { toast.error(e.response?.data?.error||'Failed to save task'); }
    setSaving(false);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files||[]);
    const valid = files.filter(f => f.size <= 25*1024*1024);
    const tooBig = files.filter(f => f.size > 25*1024*1024);
    if (tooBig.length) toast.error(`${tooBig.length} file(s) exceed 25MB limit`);
    setPendingFiles(prev => [...prev, ...valid]);
    e.target.value = '';
  };

  const removePendingFile = (idx) => setPendingFiles(p => p.filter((_,i)=>i!==idx));

  const addReminder = async () => {
    if (!newRem.remind_at) return toast.error('Select reminder date/time');
    const taskId = editTask?.id;
    if (!taskId) return toast.error('Save the task first before adding reminders');
    setRemSaving(true);
    try {
      const { createTaskReminder } = await import('../utils/api');
      // Target the task's assigned person — they get the popup
      const targetUserId = editTask.assigned_to || user.id;
      const created = await createTaskReminder({ task_id:taskId, ...newRem, target_user_id:targetUserId });
      setReminders(r=>[...r, created]);
      setNewRem({ remind_at:'', timezone: user?.timezone||'IST', note:'' });
      const isForSelf = targetUserId === user.id;
      toast.success(isForSelf ? '⏰ Reminder set!' : `⏰ Reminder set for ${editTask.assigned_to_name||'assignee'}!`);
    } catch(e) { toast.error(e.response?.data?.error||'Failed'); }
    setRemSaving(false);
  };

  const deleteReminder = async (id) => {
    const { deleteTaskReminder } = await import('../utils/api');
    await deleteTaskReminder(id);
    setReminders(r=>r.filter(x=>x.id!==id));
    toast.success('Reminder deleted');
  };

  // Build category options: dynamic categories + static fallbacks
  const catOptions = categories.length > 0
    ? categories.map(c => ({ value: c.name.toLowerCase().replace(/\s+/g,'-'), label: `${c.icon||'📁'} ${c.name}`, color: c.color }))
    : [{ value:'general', label:'📁 General' },{ value:'design', label:'🎨 Design' },{ value:'development', label:'💻 Development' },{ value:'marketing', label:'📣 Marketing' },{ value:'hr', label:'👥 HR' },{ value:'finance', label:'💰 Finance' },{ value:'legal', label:'⚖ Legal' },{ value:'operations', label:'⚙ Operations' }];

  return (
    <Modal open={open} onClose={onClose} title={editTask?'✏️ Edit Task':'➕ New Task'} width={620}>
      {/* Tabs: Details | Attachments | Reminders(edit only) */}
      <div style={{ display:'flex', gap:4, marginBottom:16, borderBottom:'1px solid var(--border)', paddingBottom:0 }}>
        {[
          ['details',     '📋 Details'],
          ['attachments', `📎 Attach${pendingFiles.length>0?` (${pendingFiles.length})`:''}`],
          ...(editTask ? [['reminders', `⏰ Reminders${reminders.length>0?` (${reminders.length})`:''}`]] : []),
        ].map(([k,l])=>(
          <div key={k} onClick={()=>setTab(k)} style={{ padding:'8px 14px', fontSize:13, fontWeight:tab===k?500:400, color:tab===k?'var(--accent2)':'var(--text2)', borderBottom:`2px solid ${tab===k?'var(--accent)':'transparent'}`, marginBottom:-1, cursor:'pointer', transition:'all .15s' }}>{l}</div>
        ))}
      </div>

      {/* ===== DETAILS TAB ===== */}
      {tab==='details' && (
        <>
          <FormGroup label="Title" required>
            <input className="input" value={form.title} onChange={e=>set('title',e.target.value)} placeholder="What needs to be done?" autoFocus />
          </FormGroup>
          <FormGroup label="Description">
            <textarea className="input" value={form.description} onChange={e=>set('description',e.target.value)} placeholder="Add details, requirements, or context…" style={{ minHeight:70 }} />
          </FormGroup>
          <div className="grid-2">
            <FormGroup label="Assign To" required hint={!canReassign?'Only creator/admin can reassign':''}>
              <select className="input" value={form.assigned_to} onChange={e=>set('assigned_to',e.target.value)} disabled={!canReassign}>
                {users?.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Priority">
              <select className="input" value={form.priority} onChange={e=>set('priority',e.target.value)}>
                <option value="low">🟢 Low</option><option value="medium">🟡 Medium</option><option value="high">🔴 High</option>
              </select>
            </FormGroup>
            <FormGroup label="Due Date" required hint="Shown in your timezone">
              <input className="input" type="date" value={form.due_date} min={today} onChange={e=>set('due_date',e.target.value)} />
            </FormGroup>
            <FormGroup label="Category">
              <select className="input" value={form.category} onChange={e=>set('category',e.target.value)}>
                {catOptions.map(c=><option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Project / Sprint">
              <input className="input" value={form.project} onChange={e=>set('project',e.target.value)} placeholder="e.g. Q4 Launch" />
            </FormGroup>
            {editTask && (
              <FormGroup label="Status">
                <select className="input" value={form.status} onChange={e=>set('status',e.target.value)}>
                  <option value="pending">⏳ Pending</option>
                  <option value="in-progress">🔄 In Progress</option>
                  <option value="closed">✅ Task Closed</option>
                </select>
              </FormGroup>
            )}
          </div>
          <div className="flex gap-10 justify-end mt-12 pt-12" style={{ borderTop:'1px solid var(--border)' }}>
            <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-accent" onClick={save} disabled={saving||uploadingFiles}>
              {saving||uploadingFiles ? <><Spinner size={14}/>{uploadingFiles?' Uploading…':' Saving…'}</> : editTask?'Save Changes':'Create Task'}
            </button>
          </div>
        </>
      )}

      {/* ===== ATTACHMENTS TAB ===== */}
      {tab==='attachments' && (
        <div>
          {editTask ? (
            // For existing tasks — use the full AttachmentPanel
            <AttachmentPanel taskId={editTask.id} canEdit={true} />
          ) : (
            // For NEW tasks — stage files to upload after creation
            <div>
              <p style={{ fontSize:13, color:'var(--text2)', marginBottom:14, lineHeight:1.6 }}>
                Attach files before creating the task. They'll be uploaded automatically when you click <strong>Create Task</strong>.
              </p>
              <input ref={fileInputRef} type="file" multiple style={{ display:'none' }} onChange={handleFileSelect}
                accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.doc,.docx,.xls,.xlsx,.zip,.txt,.csv,.ppt,.pptx" />
              <button className="btn btn-ghost" onClick={()=>fileInputRef.current?.click()} style={{ marginBottom:12 }}>
                📎 Choose Files
              </button>
              <span style={{ fontSize:12, color:'var(--text3)', marginLeft:10 }}>Images, PDF, DOC, XLS, ZIP · max 25MB each</span>

              {pendingFiles.length === 0 ? (
                <div style={{ textAlign:'center', padding:'28px 0', color:'var(--text3)', background:'var(--bg3)', borderRadius:'var(--radius-sm)', marginTop:12, border:'2px dashed var(--border2)', cursor:'pointer' }}
                  onClick={()=>fileInputRef.current?.click()}>
                  <div style={{ fontSize:28, marginBottom:6 }}>📁</div>
                  <div style={{ fontSize:13 }}>Click or drop files here</div>
                  <div style={{ fontSize:11, marginTop:3 }}>up to 25MB per file</div>
                </div>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:7, marginTop:12 }}>
                  {pendingFiles.map((file,i)=>(
                    <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 12px', background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'var(--radius-sm)' }}>
                      <span style={{ fontSize:18 }}>{file.type?.startsWith('image/')?'🖼':file.type?.includes('pdf')?'📄':file.type?.includes('word')?'📝':file.type?.includes('excel')||file.type?.includes('sheet')?'📊':'📎'}</span>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{file.name}</div>
                        <div style={{ fontSize:11, color:'var(--text3)' }}>{(file.size/1024).toFixed(1)} KB</div>
                      </div>
                      <button className="btn btn-danger btn-sm btn-icon" onClick={()=>removePendingFile(i)}>✕</button>
                    </div>
                  ))}
                  <div style={{ fontSize:12, color:'var(--text2)', marginTop:4 }}>
                    {pendingFiles.length} file(s) ready to attach · will upload when you create the task
                  </div>
                </div>
              )}

              <div className="flex gap-10 justify-end mt-16 pt-12" style={{ borderTop:'1px solid var(--border)' }}>
                <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
                <button className="btn btn-accent" onClick={save} disabled={saving}>
                  {saving ? <><Spinner size={14}/> {uploadingFiles?'Uploading…':'Creating…'}</> : `Create Task${pendingFiles.length>0?` + ${pendingFiles.length} file(s)`:''}`}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {tab==='reminders' && (
        <div>
          {/* Existing reminders */}
          {reminders.length>0 && (
            <div style={{ marginBottom:16 }}>
              <div className="label">Scheduled Reminders</div>
              <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                {reminders.map(r=>(
                  <div key={r.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 12px', background:'var(--bg3)', borderRadius:'var(--radius-sm)', border:`1px solid ${r.status==='fired'?'var(--green)':r.status==='snoozed'?'var(--amber)':r.status==='completed'?'var(--green)':'var(--border)'}` }}>
                    <span style={{ fontSize:14 }}>{r.status==='completed'?'✅':r.status==='fired'?'🔔':r.status==='snoozed'?'😴':'⏰'}</span>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:12, fontWeight:500 }}>{r.remind_at} <span className={`badge ${r.timezone==='IST'?'badge-purple':'badge-teal'}`} style={{ fontSize:9 }}>{r.timezone}</span></div>
                      {r.note && <div style={{ fontSize:11, color:'var(--text2)', marginTop:1 }}>{r.note}</div>}
                    </div>
                    <span className={`badge ${r.status==='pending'?'badge-blue':r.status==='fired'?'badge-amber':r.status==='completed'?'badge-green':r.status==='snoozed'?'badge-amber':'badge-gray'}`} style={{ fontSize:10 }}>{r.status}</span>
                    <button className="btn btn-danger btn-sm btn-icon" onClick={()=>deleteReminder(r.id)}>✕</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Add new reminder */}
          <div className="label">Add Reminder</div>
          <div className="grid-2 mb-12">
            <FormGroup label="Date & Time">
              <input className="input" type="datetime-local" value={newRem.remind_at} onChange={e=>setRem('remind_at',e.target.value)} />
            </FormGroup>
            <FormGroup label="Timezone">
              <select className="input" value={newRem.timezone} onChange={e=>setRem('timezone',e.target.value)}>
                <option value="IST">🇮🇳 IST (India)</option>
                <option value="CST">🇺🇸 CST (Chicago)</option>
              </select>
            </FormGroup>
          </div>
          <FormGroup label="Reminder Note">
            <input className="input" value={newRem.note} onChange={e=>setRem('note',e.target.value)} placeholder="Optional reminder message…" />
          </FormGroup>
          <div className="flex gap-10 justify-end mt-4">
            <button className="btn btn-ghost" onClick={onClose}>Close</button>
            <button className="btn btn-accent" onClick={addReminder} disabled={remSaving||!newRem.remind_at}>{remSaving?<Spinner size={13}/>:'⏰ Set Reminder'}</button>
          </div>
        </div>
      )}
    </Modal>
  );
}
