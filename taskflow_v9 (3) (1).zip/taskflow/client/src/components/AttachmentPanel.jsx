import { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { Spinner } from './UI';
import { getTaskAttachments, uploadTaskAttachment, deleteTaskAttachment, taskAttachmentDownloadUrl, taskAttachmentPreviewUrl } from '../utils/api';
import toast from 'react-hot-toast';

const ICONS = {
  'image':       '🖼',
  'pdf':         '📄',
  'word':        '📝',
  'excel':       '📊',
  'powerpoint':  '📊',
  'zip':         '🗜',
  'text':        '📃',
  'default':     '📎',
};

function getFileIcon(mime) {
  if (mime?.startsWith('image/'))   return ICONS.image;
  if (mime?.includes('pdf'))        return ICONS.pdf;
  if (mime?.includes('word') || mime?.includes('msword')) return ICONS.word;
  if (mime?.includes('excel') || mime?.includes('spreadsheet')) return ICONS.excel;
  if (mime?.includes('powerpoint') || mime?.includes('presentation')) return ICONS.powerpoint;
  if (mime?.includes('zip'))        return ICONS.zip;
  if (mime?.startsWith('text/'))    return ICONS.text;
  return ICONS.default;
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes+'B';
  if (bytes < 1024*1024) return (bytes/1024).toFixed(1)+'KB';
  return (bytes/1024/1024).toFixed(1)+'MB';
}

function isPreviewable(mime) {
  return mime?.startsWith('image/') || mime?.includes('pdf');
}

export default function AttachmentPanel({ taskId, canEdit=false }) {
  const { user } = useAuth();
  const [attachments, setAttachments] = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [uploading, setUploading] = useState(false);
  const [progress,  setProgress]  = useState(0);
  const [preview,   setPreview]   = useState(null); // { url, type, name }
  const fileRef = useRef(null);

  const load = useCallback(async () => {
    if (!taskId) return;
    try { setAttachments(await getTaskAttachments(taskId)); }
    catch { } finally { setLoading(false); }
  }, [taskId]);

  useEffect(() => { load(); }, [load]);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 25*1024*1024) return toast.error('Max file size is 25MB');
    setUploading(true); setProgress(0);
    try {
      const att = await uploadTaskAttachment(taskId, file, setProgress);
      setAttachments(prev => [att, ...prev]);
      toast.success(`📎 "${file.name}" attached!`);
    } catch(e) { toast.error(e.response?.data?.error || 'Upload failed'); }
    setUploading(false); setProgress(0);
    e.target.value = '';
  };

  const handleDelete = async (att) => {
    if (!confirm(`Remove "${att.original_name}"?`)) return;
    try {
      await deleteTaskAttachment(att.id);
      setAttachments(prev => prev.filter(a=>a.id!==att.id));
      toast.success('Attachment removed');
    } catch { toast.error('Failed to remove'); }
  };

  const openPreview = (att) => {
    if (!isPreviewable(att.mime_type)) return;
    setPreview({ url: taskAttachmentPreviewUrl(att.id), type: att.mime_type, name: att.original_name });
  };

  if (loading) return <div style={{padding:'12px 0',color:'var(--text3)',fontSize:13}}>Loading attachments…</div>;

  return (
    <div>
      {/* Upload button */}
      {canEdit && (
        <div style={{ marginBottom:12 }}>
          <input ref={fileRef} type="file" style={{ display:'none' }} onChange={handleUpload}
            accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv" />
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <button className="btn btn-ghost btn-sm" onClick={()=>fileRef.current?.click()} disabled={uploading}>
              {uploading ? <><Spinner size={12}/> Uploading…</> : '📎 Attach File'}
            </button>
            <span style={{ fontSize:11, color:'var(--text3)' }}>Images, PDF, DOC, XLS, ZIP · max 25MB</span>
          </div>
          {uploading && (
            <div style={{ marginTop:8 }}>
              <div style={{ background:'var(--bg3)', borderRadius:4, height:4, overflow:'hidden' }}>
                <div style={{ height:'100%', background:'var(--accent)', width:progress+'%', transition:'width .2s', borderRadius:4 }} />
              </div>
              <div style={{ fontSize:11, color:'var(--text3)', marginTop:3 }}>{progress}% uploaded</div>
            </div>
          )}
        </div>
      )}

      {/* Attachments list */}
      {attachments.length===0
        ? <div style={{ padding:'10px 0', color:'var(--text3)', fontSize:13 }}>No attachments yet</div>
        : <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {attachments.map(att => (
              <div key={att.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 12px', background:'var(--bg3)', borderRadius:'var(--radius-sm)', border:'1px solid var(--border)', transition:'border-color .15s' }}
                onMouseEnter={e=>e.currentTarget.style.borderColor='var(--border2)'}
                onMouseLeave={e=>e.currentTarget.style.borderColor='var(--border)'}>
                <span style={{ fontSize:20, flexShrink:0 }}>{getFileIcon(att.mime_type)}</span>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{att.original_name}</div>
                  <div style={{ fontSize:11, color:'var(--text3)', marginTop:1 }}>
                    {formatSize(att.file_size)} · {att.uploader_name} · {att.created_at?.split(' ')[0]}
                  </div>
                </div>
                <div style={{ display:'flex', gap:6, flexShrink:0 }}>
                  {isPreviewable(att.mime_type) && (
                    <button className="btn btn-ghost btn-sm" onClick={()=>openPreview(att)}>👁 Preview</button>
                  )}
                  <a href={taskAttachmentDownloadUrl(att.id)} className="btn btn-ghost btn-sm" download={att.original_name}>📥 Download</a>
                  {(canEdit || att.uploaded_by===user.id || user.is_admin) && (
                    <button className="btn btn-danger btn-sm btn-icon" onClick={()=>handleDelete(att)} title="Remove">✕</button>
                  )}
                </div>
              </div>
            ))}
          </div>
      }

      {/* Preview modal */}
      {preview && (
        <div onClick={()=>setPreview(null)} style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.85)', zIndex:600, display:'flex', alignItems:'center', justifyContent:'center', backdropFilter:'blur(4px)' }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:'var(--bg2)', borderRadius:'var(--radius-lg)', overflow:'hidden', maxWidth:'90vw', maxHeight:'90vh', display:'flex', flexDirection:'column', boxShadow:'0 24px 80px rgba(0,0,0,.7)' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 16px', borderBottom:'1px solid var(--border)' }}>
              <span style={{ fontSize:13, fontWeight:600 }}>{preview.name}</span>
              <div style={{ display:'flex', gap:8 }}>
                <a href={preview.url.replace('/preview','/download')} className="btn btn-ghost btn-sm" download={preview.name}>📥 Download</a>
                <button className="btn btn-ghost btn-sm" onClick={()=>setPreview(null)}>✕ Close</button>
              </div>
            </div>
            <div style={{ flex:1, overflow:'auto', display:'flex', alignItems:'center', justifyContent:'center', padding:8 }}>
              {preview.type?.startsWith('image/')
                ? <img src={preview.url} alt={preview.name} style={{ maxWidth:'85vw', maxHeight:'80vh', objectFit:'contain', borderRadius:6 }} />
                : <iframe src={preview.url} style={{ width:'80vw', height:'80vh', border:'none' }} title={preview.name} />
              }
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
