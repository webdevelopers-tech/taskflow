# TaskFlow — Enterprise Office Task Management Platform

A full-stack enterprise task management system with real-time collaboration, clock-in/out tracking, team productivity analytics, and role-based access control.

---

## ✨ Features

| Feature | Details |
|---|---|
| **Authentication** | JWT access tokens + refresh token rotation, bcrypt passwords |
| **Real-time** | WebSocket broadcast for task updates, clock-in/out, notifications |
| **Task Management** | CRUD, priorities, categories, due dates, comments, history |
| **Kanban Board** | Drag-free status lanes with instant status updates |
| **Clock In/Out** | Per-user daily sessions, duration tracking, overdue reminders |
| **Work Schedules** | Per-employee per-day schedule management |
| **Team Dashboard** | Live timezone clocks, team presence, activity feed |
| **Productivity** | Completion rates, hours worked, dept-level analytics |
| **Admin Panel** | Employee CRUD, schedule editing, system settings |
| **Overdue Reminders** | Hourly cron — WS push + notification, no duplicate within 24h |
| **Rate Limiting** | 500 req/15min general, 30 req/15min for login |

---

## 🚀 Quick Start

### Requirements
- Node.js ≥ 18
- npm ≥ 8

### 1. Install dependencies

```bash
# From project root
npm install --prefix server
npm install --prefix client
```

### 2. Seed the database

```bash
cd server
node src/seed.js
```

### 3a. Development mode (two terminals)

```bash
# Terminal 1 — backend (port 3001)
cd server
node src/index.js

# Terminal 2 — frontend dev server (port 5173, proxies /api → 3001)
cd client
npm run dev
```

Open: **http://localhost:5173**

### 3b. Production mode (single server)

```bash
# Build frontend
cd client && npm run build

# Start server (serves API + built frontend)
cd server && NODE_ENV=production node src/index.js
```

Open: **http://localhost:3001**

---

## 🔑 Demo Credentials

| Email | Password | Role |
|---|---|---|
| admin@taskflow.io | admin123 | Super Admin |
| alex@taskflow.io | pass123 | Senior Developer |
| maya@taskflow.io | pass123 | Product Designer |
| james@taskflow.io | pass123 | Marketing Lead |
| priya@taskflow.io | pass123 | HR Manager |
| marco@taskflow.io | pass123 | Backend Engineer |

---

## 🏗 Architecture

```
taskflow/
├── server/                     # Express + WebSocket API
│   ├── src/
│   │   ├── index.js            # Server entry (async DB init, WS setup)
│   │   ├── seed.js             # Database seeder
│   │   ├── db/
│   │   │   └── database.js     # sql.js wrapper (pure JS SQLite, no native deps)
│   │   ├── middleware/
│   │   │   └── auth.js         # JWT authenticate, requireAdmin, generateTokens
│   │   ├── routes/
│   │   │   ├── auth.js         # login, refresh, logout, /me, change-password
│   │   │   ├── tasks.js        # CRUD, stats, comments, history
│   │   │   ├── users.js        # list, get, create, update, delete, schedule
│   │   │   └── misc.js         # clock, notifications, activity, productivity
│   │   └── utils/
│   │       ├── websocket.js    # broadcast, sendToUser
│   │       └── reminders.js    # hourly overdue task checker
│   ├── data/
│   │   └── taskflow.db.json    # SQLite persisted as base64 JSON (auto-created)
│   └── .env
│
└── client/                     # React 18 + Vite
    └── src/
        ├── context/
        │   └── AuthContext.jsx  # AuthProvider + WSProvider (keepalive ping)
        ├── utils/
        │   └── api.js           # axios client, auto-refresh interceptor
        ├── components/
        │   ├── Layout.jsx       # Header, sidebar, live clock, notifications
        │   ├── UI.jsx           # Avatar, Badge, Modal, Spinner, Toggle, etc.
        │   └── TaskComponents.jsx # TaskCard, TaskDetailModal, TaskModal
        └── pages/
            ├── Login.jsx
            ├── Dashboard.jsx    # Stats, clock widget, team status, activity
            ├── Tasks.jsx        # AllTasks + MyTasks (filter chips, real-time)
            ├── OtherPages.jsx   # Kanban, Team, Hours, Productivity
            └── Admin.jsx        # Employee CRUD, schedule editor, settings
```

---

## 🗃 Database Schema (SQLite via sql.js)

| Table | Purpose |
|---|---|
| `users` | Employees — name, email, role, dept, admin flag, color, timezone |
| `work_schedules` | Per-user per-day working hours |
| `clock_sessions` | Clock-in/out records with duration |
| `tasks` | Tasks with priority, status, category, due date |
| `task_comments` | Per-task comment thread |
| `task_history` | Audit trail of status/field changes |
| `notifications` | User inbox (read/unread, types: info/success/warning/error) |
| `activity_log` | Global activity feed |
| `refresh_tokens` | JWT refresh token store with expiry |

---

## 🔌 API Reference

### Auth
| Method | Path | Description |
|---|---|---|
| POST | /api/auth/login | Sign in → access + refresh token |
| POST | /api/auth/refresh | Rotate refresh token |
| POST | /api/auth/logout | Revoke refresh token |
| GET  | /api/auth/me | Current user + schedule + active clock session |
| PUT  | /api/auth/change-password | Self-service password change |

### Tasks
| Method | Path | Description |
|---|---|---|
| GET  | /api/tasks | List with filters (status, priority, assigned_to, overdue, search) |
| GET  | /api/tasks/stats | Aggregate stats + weekly trend + by-user breakdown |
| GET  | /api/tasks/:id | Task detail with comments + history |
| POST | /api/tasks | Create task (notifies assignee) |
| PUT  | /api/tasks/:id | Update (status, priority, assignee…) |
| DELETE | /api/tasks/:id | Delete (admin or creator only) |
| POST | /api/tasks/:id/comments | Add comment → WS broadcast |

### Users (admin endpoints marked 🔒)
| Method | Path | Description |
|---|---|---|
| GET | /api/users | List all active users |
| GET | /api/users/online | Who's clocked in right now |
| GET | /api/users/:id | User detail + task stats + hours |
| POST | /api/users 🔒 | Create employee |
| PUT | /api/users/:id | Update profile (self) or any field (admin) |
| DELETE | /api/users/:id 🔒 | Soft-deactivate employee |
| PUT | /api/users/:id/schedule | Update work schedule |

### Clock
| Method | Path | Description |
|---|---|---|
| POST | /api/clock/in | Clock in for today |
| POST | /api/clock/out | Clock out + calculate duration |
| GET | /api/clock/today | Today's session + total minutes |
| GET | /api/clock/history | Paginated history (admin: any user) |
| GET | /api/clock/team | All users' status for today |
| PUT | /api/clock/:id 🔒 | Edit a session (admin) |

### Other
| Method | Path | Description |
|---|---|---|
| GET | /api/notifications | User's notifications + unread count |
| PUT | /api/notifications/:id/read | Mark one as read |
| PUT | /api/notifications/read-all | Mark all as read |
| GET | /api/activity | Team or personal activity feed |
| GET | /api/productivity/report | Per-user and per-dept performance |

---

## 🌐 WebSocket Events

Connect: `ws://localhost:3001/ws?token=<accessToken>`

| Event | Direction | Payload |
|---|---|---|
| `connected` | server→client | Initial handshake |
| `ping/pong` | client↔server | Keepalive (every 25s) |
| `task:created` | broadcast | `{ task }` |
| `task:updated` | broadcast | `{ task }` |
| `task:deleted` | broadcast | `{ taskId }` |
| `task:comment` | broadcast | `{ taskId, comment }` |
| `user:clockin` | broadcast | `{ userId, userName }` |
| `user:clockout` | broadcast | `{ userId, userName }` |
| `notification:new` | targeted | `{ notification }` |

---

## ⚙ Environment Variables

| Variable | Default | Description |
|---|---|---|
| PORT | 3001 | Server port |
| NODE_ENV | development | Set to `production` to serve frontend |
| JWT_SECRET | (default) | **Change in production!** |
| JWT_EXPIRES | 24h | Access token lifetime |
| FRONTEND_URL | http://localhost:5173 | CORS origin |
